package linkedlistoperation;

public class CircularLList {
    Node head;

    int length;

    class Node {
        int data;

        Node next;

        public Node(int data) {
            super();
            this.data = data;
            next = null;
        }

    }

    public void add(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            newNode.next = newNode;
            head = newNode;
            length++;
        } else {
            Node currNode = getLastNode();
            currNode.next = newNode;
            newNode.next = head;
            length++;

        }
    }

    public void addFirst(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            newNode.next = newNode;
            head = newNode;
            length++;
        } else {
            Node currNode = getLastNode();
            currNode.next = newNode;
            newNode.next = head;
            head = newNode;
            length++;
        }
    }

    public void deleteLast() {
        if (head != null) {
            Node currNode = head;
            while (currNode.next != head && currNode.next.next != head) {
                currNode = currNode.next;
            }
            Node lastNode = currNode.next;
            currNode.next = lastNode.next;
            length--;
        }
    }

    /**
     * iterate starting from head and give last node
     * @return
     */
    private Node getLastNode() {
        Node currNode = head;
        while (currNode.next != head) {
            currNode = currNode.next;
        }
        return currNode;
    }

    public void print() {
        Node currNode = head;
        if (head.next == currNode.next) {
            System.out.print(":element::" + head.data);
        }
        while (currNode.next != head) {

            currNode = currNode.next;
            System.out.print(" " + currNode.data);
        }

    }

    public boolean contains(int data) {

        if (head == null) {
            return false;
        } else {
            Node currNode = head;
            while (currNode.next != head && !(currNode.data == data)) {
                currNode = currNode.next;
            }
            return currNode.data == data;
        }
    }
}
