package linkedlistoperation;

public class DlinkedListTest {

    public static void main(String[] args) {
        DLinkedList dLinkedList = new DLinkedList();
        dLinkedList.add(12);
        dLinkedList.add(13);
        dLinkedList.add(14);
        dLinkedList.add(15);
        dLinkedList.printElements();
        System.out.println(":::delete First Elements::");
        dLinkedList.deleteAtFirst();
        System.out.println(":::Elements: after delete First:::");
        dLinkedList.printElements();
    }
}
