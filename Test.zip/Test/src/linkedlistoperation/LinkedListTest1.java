package linkedlistoperation;

public class LinkedListTest1 {

    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.add(5);
        linkedList.add(6);
        //        linkedList.add(7);
        //        linkedList.add(7);
        //        linkedList.add(7);
        //        linkedList.add(7);
        //        linkedList.printElements();
        System.out.println("::check loop:;;" + linkedList.isHaveLoop());

    }

}
