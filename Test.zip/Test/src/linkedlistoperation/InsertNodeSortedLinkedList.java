package linkedlistoperation;

import linkedlistoperation.LinkedList.Node;

public class InsertNodeSortedLinkedList {

    /**
     * merge two sorted linked list
     * insert node in sorted linked list
     */
    public void insertNode(LinkedList linkedList1, LinkedList linkedList2) {

        Node currNode = linkedList2.head;
        while (currNode.next != null) {
            insertNodeInSortedLList(linkedList1, currNode.data);
            currNode = currNode.next;
        }
        insertNodeInSortedLList(linkedList1, currNode.data);

    }

    private void insertNodeInSortedLList(LinkedList linkedList, int data) {
        Node newNode = new Node(data);
        Node currNode = linkedList.head;
        if (currNode.data > data && currNode.data != data) {
            // when data < from head..then we need to insert node before head
            newNode.next = currNode;
            linkedList.head = newNode;
        } else {
            while (currNode.next != null && currNode.next.data < data) {
                currNode = currNode.next;
            }
            // to avoid to add duplicate node
            if (currNode.next != null && currNode.next.data != data && currNode.data != data) {
                Node temp = currNode.next;
                currNode.next = newNode;
                newNode.next = temp;
            }
            // add in last of linked list
            if (currNode.next == null && currNode.data < data) {
                currNode.next = newNode;
            }
        }
    }

    public static void main(String[] args) {
        LinkedList linkedList1 = new LinkedList();
        linkedList1.add(4);
        linkedList1.add(5);
        linkedList1.add(7);
        linkedList1.add(9);

        LinkedList linkedList2 = new LinkedList();
        linkedList2.add(2);
        linkedList2.add(10);
        /*linkedList2.add(4);
        linkedList2.add(4);
        linkedList2.add(4);
        linkedList2.add(4);
        linkedList2.add(6);
        linkedList2.add(8);
        linkedList2.add(8);*/

        new InsertNodeSortedLinkedList().insertNode(linkedList1, linkedList2);
        linkedList1.printElements();

    }

}
