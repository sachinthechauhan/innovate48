package linkedlistoperation;

public class ListLoopTest {

    public static void main(String[] args) {

        LinkedList linkedList = new LinkedList();
        linkedList.add(1);
        linkedList.add(2);
        linkedList.add(3);
        linkedList.add(4);
        linkedList.add(5);

        // creating a loop
        linkedList.head.next.next.next.next = linkedList.head.next;

        // check for detect loop

        System.out.println(":::is have loop:::::::" + linkedList.isHaveLoop());
        // remove loop
        System.out.println("::::    " + linkedList.removeLoop());

        System.out.println(":::is have loop:::::::" + linkedList.isHaveLoop());

        linkedList.printElements();

    }

}
