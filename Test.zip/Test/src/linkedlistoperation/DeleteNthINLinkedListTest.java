package linkedlistoperation;

public class DeleteNthINLinkedListTest {

    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.add(5);
        linkedList.add(6);
        linkedList.add(7);
        linkedList.add(17);
        linkedList.add(27);
        linkedList.add(37);
        linkedList.add(87);

        System.out.println(":::::element before del::");
        linkedList.printElements();
        linkedList.deleteAtPositin(3);
        System.out.println(":::::element after del::");
        linkedList.printElements();

    }

}
