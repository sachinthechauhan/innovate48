package linkedlistoperation;

public class Test {

    public static void main(String[] args) {
        int n = 19;
        int k = 3;
        int m = n / k;
        for (;;)
            System.out.println("::::val::" + m);

    }

}
