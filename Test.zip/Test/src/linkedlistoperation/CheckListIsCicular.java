package linkedlistoperation;

import linkedlistoperation.CircularLList.Node;

public class CheckListIsCicular {

    public static void isCircular(CircularLList list) {
        Node CurrNode = list.head;
        while (CurrNode.next != null) {
            CurrNode = CurrNode.next;
            if (CurrNode == list.head) {
                System.out.println("::given list is circular ");
                break;
            }

        }

    }

    public static void isCircular(LinkedList list) {
        LinkedList.Node CurrNode = list.head;
        boolean check = false;
        while (CurrNode.next != null) {
            CurrNode = CurrNode.next;
            if (CurrNode == list.head) {
                check = true;

                break;
            }

        }
        if (check) {
            System.out.println("::given list is circular ");
        } else {
            System.out.println("::given list is not circular ");
        }

    }

    public static void main(String[] args) {
        CircularLList cLList = new CircularLList();
        cLList.add(34);
        cLList.add(35);
        cLList.add(36);
        isCircular(cLList);
        LinkedList linkedList = new LinkedList();
        linkedList.add(5);
        linkedList.add(6);
        linkedList.add(10);
        isCircular(linkedList);

    }

}
