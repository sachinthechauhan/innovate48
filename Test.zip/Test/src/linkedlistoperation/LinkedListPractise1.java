package linkedlistoperation;

public class LinkedListPractise1 {

    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.add(5);
        linkedList.add(6);
        linkedList.add(10);
        linkedList.add(14);
        linkedList.add(15);
        linkedList.add(16);
        linkedList.printElements();
        // del last element
        //        linkedList.deleteAttempt2(5);
        //        System.out.println(":::after del 15");
        //        linkedList.printElements();
        // middle of linked list
        System.out.println("::::Middle of linked list:::" + linkedList.middleOfLinkedList());
        LinkedList linkedList2 = new LinkedList();
        linkedList2.add(5);
        linkedList2.add(6);
        linkedList2.add(10);
        System.out.println("::::Middle of linked list:::" + linkedList2.middleOfLinkedList());
        // reverse list
        //        linkedList.reverseAttempt2();
        linkedList.reverse();
        System.out.println(":::after revrse;;;;");
        linkedList.printElements();

    }

}
