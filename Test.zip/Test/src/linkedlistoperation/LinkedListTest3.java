package linkedlistoperation;

public class LinkedListTest3 {

    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.add(5);
        linkedList.add(6);
        linkedList.add(7);
        linkedList.printElements();
        // delete elements
        linkedList.delete(5);
        System.out.println("::elemt after dlete");
        linkedList.printElements();
        //		System.out.println(":::index::"+linkedList.getNode(1).data);

        // insert node at position
        linkedList.add(45);
        linkedList.add(46);
        linkedList.add(47);
        linkedList.add(48);
        linkedList.printElements();
        linkedList.insertAtPositin(5, 49);
        System.out.println("::after insertion:::");
        System.out.println(":::" + linkedList.getNode(5).data);
        linkedList.printElements();
        //after Last delete
        linkedList.deleteAtLast(0);
        System.out.println("::after deletion last:::");
        linkedList.printElements();
        // delete first elements
        linkedList.deleteAtFirst(0);
        linkedList.printElements();

    }

}
