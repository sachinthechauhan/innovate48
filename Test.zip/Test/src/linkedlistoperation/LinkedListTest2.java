package linkedlistoperation;

public class LinkedListTest2 {

    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.add(5);
        linkedList.add(62);
        linkedList.add(7);
        linkedList.add(2);
        linkedList.printElements();
        System.out.println(":::elements after sorted::");
        linkedList.sort();
        linkedList.printElements();

    }

}
