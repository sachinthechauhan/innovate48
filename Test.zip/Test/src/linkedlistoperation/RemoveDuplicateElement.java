package linkedlistoperation;

public class RemoveDuplicateElement {

    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.add(5);
        linkedList.add(6);
        linkedList.add(10);
        linkedList.add(10);
        linkedList.add(11);
        linkedList.add(11);
        linkedList.add(11);
        linkedList.removeDuplicate(linkedList.head);
        linkedList.printElements();

    }

}
