package linkedlistoperation;

public class LinkedListPractise2 {

    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();
        linkedList.add(5);
        linkedList.add(6);
        linkedList.add(10);
        LinkedList linkedList2 = new LinkedList();
        linkedList2.add(6);
        linkedList2.add(8);
        linkedList2.add(10);
        linkedList2.mergeTwoList(linkedList, linkedList2);

    }

}
