package linkedlistoperation;

public class DLinkedList {
    DLLNode head;

    class DLLNode {
        int data;

        DLLNode next;

        DLLNode previous;

        public DLLNode(int data) {
            super();
            this.data = data;
            next = null;
            previous = null;

        }
    }

    public void add(int data) {
        DLLNode node = new DLLNode(data);
        if (head == null) {
            node.next = null;
            node.previous = null;
            head = node;
        } else {
            DLLNode currNode = head;
            while (currNode.next != null) {
                currNode = currNode.next;
            }
            currNode.next = node;
            node.previous = currNode;
        }
    }

    public void printElements() {
        DLLNode curNode;
        if (head != null) {
            curNode = head;
            System.out.print("element::=> " + curNode.data + " ");
            while (curNode.next != null) {
                curNode = curNode.next;
                System.out.print(curNode.data + "  ");
            }
            System.out.println();
        }

    }

    public void deleteAtFirst() {
        if (head != null) {
            DLLNode temp = head.next;
            head = temp;
        }
    }
}
