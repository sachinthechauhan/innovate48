package linkedlistoperation;

import linkedlistoperation.LinkedList.Node;

public class FindMiddleOFLinkedList {

    /**
     * Give at least four elemnts........
     * @param lList
     */
    public static void middleOfLinkedList(LinkedList lList) {
        Node currNode = lList.head;
        Node lastNode = lList.head;
        while (currNode.next != null && lastNode.next != null) {
            currNode = currNode.next;
            if (currNode.next != null && currNode.next.next != null) {
                lastNode = currNode.next.next;
            }
        }
        System.out.println(":::Middel of list::" + currNode.data);

    }

    public static void main(String[] args) {

        LinkedList linkedList = new LinkedList();
        linkedList.add(1);
        linkedList.add(2);
        linkedList.add(3);
        linkedList.add(4);
        linkedList.add(5);
        linkedList.add(6);
        middleOfLinkedList(linkedList);
    }

}
