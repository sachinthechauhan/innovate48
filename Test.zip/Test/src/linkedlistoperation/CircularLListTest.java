package linkedlistoperation;

public class CircularLListTest {

    public static void main(String[] args) {
        CircularLList cLList = new CircularLList();
        cLList.add(34);
        cLList.add(35);
        cLList.add(36);
        cLList.print();
        cLList.addFirst(33);
        System.out.println(":::addimng first:::");
        cLList.print();
        //        System.out.println(":::length before del::" + cLList.length);
        //        System.out.println(":::Delete last node:::");
        //        cLList.deleteLast();
        //        cLList.print();
        //        System.out.println(":::length::" + cLList.length);
        //        //		System.out.println(":::contains test 36::"+cLList.contains(36));
        //        System.out.println(":::contains test 34::" + cLList.contains(34));

    }

}
