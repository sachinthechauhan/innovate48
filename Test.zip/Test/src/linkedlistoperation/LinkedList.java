package linkedlistoperation;

import java.util.ArrayList;
import java.util.List;

public class LinkedList {
    Node head;

    int length;

    static class Node {
        int data;

        Node next;

        public Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public void add(int data) {
        Node node = new Node(data);
        if (head == null) {
            head = node;
        } else {
            Node last = head;
            while (last.next != null) {
                last = last.next;
            }
            last.next = node;
        }
        length++;
    }

    public void delete(int data) {
        if (head != null) {
            Node currNode = head;
            Node temp;
            Node prevNode = null;
            if (head.data == data) {
                // if head is target
                temp = head.next;
                head = temp;
            } else {
                while (currNode.data != data) {
                    prevNode = currNode;
                    currNode = currNode.next;
                }
                // last element of list
                if (prevNode.next.data == data && prevNode.next.next == null) {
                    prevNode.next = null;
                } else {
                    // found element in middle
                    prevNode.next = currNode.next;
                }
            }
            length--;
        }
    }

    /**
     * just modified the delete method as some diff code from delete method
     * @param data
     */
    public void deleteAttempt2(int data) {
        if (head != null) {
            Node currNode = head;
            Node temp;
            Node prevNode = head;
            if (head != null && head.data == data) {
                // if head is target
                temp = head.next;
                head = temp;
            } else {
                while (currNode.next != null && currNode.data != data) {
                    prevNode = currNode;
                    currNode = currNode.next;
                }
                // last element of list
                if (currNode.next == null) {
                    prevNode.next = null;
                } else {
                    // found element in middle
                    prevNode.next = currNode.next;
                }
            }
            length--;
        }
    }

    public void insertAtFirst(int data) {
        Node temp;
        temp = head.next;
        head = new Node(data);
        head.next = temp;
    }

    public void insertAtPositin(int index, int data) {
        Node node = getNode(index);
        Node newNode = new Node(data);
        newNode.next = node.next;
        node.next = newNode;
    }

    public void insertAtLast(int data) {
        Node currNode = null;
        currNode = head;
        while (currNode.next != null) {
            currNode = currNode.next;
        }
        currNode.next = new Node(data);
    }

    public Node getNode(int index) {
        // return the node <1 given index
        int length = 1;
        Node currNode = null;
        currNode = head;
        while (length < index && currNode.next != null) {
            currNode = currNode.next;
            length++;
        }
        return currNode;

    }

    public void deleteAtFirst(int data) {
        /*Node newNode = new Node(data);
        if (head != null) {
        	Node temp = head.next;
        	head = newNode;
        	newNode = temp;
        }*/
        if (head != null) {
            head = head.next;
        }
    }

    public void deleteAtPositin(int n) {
        // use start from 0 need to del n-1 elements.
        int index = 1;
        Node currNode = head;
        Node prevNode = null;

        while (currNode != null && index < n) {

            if (currNode.next != null) {
                prevNode = currNode;
                currNode = currNode.next;
            }
            index++;
        }
        // skip target elements
        if (prevNode != null && currNode != null && currNode.next != null) {
            prevNode.next = currNode.next;
        } else {
            prevNode.next = null;
        }

    }

    public void deleteAtLast(int data) {
        if (head != null) {
            Node currNode = head;
            while (currNode.next != null && currNode.next.next != null) {
                currNode = currNode.next;
            }
            currNode.next = null;
            ;
        }
    }

    public void printElements() {
        Node curNode;
        if (head != null) {
            curNode = head;
            System.out.print("element::=> " + curNode.data + " ");
            while (curNode.next != null) {
                curNode = curNode.next;
                System.out.print(curNode.data + "  ");
            }
        }

    }

    /**
     * reverse single  linked list
     */
    public void reverse() {
        Node currNode = head;
        Node prev = null;
        // set prev as head
        //		prev=head;
        while (currNode != null) {
            // save next node
            Node next = currNode.next;// save next node
            currNode.next = prev;// reverse the refrence
            prev = currNode;// move to prev node
            currNode = next;// move to current
        }
        head = prev;
    }

    /**
     * for reverse jusst find the last element and same assign to head
     */
    public void reverseAttempt2() {
        Node currNode = head;
        // set prev as head
        //      prev=head;
        while (currNode.next != null) {
            currNode = currNode.next;
        }
        // assign last node to head for reverse
        head = currNode;
    }

    public void sort() {
        Node currNode = head;
        Node prev = null;
        // set prev as head
        //		prev=head;
        while (currNode != null) {
            // save next node
            Node next = currNode.next;
            currNode.next = prev;
            prev = currNode;
            currNode = next;
        }
        head = prev;
    }

    /**
     * Middle of linked list 
     * 1->2->3->4->5->6 mid =4
     * @return
     */
    public int middleOfLinkedList() {
        Node currNode = head;
        Node midNode = head;// 

        while (currNode.next != null) {
            currNode = currNode.next;
            midNode = midNode.next;
            if (currNode.next != null) {
                currNode = currNode.next;
            }

        }

        return midNode.data;
    }

    /**
     * use for detect in loop
     * 
     * take two pointer , one move as first and second move with two..if list have loop
     * then one condition both pointer represt same address.
     * 
     * 
     */

    public boolean isHaveLoop() {
        Node slow = head;
        Node fast = head;

        while (slow != null && fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
            // If slow and fast meet at same point then loop is present 
            if (fast == slow) {
                return true;

            }

        }
        return false;

    }

    /**
     * If list have loop then remove loop from list
     * just take two pointer for take  reference of prev and next node
     * ASAP loop find then we mark as prevNode as null to break loop
     * 
     */

    public String removeLoop() {

        List<Integer> list = new ArrayList<>();

        Node currNode = head;
        Node prevNode;

        while (currNode != null && currNode.next != null) {
            list.add(currNode.data);
            prevNode = currNode;
            currNode = currNode.next;
            if (list.contains(currNode.data)) {
                prevNode.next = null;
                return "removed";
            }

        }
        return "No loop";

    }

    /**
     * Merge two sorted or unsorted linked list
     */
    public void mergeTwoList(LinkedList list1, LinkedList list2) {
        Node firstNode = list1.head;
        Node secNode = list2.head;

        /* a dummy first node to  
        hang the result on */
        Node dummyNode = new Node(0);

        /* tail points to the  
        last result node */
        Node tail = dummyNode;

        while (true) {
            /* if either list runs out,  
            use the other list */
            if (firstNode == null) {
                tail.next = secNode;
                break;
            }
            if (secNode == null) {
                tail.next = firstNode;
                break;
            }
            /* Compare the data of the two 
            lists whichever lists' data is  
            smaller, append it into tail and 
            advance the head to the next Node 
            */
            if (firstNode.data <= secNode.data) {
                tail.next = firstNode;
                firstNode = firstNode.next;
            } else {
                tail.next = secNode;
                secNode = secNode.next;
            }

            /* Advance the tail */
            tail = tail.next;

        }

        while (dummyNode.next != null) {
            System.out.println(dummyNode.data);
            dummyNode = dummyNode.next;

        }

    }

    public static void removeDuplicate(Node head) {

        Node current = head;
        Node temp;
        while (current != null) {
            temp = current;
            // remove all duplicate if exist
            while (temp != null && temp.data == current.data) {
                temp = temp.next;
            }
            // 
            current.next = temp;
            current = current.next;
        }

    }

}
