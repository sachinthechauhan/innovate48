import java.util.Scanner;

/**
 * Print in sinle line as even and odd charter of string
 * @author iid
 *
 */
public class Solution3 {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int n = scanner.nextInt();// number of string
        while (n > 0) {
            scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");
            String str = scanner.nextLine();
            String evenStr = "";
            String oddStr = "";
            char[] arr = str.toCharArray();
            for (int i = 0; i < arr.length; i++) {
                if (i % 2 == 0) {
                    evenStr += arr[i];
                } else {
                    oddStr += arr[i];
                }

            }
            System.out.println(evenStr + " " + oddStr);
            n--;
        }
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");
        scanner.close();
    }
}