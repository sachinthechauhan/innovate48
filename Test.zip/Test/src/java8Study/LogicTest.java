package java8Study;

public class LogicTest {

	public static int operation(int a, int b, Operation operation) {

		return operation.operation(a, b);
	}

}
