package java8Study;

import java.util.Arrays;
import java.util.List;

public class StreamTest {

    public static void main(String[] args) {
        /*
        		List<Integer> numList = Arrays.asList(12, 13, 45, 22, 67, 8, 33, 12);
        		// Print list
        		numList.forEach(e -> System.out.println(e));
        
        		// multiple each element by 2
        
        		numList.stream().map(e -> e * 2).forEach(e -> System.out.println("Element Mul By 2:: " + e));
        
        		// Remove duplicate element from list
        		numList.stream().distinct().forEach(e -> System.out.println("disinct element::" + e));*/

        List<String> dataList = Arrays.asList("sachin", "kumar", "rahul", "ravi", "hani", "yamal");

        /*List<String> dataList1 = dataList.stream().filter(e -> e.startsWith("r")).collect(Collectors.toList());
        System.out.println("::::" + dataList1);*/

        // lazy test of stream// will not print any thing untill not to add any terminal operation
        dataList.stream().filter(e -> e.startsWith("r")).peek(e -> System.out.println(e));
        ;

    }

}
