package java8Study;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public class Inventory {

	public static List<Apple> getGreenApple(List<Apple> apple, Predicate<Apple> predicate) {

		List<Apple> apples = new ArrayList<>();

		for (Apple apple2 : apple) {

			if (predicate.test(apple2)) {
				apples.add(apple2);
			}

		}
		return apples;
	};
}
