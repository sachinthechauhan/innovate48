package java8Study;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class ReductionTest {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(4, 5, 6, 7, 4, 5, 88);

		int sum = list.stream().reduce(0, (a, b) -> a + b);
		System.out.println(sum);
		boolean flag = list.stream().anyMatch(e -> e.intValue() == 5);
		System.out.println(flag);

		Integer arrSum = Stream.of(10, 12, 2).reduce(2, (x, y) -> x + y);
		System.out.println(arrSum);

		List<Integer> list2 = new ArrayList<>();

		Optional<Integer> arrSum2 = list2.stream().reduce((x, y) -> x + y);
		// System.out.println("arr Sum2::" + arrSum2.get());// error ae no such
		// element

		int val = list.stream().mapToInt(e -> e).sum();
		System.out.println("::::" + val);

	}

}
