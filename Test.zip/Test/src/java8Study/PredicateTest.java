package java8Study;

import java.util.function.Predicate;

public class PredicateTest {

    public static void main(String[] args) {

        Predicate<Integer> predicate = i -> i > 18;
        Predicate<Integer> lessThen = i -> i < 25;
        Predicate<Integer> greaterThen = i -> i > 20;
        Predicate<Long> tstLong = i -> i < 256;

        System.out.println(predicate.test(19));

        System.out.println(predicate.negate().test(19));

        System.out.println("Predicate Chain::" + lessThen.and(greaterThen).test(24));

        Predicate<Long> startRange = j -> j > 34;
        Predicate<Long> endRange = j -> j < 45;

        System.out.println(":::Test with AND::::" + startRange.and(endRange).test(36l));

        System.out.println(":::Test with OR::::" + startRange.or(endRange).test(12l));

        new Thread(() -> System.out.println(":::in thredaaa")).start();
    }

}
