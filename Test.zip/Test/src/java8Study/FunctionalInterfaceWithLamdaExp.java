package java8Study;

public class FunctionalInterfaceWithLamdaExp {

    @FunctionalInterface
    interface Operation {

        public int operation(int a, int b);

        default void print(String str) {
            System.out.println("Welcome::" + str);
        }

    }

    @FunctionalInterface
    interface HiTest {

        public void hi(String str);
    }

    public static void main(String[] args) {

        Operation operation = (int a, int b) -> {
            if (a > 0 && b > 0)
                return (a + b);
            return 0;
        };

        System.out.println(operation.operation(0, 6));
        operation.print("Sachin");

        HiTest hiTest = (s) -> System.out.println("Hi Beta" + s);

        hiTest.hi("Sachin KK");

    }
}