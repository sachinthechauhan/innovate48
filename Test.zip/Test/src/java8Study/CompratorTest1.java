package java8Study;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Apple o1, Apple o2
 * 
 * if o1-o2 then it is ascending order
 * or if o2-o1 then descending order
 * @author iid
 *
 */

public class CompratorTest1 {

    public static void main(String[] args) {

        List<Apple> list = Arrays.asList(new Apple("Green", 50), new Apple("Red", 60), new Apple("Light Green", 60),
                new Apple("Yellow Green", 10), new Apple("Light Green", 40), new Apple("Red", 42), new Apple("Red", 34),
                new Apple("Red", 40));

        Comparator<Apple> comparator = (Apple o1, Apple o2) -> o1.getWeight() - o2.getWeight();

        Collections.sort(list, comparator);
        //        list.stream().forEach(e -> System.out.println(e.getColor() + " " + e.getWeight()));
        // weight >40 and sort bases of weight
        //        list.stream().filter(e -> e.getWeight() > 40).sorted(Comparator.comparing(Apple::getWeight))
        //                .forEach(e -> System.out.println(e.getColor() + "  " + e.getWeight()));

        List<Integer> integers = Arrays.asList(100, 23, 500, 45, 300, 30);
        integers.stream().sorted(Comparator.comparingInt(Integer::intValue)).forEach(e -> System.out.println(e));

    }

}
