package java8Study;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

public class TestBehaviourWithJava2 {

    public static void main(String[] args) {

        List<Apple> apple = Arrays.asList(new Apple("Green", 50), new Apple("Red", 60), new Apple("Light Green", 60));

        Predicate<Apple> heavyWeight = (Apple a) -> a.getWeight() > 150;
        Predicate<Apple> greenApple = (Apple a) -> a.color.equalsIgnoreCase("green");
        Predicate<Apple> predicate = heavyWeight.and(greenApple);

        System.out.println(":>>>::" + Inventory.getGreenApple(apple, greenApple).size());
        System.out.println(":>>>::" + Inventory.getGreenApple(apple, heavyWeight).size());

    }

}
