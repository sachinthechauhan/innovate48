package java8Study;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@FunctionalInterface 
interface MyInterface{  
    void display();  
    public static void ThreadStatus(){  
        System.out.println("Thread is running...");  
    }  
}

 class Employee {

    String name;
    Integer age;
    BigDecimal salary;
    
    public Employee(String string, int i, BigDecimal valueOf) {
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public BigDecimal getSalary() {
		return salary;
	}
	public void setSalary(BigDecimal salary) {
		this.salary = salary;
	}
	

}

class ComparatorProvider {

    public int compareByAge(Employee o1, Employee o2) {
    	System.out.println(":::O1::"+o1);
        return o1.getAge().compareTo(o2.getAge());
    }

    public int compareByName(Employee o1, Employee o2) {
        return o1.getName().compareTo(o2.getName());
    }

    public int compareBySalary(Employee o1, Employee o2) {
        return o1.getAge().compareTo(o2.getAge());
    }

}

public class MethodRefTest {
	public static void saySomething(){  
        System.out.println("Hello, this is static method.");  
    }  

	public static void main(String[] args) {
		// static method Ref
		new Thread(MyInterface :: ThreadStatus).start();;
		
		// object method ref example
	     List<Employee> list = Arrays.asList(
	                new Employee("mkyong", 38, BigDecimal.valueOf(3800)),
	                new Employee("zilap", 5, BigDecimal.valueOf(100)),
	                new Employee("ali", 25, BigDecimal.valueOf(2500)),
	                new Employee("unknown", 99, BigDecimal.valueOf(9999)));
	     ComparatorProvider compProvider=new ComparatorProvider();
			/*
			 * list.sort(new Comparator<Employee>() {
			 * 
			 * @Override public int compare(Employee o1, Employee o2) { return
			 * o1.getAge().compareTo(o2.getAge()); } });
			 */
	     
//	     list.sort(compProvider :: compareByAge);
	     Collections.sort(list,new Comparator<Employee>() {

				@Override
				public int compare(Employee o1, Employee o2) {
					return o1.getAge().compareTo(o2.getAge());
				}
			});
	     
	     list.forEach(e-> System.out.print(e.getName()+ "::"+e.getAge()));
	}

}
