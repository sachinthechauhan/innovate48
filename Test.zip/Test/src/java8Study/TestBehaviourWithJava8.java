package java8Study;

public class TestBehaviourWithJava8 {

    public static void main(String[] args) {

        int sum = LogicTest.operation(5, 6, (int a, int b) -> a + b);
        int mul = LogicTest.operation(5, 6, (int a, int b) -> a * b);

        System.out.println("**********" + sum);

    }

}
