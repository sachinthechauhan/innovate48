package java8Study;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class CompratorTest3 {

    public static void main(String[] args) {

        List<Apple> list = Arrays.asList(new Apple("Green", 50), new Apple("Red", 60), new Apple("Light Green", 60),
                new Apple("Yellow Green", 10), new Apple("Light Green", 40), new Apple("Red", 42), new Apple("Red", 34),
                new Apple("Red", 40));

        // sort on bases of their weight

        List<Apple> sortList =
                list.stream().sorted(Comparator.comparing(Apple::getWeight)).collect(Collectors.toList());
        sortList.forEach(e -> System.out.println(e.getColor() + "::Weight::" + e.getWeight()));

    }

}
