package java8Study;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

class Person implements Comparable<Person> {
    private String name;

    private Integer age;

    private Date dob;

    public Person(String name, Integer age, Date dob) {
        super();
        this.name = name;
        this.age = age;
        this.dob = dob;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the age
     */
    public Integer getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(Integer age) {
        this.age = age;
    }

    /**
     * @return the dob
     */
    public Date getDob() {
        return dob;
    }

    /**
     * @param dob the dob to set
     */
    public void setDob(Date dob) {
        this.dob = dob;
    }

    @Override
    public int compareTo(Person o) {
        // TODO Auto-generated method stub
        return 0;
    }

}

public class ComparatorTest2 {

    public static void main(String[] args) {
        Calendar dob = Calendar.getInstance();
        Person person1 = new Person("Sachin", 18, dob.getTime());
        Person person5 = new Person("Sachin", 13, dob.getTime());
        Person person6 = new Person("Sachin", 12, dob.getTime());
        dob.add(Calendar.DATE, 5);
        Person person2 = new Person("Rajnesh", 32, dob.getTime());
        dob.add(Calendar.DATE, 6);
        Person person3 = new Person("Verma", 34, dob.getTime());
        dob.add(Calendar.DATE, 10);
        Person person4 = new Person("Kumar", 15, dob.getTime());
        dob.add(Calendar.DATE, 5);
        Person person7 = new Person("Kumar", 15, dob.getTime());
        dob.add(Calendar.DATE, 10);
        Person person8 = new Person("Kumar", 15, dob.getTime());

        List<Person> list = Arrays.asList(person1, person2, person3, person4, person5, person6, person7, person8);
        //        list.stream().forEach(e -> System.out.println(e.getName() + "  " + e.getAge() + "  " + e.getDob()));
        //        list.stream().sorted().forEach(e -> System.out.println(e.getName() + "  " + e.getAge() + "  " + e.getDob()));

        /* list.stream().sorted(Comparator.comparing(Person::getAge).thenComparing(Person::getName))
                .forEach(e -> System.out.println(e.getName() + "  " + e.getAge() + "  " + e.getDob()));
        ;*/

        Collections.sort(list);

        /**
         * Compare the object bases of their name 
         * if name equal then compare by age
         * if age equal then comapre by DOB
         */
        SimpleDateFormat fmt = new SimpleDateFormat("dd-MM-yyyy");
        list.stream()
                .sorted(Comparator.comparing(Person::getName).thenComparing(Person::getAge)
                        .thenComparing(Person::getDob))
                .forEach(e -> System.out.println(e.getName() + "  " + e.getAge() + "  " + fmt.format(e.getDob())));
        ;
    }

}
