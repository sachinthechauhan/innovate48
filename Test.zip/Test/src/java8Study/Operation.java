package java8Study;

@FunctionalInterface
public interface Operation {

	public int operation(int a, int b);
}
