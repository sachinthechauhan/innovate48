package java8Example;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class FlatMapTest3 {

    public static void main(String[] args) {
        List<String> list = Arrays.asList("5.6", "7.4", "4", "1", "2.3");

        //        list.stream().forEach(e -> System.out.println(e));

        List<List<Integer>> list2 = Arrays.asList(Arrays.asList(1, 2, 3), Arrays.asList(4, 5, 6));
        list2.stream().forEach(e -> System.out.println(e));
        list2.stream().flatMap(e -> e.stream()).forEach(e -> System.out.println(e));

        int[] intArray = { 1, 2, 3, 4, 5, 6 };

        //1. Stream<int[]>
        Stream<int[]> streamArray = Stream.of(intArray);

        //2. Stream<int[]> -> flatMap -> IntStream
        IntStream intStream = streamArray.flatMapToInt(x -> Arrays.stream(x));
    }

}
