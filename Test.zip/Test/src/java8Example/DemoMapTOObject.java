package java8Example;

import java.util.Arrays;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Custom mapper , as we can pass our custom logic in map object in java 8
 * 
 * @author iid
 *
 */

class Foo {
    private int a, b, c;

    public Foo(int a, int b, int c) {
        super();
        this.a = a;
        this.b = b;
        this.c = c;
    }

    /**
     * @return the a
     */
    public int getA() {
        return a;
    }

    /**
     * @param a
     *            the a to set
     */
    public void setA(int a) {
        this.a = a;
    }

    /**
     * @return the b
     */
    public int getB() {
        return b;
    }

    /**
     * @param b
     *            the b to set
     */
    public void setB(int b) {
        this.b = b;
    }

    /**
     * @return the c
     */
    public int getC() {
        return c;
    }

    /**
     * @param c
     *            the c to set
     */
    public void setC(int c) {
        this.c = c;
    }
}

class Bar {

    public Bar(int p, int q) {
        super();
        this.p = p;
        this.q = q;
    }

    private int p, q;

    /**
     * @return the p
     */
    public int getP() {
        return p;
    }

    /**
     * @param p
     *            the p to set
     */
    public void setP(int p) {
        this.p = p;
    }

    /**
     * @return the q
     */
    public int getQ() {
        return q;
    }

    /**
     * @param q
     *            the q to set
     */
    public void setQ(int q) {
        this.q = q;
    }
}

public class DemoMapTOObject {

    public static void main(String[] args) {

        List<Foo> list = Arrays.asList(new Foo(1, 2, 3), new Foo(4, 5, 6), new Foo(7, 8, 9));

        Function<Foo, Bar> changeObj = new Function<Foo, Bar>() {
            public Bar apply(Foo t) {
                return new Bar(t.getA(), t.getB());
            }

        };

        Function<Foo, Bar> customFun = new Function<Foo, Bar>() {

            @Override
            public Bar apply(Foo t) {
                // TODO Auto-generated method stub
                return new Bar(t.getA(), t.getB());
            }
        };

        /* Function<Bar, Foo> e=new Function<Bar, Foo>() {
        
            @Override
            public Foo apply(Bar t) {
                // TODO Auto-generated method stub
                return null;
            }
        };
        */
        List<Bar> barList = list.stream().map(changeObj).collect(Collectors.toList());

        barList.forEach(e -> System.out.println(e.getP()));

    }

}
