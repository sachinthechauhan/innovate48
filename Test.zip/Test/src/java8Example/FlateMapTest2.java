package java8Example;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

public class FlateMapTest2 {

    public static void main(String[] args) {

        List<String> list = Arrays.asList("sachin", "kumar");
        //        list.stream().forEach(e -> System.out.println(e));

        //
        Stream<List<String>> list2 = Stream.of(Arrays.asList("sachin", "kumar"), Arrays.asList("Pritam", "kumar"),
                Arrays.asList("Rahul", "kumar"));

        //        list2.forEach(e -> System.out.println(e.get(0)));
        //        list2.flatMap(e -> e.stream()).forEach(e -> System.out.println(e));

        int[] intArray = { 1, 6, 3, 5, 4, 0 };

        // 1. Stream<int[]>
        Stream<int[]> streamArray = Stream.of(intArray);
        streamArray.flatMapToInt(e -> Arrays.stream(e)).forEach(e -> System.out.println(e));

    }

}
