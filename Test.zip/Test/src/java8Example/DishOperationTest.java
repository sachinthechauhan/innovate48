package java8Example;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class DishOperationTest {

	public static void useOfAggrigateFunction(List<Dish> dishs) {

		// allMatch -> compare with all element with given condition.

		Boolean allMatch = dishs.stream().allMatch(e -> e.getCalories() < 801);

		System.out.println("Any Operation:  : " + allMatch);

		Optional<Dish> findAny = dishs.stream().filter(e -> e.getCalories() < 400).findAny();
		System.out.println("::Find Any:Match::" + findAny.get().getName());

	}

	public static void main(String[] args) {

		List<Dish> menu = Arrays.asList(new Dish("pork", false, 800, Dish.Type.MEAT),
				new Dish("beef", false, 700, Dish.Type.MEAT), new Dish("chicken", false, 400, Dish.Type.MEAT),
				new Dish("french fries", true, 530, Dish.Type.OTHER), new Dish("rice", true, 350, Dish.Type.OTHER),
				new Dish("season fruit", true, 120, Dish.Type.OTHER), new Dish("pizza", true, 550, Dish.Type.OTHER),
				new Dish("prawns", false, 300, Dish.Type.FISH), new Dish("salmon", false, 450, Dish.Type.FISH));

		// return the names of dishes that are low in calories (<400),
		// sorted by number of calories

		List<String> list = menu.stream().filter(e -> e.getCalories() < 400).map(e -> e.getName())
				.collect(Collectors.toList());
		// using by method refrence:

		List<String> list2 = menu.stream().filter(e -> e.getCalories() < 400).map(Dish::getName)
				.collect(Collectors.toList());

		list.forEach(e -> System.out.println(e));

		Map<String, List<Dish>> namesByDishName = menu.stream().collect(Collectors.groupingBy(Dish::getName));

		// System.out.println(namesByDishName);

		// Skip operation test
		List<String> skipList = menu.stream().filter(e -> e.getCalories() < 400).skip(0).map(Dish::getName)
				.collect(Collectors.toList());

		System.out.println(skipList);

		useOfAggrigateFunction(menu);

	}

}
