package mypack;

import java.text.ParseException;

public class Test {

    public static void main(String[] args) throws ParseException, ClassNotFoundException {

        int mask = 0x000F;
        int value = 0x2222;
        System.out.println(value & mask);

    }

}
