package mypack;

public class A2 {
    int add(int i, int j) {
        return i + j;
    }
}
