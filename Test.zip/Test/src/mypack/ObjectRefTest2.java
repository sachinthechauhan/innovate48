package mypack;

class TestVaribale {

}

public class ObjectRefTest2 {

	public static void main(String[] args) {

	}

}
