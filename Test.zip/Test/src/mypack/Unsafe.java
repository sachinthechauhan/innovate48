package mypack;

public class Unsafe {

	public static void main(String[] args) {

		/*
		 * Unsafe unsafe = new Unsafe(); System.out.println("addres of Obj=" +
		 * unsafe); unsafe = new Unsafe(); System.out.println(":::test again:::"
		 * + unsafe);
		 * 
		 * Unsafe unsafe1 = new Unsafe();
		 * 
		 * Unsafe unsafe2 = unsafe1;
		 * 
		 * System.out.println(unsafe1.equals(unsafe2));
		 */

		StringBuffer buffer1 = new StringBuffer();
		buffer1.append("sachin");
		StringBuffer buffer2 = new StringBuffer();
		buffer2.append("sachin");

		String str = "Sachin";

		System.out.println(str.contentEquals(buffer1));
		{
			int a = 5;
			System.out.println(":::" + a);
		}

		int c = 2023;
		int b = 2;
		long d = 2023;

		System.out.println(c == d);

	}

}
