package mypack;

import java.text.ParseException;
import java.util.Scanner;

/**
 * Take the second to print by scanner
 * 
 * @author iid
 *
 */

public class Problem1 {

	public static void main(String[] args) throws ParseException {
		System.out.println("Hello, World.");
		Scanner scan = new Scanner(System.in);
		System.out.println("" + scan.nextLine());
		scan.close();

	}

}
