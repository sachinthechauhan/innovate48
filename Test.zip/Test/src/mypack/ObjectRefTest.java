package mypack;

class Box {

	public Box(int length, int width, int height) {
		super();
		this.length = length;
		this.width = width;
		this.height = height;
	}

	int length;
	int width;
	int height;

}

public class ObjectRefTest {

	public static void main(String[] args) {

		Box box1 = new Box(2, 3, 4);
		Box box2 = new Box(2, 3, 4);
		// Box box2 = box1;
		System.out.println(box1.height == box2.height);

	}

}
