package sorting;

import java.util.Arrays;

/**
 * THis code working for all type of array to sort
 * 
 * @author iid
 *
 */
public class BubbleSortTest {

    static int minimumSwaps() {
        int[] arr = { 4, 3, 1, 2 };
        int swap = 0;
        boolean visited[] = new boolean[arr.length];

        for (int i = 0; i < arr.length; i++) {
            int j = i, cycle = 0;

            while (!visited[j]) {
                visited[j] = true;
                j = arr[j] - 1;
                cycle++;
            }

            if (cycle != 0)
                swap += cycle - 1;
        }
        return swap;
    }

    public static void bubbleSort() {

        int[] a = { 4, 3, 1, 2 };
        int swapCount = 0;
        int len = a.length;
        for (int i = 0; i < len - 1; i++) {
            System.out.println("pre::" + Arrays.toString(a));
            for (int j = 0; j < len - i - 1; j++) {
                if (a[j] > a[j + 1]) {
                    swapCount++;
                    int temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;

                }
            }
        }
        System.out.println("Array is sorted in " + swapCount + " swaps.");
        //		System.out.println("" + a[0]);
        //		System.out.println("" + a[a.length - 1]);

        System.out.println(Arrays.toString(a));
    }

    public static void main(String[] args) {
        BubbleSortTest.bubbleSort();
        //        System.out.println("" + minimumSwaps());
    }

}
