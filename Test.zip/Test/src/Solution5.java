class Person {
    protected String firstName;

    protected String lastName;

    protected int idNumber;

    // Constructor
    Person(String firstName, String lastName, int identification) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.idNumber = identification;
    }

    // Print person data
    public void printPerson() {
        System.out.println("Name: " + lastName + ", " + firstName + "\nID: " + idNumber);
    }

}

class Student extends Person {
    private int[] testScores;

    /*  
    *   Class Constructor
    *   
    *   @param firstName - A string denoting the Person's first name.
    *   @param lastName - A string denoting the Person's last name.
    *   @param id - An integer denoting the Person's ID number.
    *   @param scores - An array of integers denoting the Person's test scores.
    */
    // Write your constructor here

    public Student(String firstName, String lastName, int idNumber, int[] testScores) {
        super(firstName, lastName, idNumber);
        this.testScores = testScores;
    }

    /*  
    *   Method Name: calculate
    *   @return A character denoting the grade.
    */
    // Write your method here
    public char calculate() {
        java.util.OptionalDouble value = java.util.Arrays.stream(testScores).average();
        double marks = value.getAsDouble();
        if (marks >= 90 && marks <= 100) {
            return 'O';
        } else if (marks >= 80 && marks < 90) {
            return 'E';
        } else if (marks >= 70 && marks < 80) {
            return 'A';
        } else if (marks >= 55 && marks < 70) {
            return 'P';
        } else if (marks >= 40 && marks < 55) {
            return 'D';
        } else {
            return 'T';
        }
    }

}

class Solution5 {

    static int factorial(int n) {

        return 0;

    }

    public static void main(String[] args) {
        System.out.println(":::i main main:::");
    }
}