package common;

import java.util.Arrays;
import java.util.List;

public class JoinString {

	public static void main(String[] args) {

		List<String> list = Arrays.asList("java", "python", "nodejs", "ruby");
		// java, python, nodejs, ruby
		String result = String.join(", ", list);
		System.out.println(result);

		String result2 = String.join("- ", "sachin", "kumar");

	}

}
