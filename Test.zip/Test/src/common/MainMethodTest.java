package common;

public class MainMethodTest {

    protected MainMethodTest() {
        System.out.println(":::in constructor::::");
    }

    { // during object initilization
        System.out.println(":::in block");
    }

    static {// compile team

        System.out.println(":::in static block");
    }

    public static void main(String[] args) {
        //        MainMethodTest mainMethodTest = new MainMethodTest();
    }

    public static void main(Integer[] args) {
        MainMethodTest mainMethodTest = new MainMethodTest();
    }
}
