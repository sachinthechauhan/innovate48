package common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ReverseList {

    public static void main(String[] args) {

        List<Integer> list = Arrays.asList(1, 2, 3, 4);
        //        list.stream().
        //        Collections.reverse(list);
        System.out.println(list);

        List<Integer> revList = new ArrayList<>();
        int size = list.size() - 1;
        for (int i = size; i >= 0; i--) {
            revList.add(list.get(i));
        }

        System.out.println("::::list:::" + revList);

        // second attempt by using set method
        list = Arrays.asList(7, 8, 9, 10);
        size = list.size() - 1;
        for (int i = 0; i <= size / 2; i++) {
            int temp = list.get(i);
            list.set(i, list.get(size));
            list.set(size, temp);
            size--;
        }
        System.out.println("::rev list::" + list);

        // reverse list using java 8
        System.out.println(":::JAVA 8::::");

        list = Arrays.asList(7, 8, 9, 10);
        list = list.stream().sorted(Comparator.reverseOrder()).collect(Collectors.toList());
        System.out.println("::::" + list);

    }

}
