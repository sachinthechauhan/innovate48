package common;

import java.util.concurrent.Semaphore;

/**
 *  * <p>Semaphores are often used to restrict the number of threads than can
 * access some (physical or logical) resource.
 * 
        ==> A semaphore maintains a counter to specify the number of
            resources that the semaphore controls. 


        ==> If counter > 0 then access to resource is allowed 
            If counter == 0 indicate no resource is available, access is denied


        ==>  Method acquire() and release() are for acquiring and 
          releasing resources from a semaphore

        ==> If a thread calls acquire() and the counter is zero 
            (i.e., resources are unavailable), the thread waits
             until the counter is non-zero and then gets the resource for use.

        ==> Once the thread is done using the resource, it calls release() to 
            increment the resource availability counter
 * @author iid
 *
 */
class Person extends Thread {

    String name;

    Semaphore atm;

    public Person(String name, Semaphore semaphore) {
        this.name = name;
        this.atm = semaphore;
        this.start();
    }

    @Override
    public void run() {
        System.out.println("::::available permit:::" + atm.availablePermits());
        System.out.println(name + "::enter in room");
        try {
            atm.acquire();

            System.out.println(name + ":::::Widhdrawl money...");
            Thread.sleep(5000);
            atm.release();
            System.out.println(name + ":::out...");
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}

public class SemaphoreTest {

    public static void main(String[] args) {
        Semaphore semaphore = new Semaphore(1);
        Person person = new Person("Sachin", semaphore);
        Person person1 = new Person("Pritam", semaphore);
        Person person2 = new Person("Kumar", semaphore);
        Person person3 = new Person("verma", semaphore);

    }

}
