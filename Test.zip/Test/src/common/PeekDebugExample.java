package common;

import java.util.stream.Stream;

public class PeekDebugExample {

	public static void main(String[] args) {
		/*
		 * List<Integer> result = Stream.of(2, 3, 4, 5).peek(x ->
		 * System.out.println("taking from stream: " + x)) .map(x -> x +
		 * 17).peek(x -> System.out.println("after map: " + x)).filter(x -> x %
		 * 2 == 0) .peek(x -> System.out.println("after filter: " + x)).limit(3)
		 * .peek(x -> System.out.println("after limit: " +
		 * x)).collect(Collectors.toList());
		 */

		Stream.of("bus", "car", "bycle", "flight", "train").filter(e -> e.length() > 3)
				.peek(e -> System.out.println("Filtered value: " + e)).map(String::toUpperCase)
				.peek(e -> System.out.println("Mapped value: " + e)).forEach(e -> System.out.println(">>>>" + e));
	}

}
