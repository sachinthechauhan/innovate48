package common;

class String1 {
    private final String str;

    public String1(String str) {
        this.str = str;
    }

}

public class StringClass {

    public static void main(String[] args) {

        int a = 10 + 20;
        System.out.println(a);
    }

}
