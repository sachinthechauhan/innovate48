package common;

/**
 * only public, abstract, default, static methods allow in interface
 * @author iid
 *
 */
interface Demo {

    public static final int a = 45;

    public static int a2 = 45;

    static int a3 = 45;
    //     private int a4=45;// CE

    public void test1();

    //    public static void test2();// CE error
    //    public final void test3();// CE

    default void test() {
        System.out.println(":::in test of default");
    }

    public static void test4() {
        System.out.println(":::in test 4");
    }

}

class IntDemoImpl implements Demo {

    @Override
    public void test1() {
        System.out.println("::;;in overirde method:::");

    }

    public static void test4() {
        System.out.println(":::in test 4");
    }
}

public class InterfaceDemoTest {

    public static void main(String[] args) {

    }

}
