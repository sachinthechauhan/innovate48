package common;

public class RejexTest {

	public static void main(String[] args) {
		String str = "N";
		System.out.println("Using String matches method: " + str.matches("N|| "));
		// System.out.println("Using Pattern matches method: " +
		// Pattern.matches(".bb", str));
	}

}
