package common;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

class Item {

	private String name;
	private int qty;
	private BigDecimal price;

	public Item(String name, int qty, BigDecimal price) {
		super();
		this.name = name;
		this.qty = qty;
		this.price = price;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the qty
	 */
	public int getQty() {
		return qty;
	}

	/**
	 * @param qty
	 *            the qty to set
	 */
	public void setQty(int qty) {
		this.qty = qty;
	}

	/**
	 * @return the price
	 */
	public BigDecimal getPrice() {
		return price;
	}

	/**
	 * @param price
	 *            the price to set
	 */
	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	// constructors, getter/setters
}

public class GroupByCountExample2 {

	public static void main(String[] args) {

		List<Item> items = Arrays.asList(new Item("apple", 10, new BigDecimal("9.99")),
				new Item("banana", 20, new BigDecimal("19.99")), new Item("orang", 10, new BigDecimal("29.99")),
				new Item("watermelon", 10, new BigDecimal("29.99")), new Item("papaya", 20, new BigDecimal("9.99")),
				new Item("apple", 10, new BigDecimal("9.99")), new Item("banana", 10, new BigDecimal("19.99")),
				new Item("apple", 20, new BigDecimal("9.99")));
		// counting of item

		Map<String, Long> map = items.stream().collect(Collectors.groupingBy(Item::getName, Collectors.counting()));
		System.out.println(":::" + map);
		// Group by + Count
		// {
		// papaya=1, banana=2, apple=3, orang=1, watermelon=1
		// }

		// sum of quantity item wise

		Map<String, Long> map2 = items.stream()
				.collect(Collectors.groupingBy(Item::getName, Collectors.summingLong(Item::getQty)));

		System.out.println("::Item sumby quantity:::" + map2);
		// Group by + Sum qty
		// {
		// papaya=20, banana=30, apple=40, orang=10, watermelon=10
		// }

		// group by price, uses 'mapping' to convert List<Item> to Set<String>

		Map<BigDecimal, List<String>> map3 = items.stream()
				.collect(Collectors.groupingBy(Item::getPrice, Collectors.mapping(Item::getName, Collectors.toList())));

		System.out.println(":::" + map3);

	}

}
