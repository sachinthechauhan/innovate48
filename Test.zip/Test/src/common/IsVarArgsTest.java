package common;

public class IsVarArgsTest {

    public static void test(int... a) {
        for (int i : a) {
            System.out.print(i + " ");
        }
    }

    public static void test2(String str, int... a) {
        System.out.print(":::" + str + " ");
        for (int i : a) {
            System.out.print(i + " ");
        }
    }

    public static void main(String[] args) {
        //        IsVarArgsTest.test(4, 5, 67, 8);
        IsVarArgsTest.test2("all integer", 4, 5, 67, 8);
    }

}
