package common;

import java.util.concurrent.CountDownLatch;

/**
 * * A synchronization aid that allows one or more threads to wait until
 * a set of operations being performed in other threads completes.
 * @author iid
 * 
        ==> This synchronizer allows one or more threads to wait 
           for a countdown to complete

        ==> This countdown could be for a set of events to happen or 
            until a set of operations being performed in other threads completes

        Ex:
        this class simulates the start of a running race by counting down from 5. 
        It holds three runner threads to be ready to start in the start line of the race 
        and once the count down reaches zero, all the three runners start running...
 *
 */

class RunnerTest extends Thread {

    String name;

    CountDownLatch countDown;

    public RunnerTest(String name, CountDownLatch countDown) {
        this.name = name;
        this.countDown = countDown;
        this.start();
    }

    @Override
    public void run() {
        System.out.println(name + "::participate in room..");
        try {
            countDown.await();
            System.out.println(name + ":::runningggggg...");
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

}

public class CountDownLatchTest {

    public static void main(String[] args) {
        CountDownLatch countDownLatch = new CountDownLatch(3);// 3 is count value
        RunnerTest runner1 = new RunnerTest("Sachin", countDownLatch);
        RunnerTest runner2 = new RunnerTest("Pritam", countDownLatch);
        RunnerTest runner3 = new RunnerTest("Kumar", countDownLatch);
        RunnerTest runner4 = new RunnerTest("Sharma", countDownLatch);
        long countVal = countDownLatch.getCount();
        while (countVal > 0) {

            if (countVal == 1) {
                System.out.println(":::Race going to start now......");
            }
            countDownLatch.countDown();
            System.out.println("::::countdown::" + countVal);
            countVal = countDownLatch.getCount();
        }

    }

}
