package common;

class FinalDemo {
    final int i = 10;
}

//class FinalDemo2 extends FinalDemo // error: The type FinalDemo2 cannot subclass the final class FinalDemo

public class FinalClassTest {

    public static void main(String[] args) {
        final FinalDemo demo = new FinalDemo();
        System.out.println(demo.i);
    }

}
