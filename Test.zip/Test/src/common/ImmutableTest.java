package common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

final class Immutable {

    private final String name;

    private final Integer age;

    private final Date dob;

    private final List<String> hobbies;

    public Immutable(String name, Integer age, Date dob, List<String> hobbies) {
        super();
        this.name = name;
        this.age = age;
        this.dob = dob;
        this.hobbies = hobbies;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @return the age
     */
    public Integer getAge() {
        return age;
    }

    /**
     * @return the dob
     */
    public Date getDob() {
        return new Date(this.dob.getTime());
    }

    /**
     * @return the hobbies
     */
    public List<String> getHobbies() {
        return Collections.unmodifiableList(hobbies);
    }

}

public class ImmutableTest {

    public static void main(String[] args) {
        List<String> hobbies = new ArrayList<>();
        hobbies.add("Sachin");
        hobbies.add("Kumar");
        hobbies.add("Sachin1");
        Date dob = new Date();

        Immutable immutable = new Immutable("Sachin", 42, dob, hobbies);
        //        immutable.getHobbies().add("Sachinkk");//Exception in thread "main" java.lang.UnsupportedOperationException
        Date d2 = new Date(2323223232L);
        immutable.getDob().setTime(d2.getTime());
        System.out.println(immutable.getHobbies());
        System.out.println(immutable.getDob());

    }

}
