package common;

import java.io.UnsupportedEncodingException;
import java.util.Base64;

public class Base64EncodeDecodeTest {

	public static void main(String[] args) throws UnsupportedEncodingException {

		String str = "my name is sachin";

		System.out.println(":::Encoded String----");
		String encodeStr = Base64.getEncoder().encodeToString(str.getBytes());
		System.out.println(encodeStr);
		byte[] deCodeStr = Base64.getDecoder().decode(encodeStr);
		System.out.println("Original String: " + new String(deCodeStr, "utf-8"));

	}

}
