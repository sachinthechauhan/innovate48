package common;

public interface TestInterface {

    public int sum();

    abstract void kk();
}
