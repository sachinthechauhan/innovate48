package common;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class GroupByCountExample1 {

	public static void main(String[] args) {
		List<String> items = Arrays.asList("apple", "apple", "banana", "apple", "orange", "banana", "papaya");

		Map<String, List<String>> map = items.stream().collect(Collectors.groupingBy(Function.identity()));

		System.out.println("::::" + map);
		// {papaya=[papaya], orange=[orange], banana=[banana, banana],
		// apple=[apple, apple, apple]}

		Map<String, Long> map2 = items.stream()
				.collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));

		System.out.println(map2);
		// {papaya=1, orange=1, banana=2, apple=3}

	}

}
