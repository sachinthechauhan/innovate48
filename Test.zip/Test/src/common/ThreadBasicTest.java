package common;

/**'
 * display1 and display 2 both method are sycn so at a time one thread 
 * can access one method as in case of 
 * sync object level lock will work
 * 
 * @author iid
 *
 */
public class ThreadBasicTest {

    public void display4() {
        synchronized (ThreadBasicTest.class) {
            System.out.println(":::display 4:");

        }
        System.out.println("::::done d4");
    }

    public void display5() {
        synchronized (this) {
            System.out.println(":::display 5:");

        }
        System.out.println("::::done d5");
    }

    public synchronized void display1() {
        System.out.println(":::display 1:");

        System.out.println("::::done d1");
    }

    public synchronized void display2() {
        System.out.println(":::display 2:");

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("::::done d2");
    }

    public static synchronized void display3() {
        System.out.println(":::display 3:");
        System.out.println(":::done 3:");
    }

    public static void main(String[] args) {

        ThreadBasicTest test4 = new ThreadBasicTest();

        Thread t1 = new Thread(new Runnable() {

            @Override
            public void run() {
                test4.display1();

            }
        });

        Thread t2 = new Thread(new Runnable() {

            @Override
            public void run() {
                test4.display2();

            }
        });

        Thread t3 = new Thread(new Runnable() {

            @Override
            public void run() {
                test4.display3();

            }
        });

        Thread t4 = new Thread(new Runnable() {

            @Override
            public void run() {
                test4.display4();

            }
        });

        t2.start();
        t1.start();
        //        t3.start();
        t4.start();

    }

}
