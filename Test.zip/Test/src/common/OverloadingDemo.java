package common;

public class OverloadingDemo {

    public void display() {
        System.out.println(":::in deafult Display:1:::");
    }

    public void display(int a) {
        System.out.println(":::in deafult Display:2:::");
    }

    public void display(long b) {
        System.out.println(":::in deafult Display:3:::");
    }

    public void display(int a, long b) {
        System.out.println(":::in deafult Display::4::");
    }

    public void display(long b, int a) {
        System.out.println(":::in deafult Display::5::");
    }

    public static void main(String[] args) {

        //        new OverloadingDemo().display(2000000000, 20);// CE error as method showing ambigous
    }

}
