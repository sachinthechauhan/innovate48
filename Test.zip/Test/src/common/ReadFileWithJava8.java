package common;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;

public class ReadFileWithJava8 {

    public static void main(String[] args) throws IOException {
        //        readFileWithJava8();
        sortFileWithName();

    }

    public static void sortFileWithName() {

        File file = new File("/home/iid/Desktop/sachin/java8/");

        //        file.isFile()
        //        file.isHidden()
        //        file.exists();

        if (file.isDirectory()) {
            List<String> list = Arrays.asList(file.list());
            Collections.sort(list);
            list.stream().forEach(e -> System.out.println(e));
        }

    }

    /**
     * 
     */
    private static void readFileWithJava8() {
        try (Stream<String> fileStream = Files.lines(Paths.get("/home/iid/Desktop/sachin/java8/test.txt"))) {
            fileStream.forEach(e -> System.out.println(e));

            //            fileStream.map(e -> e.toUpperCase()).forEach(e -> System.out.println(e));

        } catch (Exception e2) {
            e2.printStackTrace();
        }
    }

}
