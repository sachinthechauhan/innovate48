package common;

class PersonName {
    PersonName() {
        System.out.println("Default Constructor PersonName");
    }

    public void display() {
        System.out.println(":::in display method:::");
    }

}

public class CreateObjectTest {

    public static void main(String[] args)
            throws InstantiationException, IllegalAccessException, ClassNotFoundException {

        PersonName name = (PersonName) Class.forName("common.PersonName").newInstance();
        System.out.println(Class.forName("common.PersonName").isInstance(name));

    }

}
