package common;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.LongPredicate;
import java.util.stream.LongStream;

public class ParallelStreamTest {

	public static void main(String[] args) {

		LongPredicate isPrime = PrimeNumbers::isPrime;
		long numOfPrimes = LongStream.rangeClosed(2, 100_000).parallel().filter(isPrime).count();
		// System.out.println("::::" + numOfPrimes);

		long numOfPrimes1 = LongStream.rangeClosed(2, 100_000).sequential().filter(isPrime).count();
		// System.out.println("::::" + numOfPrimes1);

		List<Integer> list = Arrays.asList(12, 34, 13, 78, 56, 3);
		list.parallelStream().filter(e -> e % 2 == 0).forEach(e -> System.out.print(e + " "));

		System.out.println(":::simple stream:::::::");
		list.stream().filter(e -> e % 2 == 0).forEach(e -> System.out.print(e + "  "));

		String words[] = "the quick brown fox jumps over the lazy dog".split(" ");

		Optional<String> originalString = (Arrays.stream(words).parallel().reduce((a, b) -> a + " " + b));

		System.out.println(originalString.get());
		;

		System.out.println(Runtime.getRuntime().availableProcessors());
		;
	}

}
