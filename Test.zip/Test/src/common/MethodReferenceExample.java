package common;

public class MethodReferenceExample {
    void close() {
        System.out.println("Close.");
    }

    public void display() {
        System.out.println(":::in display......");
    }

    public static void main(String[] args) throws Exception {
        MethodReferenceExample referenceObj = new MethodReferenceExample();

        try (AutoCloseable ac = referenceObj::display) {
        }
    }
}
