package common;

import java.util.Arrays;
import java.util.List;

public class IdentityDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String> listStr = Arrays.asList("one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
				"ten");

		String str = listStr.stream().reduce("ZZ", (a, b) -> a + b);

		System.out.println("::::" + str);

		String str2 = listStr.stream().map(s -> "{" + s + "}").reduce("ZZ", (a, b) -> a + b);

		System.out.println("::::" + str2);

		String str3 = listStr.parallelStream().map(s -> "{" + s + "}").reduce("ZZ", (a, b) -> a + b);

		System.out.println("::::" + str3);

		StringBuffer str4 = listStr.parallelStream().map(string -> new StringBuffer("{" + string + "}"))
				.reduce(new StringBuffer(), (a, b) -> a.append(b));

		System.out.println(":By Using appned:::" + str4.toString());

	}

}
