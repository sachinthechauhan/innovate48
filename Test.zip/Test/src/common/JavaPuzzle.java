package common;

import java.util.Locale;

public class JavaPuzzle {

    public static void main(String[] args) {
        System.out.println("Hi Guys!");
        /* Character myChar = new Character('\u000d');*/
        Locale.setDefault(new Locale("lt")); //setting Lithuanian as locale
        String str = "\u00cc";
        System.out.println("Before case conversion is " + str + " and length is " + str.length());// Ì
        String lowerCaseStr = str.toLowerCase();
        System.out.println("Lower case is " + lowerCaseStr + " and length is " + lowerCaseStr.length());// i?`
    }

}
