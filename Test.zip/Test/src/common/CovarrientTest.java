package common;

class A {

    public A fun() {
        System.out.println("i am in fun A");
        return new A();
    }

}

class B extends A {
    public B fun() {
        System.out.println("i am in fun B");
        return new B();
    }

}

public class CovarrientTest {

    public static void main(String[] args) {

    }

}
