package common;

import java.util.ArrayList;
import java.util.List;

class CloneTest implements Cloneable {
    public int a;

    public Integer b;

    public CloneTest cloneTest;

    public List<String> list = new ArrayList<>();

    public CloneTest() {
        this.a = 10;
        this.b = 20;
        list.add("sachin");
        /*this.cloneTest = new CloneTest();
        cloneTest.a = 50;
        cloneTest.b = 60;*/
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        /**
         * if we change the property of object , then it will also reflect original value of original object.
         */
        System.out.println("::in clone:::");
        //        b = 90;
        //        list.add("kumar");
        return super.clone();
    }

}

public class ClonableTest {

    public static void main(String[] args) throws CloneNotSupportedException {
        // test clone
        CloneTest obj1 = new CloneTest();
        // before clone
        System.out.println("::Object Property:1::" + obj1.a + "  " + obj1.b + "  " + obj1.list);
        CloneTest obj2 = (CloneTest) obj1.clone();

        if (obj1 == obj2) {
            System.out.println(":::in if same address");
        } else {
            System.out.println("::in else diff address...");
        }

        System.out.println("::::after cloneing::::");
        obj2.a = 33;
        obj2.b = 44;
        obj2.list.add("india");
        System.out.println("::Object Property:1::" + obj1.a + "  " + obj1.b + "  " + obj1.list);
        System.out.println("::Object Property:2::" + obj2.a + "  " + obj2.b + "   " + obj2.list);

    }

}
