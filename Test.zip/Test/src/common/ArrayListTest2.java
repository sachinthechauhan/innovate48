package common;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class AA {

}

class BB extends AA {

}

class CC extends BB {

}

class DD {

}

public class ArrayListTest2 {

    public static void main(String[] args) {

        List<? extends Number> foo3 = new ArrayList<Number>(); // Number "extends" Number (in this context)
        List<? extends Number> foo33 = new ArrayList<Integer>(); // Integer extends Number
        List<? extends Number> foo32 = new ArrayList<Double>(); // Double extends Number

        // type of list left and right side type both should be same.
        //        but at the time of adding in list, we can add same or child of given type
        List<AA> list = new ArrayList<>();
        list.add(new AA());
        list.add(new BB());
        list.add(new CC());

        List<? extends AA> list2 = new ArrayList<>();// use for reading
        list2 = Arrays.asList(new BB());
        System.out.println("::::" + list2.size());
        //        list2.add(new AA());// CE
        //        list2.add(new BB()); //CE

        List<? super AA> list3 = new ArrayList<>();
        list3.add(new AA());
        list3.add(new BB());
        list3.add(new CC());

    }
}
