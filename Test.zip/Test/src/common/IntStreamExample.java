package common;

import java.util.OptionalInt;
import java.util.stream.IntStream;

public class IntStreamExample {

	public static void main(String[] args) {

		IntStream.rangeClosed(2, 10).filter(e -> e % 2 == 0).forEach(e -> System.out.println(e));

		OptionalInt sum = IntStream.rangeClosed(2, 10).reduce((a, b) -> a + b);
		System.out.println(":::::" + sum.getAsInt());
		// Using some value as identity

		int sum2 = IntStream.rangeClosed(2, 10).reduce(1, (a, b) -> a + b);
		System.out.println(": Using Reduction with initial val:::" + sum2);

	}

}
