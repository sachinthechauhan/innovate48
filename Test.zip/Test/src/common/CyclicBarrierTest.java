package common;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

/**
 *  * A synchronization aid that allows a set of threads to all wait for
 * each other to reach a common barrier point.  CyclicBarriers are
 * useful in programs involving a fixed sized party of threads that
 * must occasionally wait for each other. The barrier is called
 * <em>cyclic</em> because it can be re-used after the waiting threads
 * are released.
 * 
 * => enables threads to wait at a predefined execution point

    => Let say he have to process huge database records and records are 
        divided in years.. 2011. we need to aggrigate one all year records are processed

    => We spawn 4 threads once all done control is transfered to another thread
 * @author iid
 *
 */
class Aggregator extends Thread {

    public void run() {
        System.out.println("::control is transfered to main thread...");
    };
}

class Database extends Thread {
    CyclicBarrier barrier;

    String name;

    public Database(String name, CyclicBarrier barrier) {
        this.name = name;
        this.barrier = barrier;
        this.start();
    }

    @Override
    public void run() {

        try {
            System.out.println("::::Processing .completd and waiting for other thread.." + name);
            barrier.await();
            System.out.println("::::Completed....." + name);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (BrokenBarrierException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}

public class CyclicBarrierTest {

    public static void main(String[] args) {

        CyclicBarrier barrier = new CyclicBarrier(3, new Aggregator());
        // count given as 3 and as first three thread wait and control tranfer to main thread.
        //        ...if the any other thread is waiitng..then same cycle repeat for waiting thread...
        Database database = new Database("Sachin", barrier);
        Database database2 = new Database("kumar", barrier);
        Database database3 = new Database("verma", barrier);

        Database database4 = new Database("sharma", barrier);
        Database database5 = new Database("Pritam", barrier);
        Database database6 = new Database("AK", barrier);

    }

}
