package common;

import java.util.stream.Stream;

public class StreamTest {

	public static void main(String[] args) {

		Stream<String> stream = Stream.of("sachin", "kumar");
		stream.forEach(e -> System.out.println(e));// OP: sachin kumar
		stream.forEach(e -> System.out.println(e));// throw Exception stream has
													// already been operated
													// upon or closed

	}

}
