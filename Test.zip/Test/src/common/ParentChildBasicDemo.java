package common;

class Parent {

    public int a = 20;

    private int a1 = 21;

    public static int a2 = 22;

    public static final int a3 = 25;

    public void display() {
        System.out.println("Parent::" + a + " " + a1 + " " + a2 + " " + a3);
    }

}

/*class Child extends Parent {

    public int a = 30;

    private int a1 = 31;

    public static int a2 = 32;

    public static final int a3 = 33;

    public void display() {
        System.out.println("Child " + a + " " + a1 + " " + a2 + " " + a3);
    }
}*/

class Child extends Parent {
    /**
      * we can change value of parent class variable 
      * by using constructor
      */
    Child() {
        a = 30;
        //        a1 = 31;// CE as a1 is private in paraent
        a2 = 32;
        //        a3 = 33; //        a1 = 31;// CE as a1 is final in paraent
        return;// no impact
    }

    public void display() {
        System.out.println("Child " + a + " " + a2 + " " + a3);
    }
}

public class ParentChildBasicDemo {

    public static void main(String[] args) {
        Child child = new Child();
        child.display();
        Parent parent = new Parent();
        parent.display();

    }

}
