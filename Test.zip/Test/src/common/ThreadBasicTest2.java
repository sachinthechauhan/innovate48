package common;

/**'
 * display1 and display 2 both method are sycn 
 * so at a time one thread can access one method as in case of 
 * sync class level lock will work
 * 
 * @author iid
 *
 */
public class ThreadBasicTest2 {

    public static synchronized void display2() {
        System.out.println(":::display 2:");

        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println("::::done d2");
    }

    public static synchronized void display3() {
        System.out.println(":::display 3:");
        System.out.println(":::done 3:");
    }

    public static void main(String[] args) {

        Thread t1 = new Thread(new Runnable() {

            @Override
            public void run() {
                ThreadBasicTest2.display2();

            }
        });

        Thread t2 = new Thread(new Runnable() {

            @Override
            public void run() {
                ThreadBasicTest2.display3();

            }
        });

        t1.start();
        t2.start();

    }

}
