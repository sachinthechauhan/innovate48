package common;

public class SwitchTest {

    public static void switchTest(int str) {

        switch (str) {
        case 1:
            System.out.println("Welcome 1.");
            //            break;
        case 2:
        case 4:
            System.out.println("Welcome 2.");
            //            break;
        case 3:
            System.out.println("Welcome 3.");
            //            break;
            //        default:
            //            System.out.println(":::in default case::");

        }

    }

    public static void switchTestWithString(String str) {

        switch (str) {
        case "sachin":
            System.out.println("Welcome 1.");
        case "kumar":
        case "chauhan":
            System.out.println("Welcome 2.");
        case "ok":
            System.out.println("Welcome 3.");
        default:
            System.out.println(":::in default case::");

        }

    }

    public static void main(String[] args) {
        //        switchTest(2);
        switchTestWithString("sachin");
    }

}
