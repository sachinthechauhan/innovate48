package common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.IntStream;

public class ListTest {

    public static void main(String[] args) {

        List<String> list = new ArrayList<>();
        list.add("sachin");
        list.add("kumar");
        list.add("verma");
        for (String string : list) {
            System.out.println("::::" + string);
        }

        IntStream.range(1, 100).filter(e -> e % 2 == 0).forEach(e -> System.out.println(e));

        List<String> list2 = new ArrayList<>();
        List<String> list3 = new ArrayList<>();
        List<String> list4 = new ArrayList<>();
        Collections.addAll(list2, "sachin", "kumar", "test");
        System.out.println("::::list2:elements:::" + list2);
    }

}
