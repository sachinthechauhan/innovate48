package common;

class TestOverRide {
    public String name;

    public Integer id;

    public Integer age;

    @Override
    public int hashCode() {
        int result = 1;
        int hash = 31;

        result = result * hash + this.name != null ? this.name.hashCode() : 0;
        result = result * hash + this.id != 0 ? this.id : 0;
        result = result * hash + this.age != 0 ? this.age : 0;

        return result;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null || obj.getClass() != this.getClass()) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        // match required property
        TestOverRide overRide = (TestOverRide) obj;
        return this.id == overRide.id && this.name.equals(overRide.name);

    }

}

public class OverrideEqualAndHashCode {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

}
