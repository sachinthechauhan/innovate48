package test.stack;

import java.util.Stack;

public class StackExample {

    public static void main(String[] args) {

        Stack<Integer> stack = new Stack<>();
        stack.add(11);
        stack.add(22);
        stack.add(33);
        stack.add(44);//
        stack.push(55);// internal working same as add method.
        System.out.println(":Print::" + stack);
        stack.pop();
        System.out.println(":Print::" + stack);
    }

}
