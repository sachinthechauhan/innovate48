package test.stack;

/**
 * 
 * https://www.geeksforgeeks.org/stack-data-structure-introduction-program/
 * 
 * https://docs.oracle.com/javase/7/docs/api/java/util/Stack.html
 * 
 * Stack is a linear data structure which follows a particular order in which the operations are performed. 
 * The order may be LIFO(Last In First Out) or FILO(First In Last Out).
 * 
 * Push: Adds an item in the stack. If the stack is full, then it is said to be an Overflow condition.
Pop: Removes an item from the stack. The items are popped in the reversed order in which they are pushed. If the stack is empty, then it is said to be an Underflow condition.
Peek or Top: Returns top element of stack.
isEmpty: Returns true if stack is empty, else false.
 * 
 * public class Stack<E>
extends Vector<E>

public class Vector<E>
    extends AbstractList<E>
    implements List<E>, RandomAccess, Cloneable, java.io.Serializable
    
    
    Object push(Object element) : Pushes an element on the top of the stack.
Object pop() : Removes and returns the top element of the stack. An ‘EmptyStackException’ exception 
is thrown if we call pop() when the invoking stack is empty.
Object peek() : Returns the element on the top of the stack, but does not remove it.
boolean empty() : It returns true if nothing is on the top of the stack. Else, returns false.
int search(Object element) : It determines whether an object exists in the stack. 
If the element is found, it returns the position of the element from the top of the stack. 
Else, it returns -1.
 * 
 * @author iid
 *
 */
class Stack {
    int[] arr;

    int max_size = 10;

    int index = 0;

    Stack(int size) {
        this.max_size = size;
        arr = new int[max_size];
    }

    public void push(int data) {
        if (index == max_size) {
            System.out.println(":::stack overfow:::");
            return;
        }
        arr[index++] = data;
    }

    public int pop() {
        if (index < 0) {
            System.out.println(":::stack is empty:::");
            return 0;
        }
        System.out.println("index val:::" + index);
        int data = arr[--index];
        return data;
    }

    public void printStac() {

        for (int i = 0; i < arr.length; i++) {
            System.out.println("Index:::" + i + "    Value::::" + arr[i]);
        }
    }

}

public class StackDemo {
    public static void main(String[] args) {

        Stack stack = new Stack(2);
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.printStac();
        stack.pop();
        stack.pop();
        //        stack.pop();

    }

}
