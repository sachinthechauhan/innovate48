package test.stack;

import java.util.Stack;

/**
 * https://www.techiedelight.com/find-duplicate-parenthesis-expression/
 * @author iid
 *
 */

public class CheckDuplicateParanthesis {

    // Function to find duplicate parenthesis in a  
    // balanced expression  

    //    Stack<Character> characters = new Stack<>();

    public static boolean checkDuplicatePranthesis(String exp) {
        Stack<Character> stack = new Stack<>();
        char[] arr = exp.toCharArray();

        for (char ch : arr) {

            if (ch == ')') {
                char top = stack.peek();
                stack.pop();

                int elementInsideCheck = 0;
                // stores the number of characters between a  
                // closing and opening parenthesis  
                // if this count is less than or equal to 1  
                // then the brackets are redundant else not  
                while (top != '(') {
                    // if current character is close parenthesis ')'
                    elementInsideCheck++;
                    top = stack.peek();
                    stack.pop();
                }

                if (elementInsideCheck < 1) {
                    return true;
                }

            } else {

                stack.push(ch);
            }

        }

        return false;

    }

    public static void main(String[] args) {
        String exp = "((x+y))";//false
        exp = "((a+b)+(c+d))";//false
        exp = "((a+b)+((c+d)))";//true
        CheckDuplicateParanthesis object = new CheckDuplicateParanthesis();
        System.out.println(object.checkDuplicatePranthesis(exp));
    }
}
