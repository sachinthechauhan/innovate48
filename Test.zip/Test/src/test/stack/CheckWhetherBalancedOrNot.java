package test.stack;

import java.util.Stack;

/**
 * https://hackernoon.com/code-challenge-find-whether-the-given-expression-is-balanced-d9cb9793bcf0
 * 
 * Time Complexity: O(n)
Auxiliary Space: O(n) for stack.


// if the size of stack is not zero then some closing bracket is missing
 * @author iid
 *
 */

public class CheckWhetherBalancedOrNot {

    /**
     * EXP: { [ ( ) ] }
     * @param exp
     */
    public void checkIsBalancedOrNot(String exp) {

        Stack<Character> stack = new Stack<>();

        char[] arr = exp.toCharArray();

        for (char ch : arr) {

            if (ch == '{' || ch == '(' || ch == '[') {
                stack.push(ch);
            } else {

                if (stack.isEmpty()) {
                    System.out.println(":::not balnced:::");
                    return;
                }
                if (!stack.empty()) {
                    char top = stack.peek();
                    if ((ch == '}' && top == '{')

                            || (ch == ')' && top == '(') || (ch == ']' && top == '[')) {
                        stack.pop();
                    } else {
                        // no need to traversed morw
                        System.out.println("::::not balanced:::");
                        return;
                    }
                }
            }

        }

        if (stack.isEmpty()) {
            System.out.println(":::::balanced");
        } else {
            System.out.println("::::not balanced:::");
        }

    }

    public static void main(String[] args) {
        CheckWhetherBalancedOrNot obj = new CheckWhetherBalancedOrNot();

        String exp = "{[(()]}";
        //        exp = "{[()]}";
        exp = "(((5))";
        obj.checkIsBalancedOrNot(exp);
    }

}
