package test.arm;

import java.io.Closeable;
import java.io.IOException;

/**
 * https://docs.oracle.com/javase/tutorial/essential/exceptions/tryResourceClose.html
 * @author iid
 *
 */

class Resource implements Closeable {

    @Override
    public void close() throws IOException {
        System.out.println("::Resource:in close ::done clean:::");

    }

}

class Resource2 implements AutoCloseable {

    @Override
    public void close() throws IOException {
        System.out.println("::Resource2:in close ::done clean:::");

    }

}

public class ResourceCleanTest {

    public static void main(String[] args) {
        try (Resource resource = new Resource(); Resource2 resource2 = new Resource2()) {

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}
