package test.thread;

import java.util.ArrayList;
import java.util.List;

public class EnumerationTest {

    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("Sachin");
        list.add("Kumar");
        list.add("Rahul");
        list.add("yamal");
        list.add("mahipal singh");
        list.add("hani");
        List subList = list.subList(2, 4);

        System.out.println("L:::::::" + subList);

        /*Enumeration<String> enumeration=Collections.enumeration(list);
        while (enumeration.hasMoreElements()) {
        	String string = (String) enumeration.nextElement();
        	System.out.println("::::"+string);
        	list.add("sachin1");
        	
        }*/

    }

}
