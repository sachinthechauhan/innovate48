package test.thread;

import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapTest {

    public static void main(String[] args) throws InterruptedException {
        ConcurrentHashMap<Integer, String> map = new ConcurrentHashMap<>();

        map.put(101, "A");
        map.put(102, "B");
        map.putIfAbsent(103, "C");
        map.remove(102, "d");// will not remove as K and V not matching

        System.out.println(":::::" + map);
        new Thread(new Runnable() {

            @Override
            public void run() {
                map.put(104, "Test CME");

            }
        }).start();
        // First way to iterate
        for (Integer integer : map.keySet()) {
            System.out.println("::::::" + map.get(integer));
            Thread.sleep(2000);
        }
    }

}
