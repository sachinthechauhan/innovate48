package test.thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Job2 implements Runnable {
    String name;

    public Job2(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        System.out.println(":::: " + name + " ...");
    }
}

public class ExecutorTest {
    public static void main(String[] args) {
        Job2[] runnables = { new Job2("Hello java"), new Job2("Hello java"), new Job2("Hello java") };

        ExecutorService service = Executors.newFixedThreadPool(3);
        for (Runnable r : runnables) {
            //			service.submit(r);
            service.execute(r);
        }
        service.shutdown();
    }
}
