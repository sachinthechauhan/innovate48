package test.thread;

import java.util.concurrent.CountDownLatch;

class Runner extends Thread {
    CountDownLatch countDownLatch;

    Runner() {

    }

    public void run() {
    };
}

public class CountDownLatchDemo2 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

}
