package test.thread;

import java.util.HashMap;
import java.util.Map;

class CustomMapKey {
    private String name;

    private int id;

    public CustomMapKey(String name, int id) {
        super();
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

}

public class MapKeyTest {

    public static void main(String[] args) {
        CustomMapKey obj = new CustomMapKey("SK", 34);
        CustomMapKey obj2 = new CustomMapKey("Sk2", 32);

        Map<CustomMapKey, Integer> map = new HashMap<>();
        map.put(obj, 12);
        map.put(obj2, 16);

        for (CustomMapKey val : map.keySet()) {
            System.out.println("::::::" + val.getId() + "::::::" + val.getName() + ":::" + map.get(val));
        }

    }

}
