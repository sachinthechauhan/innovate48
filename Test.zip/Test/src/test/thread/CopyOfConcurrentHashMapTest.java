package test.thread;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class CopyOfConcurrentHashMapTest {

    public static void main(String[] args) {
        ConcurrentHashMap<Integer, String> map = new ConcurrentHashMap<>();

        map.put(101, "A");
        map.put(102, "B");
        map.putIfAbsent(103, "C");
        map.remove(102, "d");// will not remove as K and V not matching

        System.out.println(":::::" + map);
        // First way to iterate
        for (Integer integer : map.keySet()) {
            System.out.println("::::::" + map.get(integer));
        }
        // second way to iterate

        // printing all keys and values pairs of ConcurrentHashMap System.out.println("Printing all keys and values of ConcurrentHashMap");
        for (Entry<Integer, String> entry : map.entrySet()) {
            Integer key = entry.getKey();
            String value = entry.getValue();
            System.out.println("key: " + key + " value: " + value);
        }
        Set<Entry<Integer, String>> entries = map.entrySet();
        Iterator<Entry<Integer, String>> iterator = entries.iterator();
        while (iterator.hasNext()) {
            Entry<Integer, String> entry = iterator.next();
            System.out.println("::::::::::" + entry.getKey() + ":::" + entry.getValue());

        }

    }

}
