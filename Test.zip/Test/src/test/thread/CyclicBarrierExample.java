package test.thread;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

class DatabaseProcessThread extends Thread {
    CyclicBarrier barrier;

    public DatabaseProcessThread(CyclicBarrier barrier, String name) {
        this.setName(name);
        this.barrier = barrier;
        this.start();
    }

    @Override
    public void run() {
        System.out.println(":::DB Process done by " + Thread.currentThread().getName());
        try {
            barrier.await();
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (BrokenBarrierException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}

class Aggretator implements Runnable {

    @Override
    public void run() {
        System.out.println(":::all task doen and control transfered to Main Thread");
    }

}

public class CyclicBarrierExample {

    public static void main(String[] args) {

        CyclicBarrier barrier = new CyclicBarrier(2, new Aggretator());
        new DatabaseProcessThread(barrier, "First");
        new DatabaseProcessThread(barrier, "Second");
        new DatabaseProcessThread(barrier, "Third");
        new DatabaseProcessThread(barrier, "Fourth");

    }

}
