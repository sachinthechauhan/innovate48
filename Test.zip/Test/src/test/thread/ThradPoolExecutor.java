package test.thread;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Job implements Runnable {
    String name;

    Job(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        System.out.println("::::Runnable Thread::" + name);

    }

}

class Job22 extends Thread {
    String name;

    Job22(String name) {
        this.name = name;
    }

    @Override
    public void run() {
        System.out.println("::::Extendable Thread::" + name);

    }

}

public class ThradPoolExecutor {

    public static void main(String[] args) {

        Thread thread = new Thread(new Job("sachin"));

        Job jb = new Job("sachin");
        Job22 jb2 = new Job22("Chauhan");

        Executor executor = Executors.newFixedThreadPool(5);
        executor.execute(thread);
        executor.execute(jb2);

        ExecutorService executor2 = Executors.newFixedThreadPool(5);
        executor2.submit(jb);
        executor2.submit(jb2);

    }

}
