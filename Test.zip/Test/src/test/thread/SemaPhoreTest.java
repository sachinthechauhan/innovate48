package test.thread;

import java.util.concurrent.Semaphore;

class Person extends Thread {
    Semaphore machine;

    public Person(Semaphore semaphore, String name) {
        this.machine = semaphore;
        this.setName(name);
        start();
    }

    @Override
    public void run() {
        try {
            System.out.println(Thread.currentThread().getName() + " ::waiting for enter room....");
            machine.acquire();
            System.out.println(":::First::::Available::::::::::::::::" + machine.availablePermits());
            System.out.println(Thread.currentThread().getName() + "  ::doing transaction........");
            Thread.sleep(2000);
            machine.release();
            System.out.println(Thread.currentThread().getName() + "  ::transaction completed...");
            System.out.println("::::END:::Available::::::::::::::::" + machine.availablePermits());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

}

public class SemaPhoreTest {
    public static void main(String[] args) {
        // Semaphore machine=new Semaphore(2);
        Semaphore machine = new Semaphore(1, true);// give the guarntee for FIFO
        new Person(machine, "Sachin");
        new Person(machine, "Meenakshi");
        new Person(machine, "Ishi");

    }

}
