package test.thread;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ProducerConsumerProblem {
    static BlockingQueue<Integer> blockingQueue = new ArrayBlockingQueue<>(1);

    public static void main(String[] args) throws InterruptedException {
        Thread producer = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    producer();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        });

        Thread consumer = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    consumer();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        });

        producer.start();
        consumer.start();
        //		producer.join();
        //		consumer.join();
    }

    public static void producer() throws InterruptedException {
        for (int i = 1; i < 10; i++) {
            System.out.println("Produce::" + i);
            blockingQueue.put(i);
        }
    }

    public static void consumer() throws InterruptedException {
        while (true) {
            System.out.println("Consume:::" + blockingQueue.take());
        }
    }

}
