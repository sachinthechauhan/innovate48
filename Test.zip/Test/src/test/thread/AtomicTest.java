package test.thread;

import java.util.concurrent.atomic.AtomicInteger;

class Counter {

    public static AtomicInteger atomicInteger = new AtomicInteger(0);

}

class Mythread extends Thread {

    @Override
    public void run() {
        System.out.println(currentThread().getName() + " DEC:: " + Counter.atomicInteger.decrementAndGet());
    }
}

class Mythread2 extends Thread {

    @Override
    public void run() {
        System.out.println(currentThread().getName() + "::INC: " + Counter.atomicInteger.incrementAndGet());
    }
}

public class AtomicTest {

    public static void main(String[] args) {

        for (int i = 0; i < 10; i++) {
            if (i % 3 == 0) {
                new Mythread().start();
            } else {
                new Mythread2().start();
            }
        }
        System.out.println("Final Latest Val::::" + Counter.atomicInteger);
    }

}
