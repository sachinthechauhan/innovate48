package test.thread;

class BlockingQueue {
    public int capacity;

    java.util.LinkedList<Object> queue = new java.util.LinkedList<>();

    public BlockingQueue(int capacity) {
        this.capacity = capacity;
    }

    public synchronized void enqueu(Object object) throws InterruptedException {
        while (queue.size() == capacity) {
            wait();
        }
        if (this.queue.size() == 0) {
            notifyAll();
        }
        queue.add(object);
        System.out.println(":::::enqueue::::");
    }

    public synchronized Object dequeue() throws InterruptedException {
        while (queue.size() == 0) {
            wait();
        }
        if (this.queue.size() == capacity) {
            notifyAll();
        }
        return queue.remove(0);
    }

}

public class BlockingQueueDemo2 {

    public static void main(String[] args) throws InterruptedException {
        BlockingQueue blockingQueue = new BlockingQueue(1);
        //		blockingQueue.enqueu("Sachin");
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    blockingQueue.enqueu("Sachin");
                    blockingQueue.enqueu("Ishin");
                    Thread.sleep(5000);
                    blockingQueue.enqueu("kkk kumar");
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        }).start();
        ;

        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    while (blockingQueue.capacity > 0) {
                        System.out.println(blockingQueue.dequeue());
                    }

                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
        }).start();
        ;

    }

}
