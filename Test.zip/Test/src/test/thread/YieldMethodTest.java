package test.thread;

/**
 * https://www.geeksforgeeks.org/java-concurrency-yield-sleep-and-join-methods/
 * @author Sachin Chauhan
 *
 */
class ThreadTest2 extends Thread {
    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println("::Test Thread::" + Thread.currentThread().getName() + "   "
                    + Thread.currentThread().getState() + "  " + Thread.currentThread().getPriority());
        }
    }
}

public class YieldMethodTest {

    public static void main(String[] args) throws InterruptedException {
        ThreadTest2 test2 = new ThreadTest2();
        test2.start();
        for (int i = 0; i < 5; i++) {
            Thread.yield();// pass to control child thread
            System.out.println("::Main Thread::" + Thread.currentThread().getName() + "   "
                    + Thread.currentThread().getState() + "   " + Thread.currentThread().getPriority());
        }
    }

}
