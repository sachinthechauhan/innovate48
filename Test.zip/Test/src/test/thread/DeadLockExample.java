package test.thread;

public class DeadLockExample {
    public static String resource1 = "Resource1";

    public static String resource2 = "Resource2";

    public static void main(String[] args) {

        Thread thread1 = new Thread() {

            @Override
            public void run() {
                synchronized (resource1) {
                    System.out.println(" Thread1 locker :resource1: ");
                    try {
                        Thread.sleep(10000);
                    } catch (InterruptedException e) {
                        System.out.println("::Thread 1 waiting for resource 2");
                    }
                    synchronized (resource2) {
                        System.out.println(" Thread1 locker :resource2: ");
                    }
                }

            }
        };

        Thread thread2 = new Thread(new Runnable() {

            @Override
            public void run() {
                synchronized (resource2) {
                    System.out.println(" Thread2 locker :resource2: ");
                    try {
                        Thread.sleep(10000);
                    } catch (InterruptedException e) {
                        System.out.println("::Thread 2 waiting for resource 1");
                    }
                    synchronized (resource2) {
                        System.out.println(" Thread2 locker :resource1: ");
                    }
                }

            }
        });

        thread1.start();
        thread2.start();

    }

}
