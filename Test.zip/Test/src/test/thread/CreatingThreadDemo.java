package test.thread;

class ThreadTest extends Thread {
    @Override
    public void run() {
        System.out.println("::Thread Test");
    }
}

class RunnableTest implements Runnable {

    @Override
    public void run() {
        System.out.println(
                "::Runnable Test::::::  " + Thread.currentThread().getName() + "::" + Thread.currentThread().getId());

    }

}

public class CreatingThreadDemo {
    public static void main(String[] args) {
        ThreadTest test = new ThreadTest();
        test.start();

        RunnableTest runnableTest = new RunnableTest();
        Thread thread = new Thread(runnableTest, "Runnable Thread");
        thread.start();

    }

}
