package test.thread;

import java.util.concurrent.CopyOnWriteArrayList;

public class CopyonWriteArrayListDemo {

    public static void main(String[] args) throws InterruptedException {

        attempt1();
    }

    public static void attempt2() throws InterruptedException {
        CopyOnWriteArrayList<String> arrayList = new CopyOnWriteArrayList<>();
        arrayList.add("Sachin");
        arrayList.add("Meenakshi");

        CopyOnWriteArrayList<String> arrayList2 = new CopyOnWriteArrayList<>(arrayList);

        for (String str : arrayList) {
            System.out.println("::::::" + str);
            Thread.sleep(2000);
        }
    }

    public static void attempt1() throws InterruptedException {
        CopyOnWriteArrayList<String> arrayList = new CopyOnWriteArrayList<>();
        arrayList.add("Sachin");
        arrayList.add("Meenakshi");
        new Thread(new Runnable() {
            @Override
            public void run() {
                System.out.println("::::hiii::::");
                arrayList.add("Ishi Chauhan");// this element will print
            }
        }).start();
        ;
        for (String str : arrayList) {
            Thread.sleep(2000);
            System.out.println("::output::::" + str);
            //            Thread.sleep(2000);
        }
    }
}
