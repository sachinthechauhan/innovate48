package test.thread;

import java.util.LinkedList;
import java.util.List;

/**
 * Introduced in Java 1.5 and written by Doug Lea
 * 
 * implementation of bounded queue..how this work internally
 * A blocking queue is a queue that blocks when you try to dequeue
 *  from it and the queue is empty, or if you try to enqueue 
 *  items to it 
 * and the queue is already full. A thread trying to dequeue 
 * from an empty queue is blocked until some other thread inserts
 *  an item into the queue. 
 * A thread trying to enqueue an item in a full queue is blocked 
 * until some other thread makes space in the queue, 
 * either by dequeuing one or 
 * more items or clearing the queue completely.
 * 
 * 
 * iF We see java implemnetaion ,
 * 
 * It have enqueue for insert and dequeue for delete
 * 
 * private void enqueue(E x) {
        // assert lock.getHoldCount() == 1;
        // assert items[putIndex] == null;
        final Object[] items = this.items;
        items[putIndex] = x;
        if (++putIndex == items.length)
            putIndex = 0;
        count++;
        notEmpty.signal();// for notify waiting thread..
    }
    
    
    private E dequeue() {
        // assert lock.getHoldCount() == 1;
        // assert items[takeIndex] != null;
        final Object[] items = this.items;
        @SuppressWarnings("unchecked")
        E x = (E) items[takeIndex];
        items[takeIndex] = null;
        if (++takeIndex == items.length)
            takeIndex = 0;
        count--;
        if (itrs != null)
            itrs.elementDequeued();
        notFull.signal();
        return x;
    }

    
 * 
 * @author iid
 *
 */
class BlockingQueueDemo {

    List<String> list = new LinkedList<>();

    private int limit_size;

    public BlockingQueueDemo(int val) {
        this.limit_size = val;
    }

    public synchronized void enQueue(String obj) {
        if (list.size() == limit_size) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (list.size() == 0) {
            notifyAll();
        }

        list.add(obj);
        System.out.println(Thread.currentThread().getName() + " enqueue  " + obj + "   size " + list.size());
    }

    public synchronized Object deQueue() {

        if (list.size() == 0) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        if (list.size() == this.limit_size) {
            notifyAll();
        }
        System.out.println(Thread.currentThread().getName() + " dequeue  " + list.get(0) + "   size " + list.size());
        return list.remove(0);
    }

    public void display() {

    }

}

class A3 {
    public void display() {

    }
}

public class BlockingQueueInternalWorking {

    public static void main(String[] args) {

        BlockingQueueDemo objectQueue = new BlockingQueueDemo(5);

        Thread producer = new Thread() {
            public void run() {
                for (int i = 0; i < 10; i++) {
                    objectQueue.enQueue("Object " + i);
                }

            };
        };

        Thread consumer = new Thread() {
            public void run() {
                while (true) {
                    objectQueue.deQueue();
                }

            };
        };
        producer.start();
        consumer.start();
    }

}
