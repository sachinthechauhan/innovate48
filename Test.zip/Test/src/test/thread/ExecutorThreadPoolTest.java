package test.thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorThreadPoolTest {

    public static void main(String[] args) {
        // create thread pool
        ExecutorService service = Executors.newFixedThreadPool(3);
        service = Executors.newCachedThreadPool();
        Executors.newSingleThreadExecutor();

    }

}
