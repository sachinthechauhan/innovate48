package test.thread;

/**
 * 
 * @author iid
 *
 */
class ThreadTest3 extends Thread {
    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            /* try {
                Thread.currentThread().join(2000);// current thread will be go in waiting state and other thread will complte work
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }*/
            System.out.println(": " + Thread.currentThread().getName() + "   " + Thread.currentThread().getState()
                    + "  " + Thread.currentThread().getPriority());
        }
    }
}

class ThreadTest4 extends Thread {
    @Override
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(": " + Thread.currentThread().getName() + "   " + Thread.currentThread().getState()
                    + "  " + Thread.currentThread().getPriority());
        }
    }
}

public class JoinMethodTest {

    public static void main(String[] args) throws InterruptedException {

        ThreadTest3 test3 = new ThreadTest3();
        test3.setName("First");
        test3.start();

        ThreadTest4 test4 = new ThreadTest4();
        test4.setName("Second");
        test4.start();
        test4.join();
        //        test3.join();// this thread will complete work

    }

}
