package test.thread;

/**
 * Java program to demonstrate How to use CountDownLatch in Java. CountDownLatch is
 * useful if you want to start main processing thread once its dependency is completed
 * as illustrated in this CountDownLatch Example
 * 
 * // application should not start processing any thread until all service is up
       // and ready to do there job.
       // Countdown latch is idle choice here, main thread will start with count 3
       // and wait until count reaches zero. each thread once up and read will do
       // a count down. this will ensure that main thread is not started processing
       // until all services is up.
      
       //count is 3 since we have 3 Threads (Services)
 * 
 */
import java.util.concurrent.CountDownLatch;

class Service implements Runnable {

    public String serviceName;

    public CountDownLatch countDownLatch;

    public int timeToStart;

    public Service(String serviceName, CountDownLatch countDownLatch, int timeToStart) {
        this.serviceName = serviceName;
        this.countDownLatch = countDownLatch;
        this.timeToStart = timeToStart;
    }

    @Override
    public void run() {
        try {
            Thread.sleep(timeToStart);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        System.out.println(":::Serice UP:::" + serviceName);
        countDownLatch.countDown();
        System.out.println("::::Remaining Count:::" + countDownLatch.getCount());
    }
}

public class CountDownLatchDemo {

    static CountDownLatch countDownLatch = new CountDownLatch(3);

    public static void main(String[] args) throws InterruptedException {
        Thread cache = new Thread(new Service("Cache", countDownLatch, 1000));
        Thread validation = new Thread(new Service("Validation", countDownLatch, 1000));
        Thread listners = new Thread(new Service("listners", countDownLatch, 1000));
        cache.start();
        validation.start();
        listners.start();

        countDownLatch.await();// Causes the current thread to wait until the
                               // latch has counted down to zero, unless the
                               // thread is interrupted.

        // this thread will wait untill count down latch become zero.
        new Thread(new Runnable() {

            @Override
            public void run() {
                System.out.println(":::::Service from main thread.........");

            }
        }).start();

    }

}
