package test.thread;

import java.util.concurrent.locks.ReentrantLock;

class AtmMachine extends Thread {
    private String name;

    ReentrantLock machine;

    public AtmMachine(String name, ReentrantLock lock) {
        this.name = name;
        this.machine = lock;
        this.start();
    }

    @Override
    public void run() {
        System.out.println(":::::doing transaction:::" + name);
        System.out.println(":::No Of wating Thread:::" + machine.getQueueLength());
        machine.lock();
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        machine.unlock();
        System.out.println(":::::Completed transaction:::" + name);

    }

}

public class ReentrantLockTest {

    public static void main(String[] args) {
        ReentrantLock machin = new ReentrantLock(true);

        for (int i = 0; i < 10; i++) {
            new AtmMachine("sachin " + i, machin);
        }
        //        testLockOperation(lock);
    }

    /**
     * @param lock
     */
    private static void testLockOperation(ReentrantLock lock) {
        System.out.println(lock.getHoldCount());
        lock.lock();
        lock.lock();
        lock.lock();
        System.out.println(lock.getHoldCount());
        lock.unlock();
        System.out.println("before if::" + lock.getHoldCount());
        if (lock.tryLock()) {//it will hold one lock
            System.out.println("iniff" + lock.getHoldCount());
        }
    }

}
