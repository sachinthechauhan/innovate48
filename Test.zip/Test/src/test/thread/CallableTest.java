package test.thread;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class Factorial implements Callable<Integer> {
    public Integer number;

    Factorial(Integer integer) {
        this.number = integer;
    }

    @Override
    public Integer call() throws Exception {
        Integer result = 1;
        while (number > 0) {
            result = result * number;
            number--;
        }
        return result;
    }

}

public class CallableTest {

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        //        Factorial fact = new Factorial(5);

        Factorial[] arry = { new Factorial(15), new Factorial(20), new Factorial(10) };

        //        ExecutorService executorService = Executors.newSingleThreadExecutor();
        ExecutorService executorService = Executors.newCachedThreadPool();

        /* Future<Integer> future = executorService.submit(fact);
        
        if (future.isDone()) {
            System.out.println(":::::" + future.get());
        }*/

        for (int i = 0; i < arry.length; i++) {
            Future<Integer> future2 = executorService.submit(arry[i]);
            System.out.println("Fact of " + arry[i].number + ":::is::" + future2.get());
        }
        executorService.shutdown();

    }

}
