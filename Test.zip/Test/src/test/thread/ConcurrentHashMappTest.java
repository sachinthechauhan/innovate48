package test.thread;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMappTest {

    public static void main(String[] args) {

        ConcurrentHashMap<String, String> concurrentHashMap = new ConcurrentHashMap<>(200, .75f, 10);
        Set<String> str = concurrentHashMap.keySet();

    }

}
