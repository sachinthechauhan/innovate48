package test.thread;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

class CallableTest2 implements Callable<Long> {
    public int num;

    CallableTest2(int num) {
        this.num = num;
    }

    long fact = 1;

    @Override
    public Long call() throws Exception {

        for (int i = 1; i <= num; i++) {
            fact = fact * i;
        }

        return fact;
    }
}

public class CallableTestDemo {

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        CallableTest2 callableTest = new CallableTest2(20);
        System.out.println("::::::main method:::");
        ExecutorService extService = Executors.newSingleThreadExecutor();
        Future<Long> result = extService.submit(callableTest);
        //		if (result.isDone()) {
        System.out.println("::::Fact of given No:::" + result.get());
        //		}
        extService.shutdown();
    }

}
