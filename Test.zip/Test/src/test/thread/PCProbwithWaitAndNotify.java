package test.thread;

class PCTest {
    private int value;

    private Boolean flag = false;

    public synchronized void put(int n) {
        if (flag) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        this.value = n;
        System.out.println(":::produced::::" + this.value);
        flag = true;
        notify();

    }

    public synchronized void get() {
        if (!flag) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println("::::consumed::" + this.value);
        flag = false;
        notify();
    }

}

public class PCProbwithWaitAndNotify {

    public static void main(String[] args) {
        PCTest pcTest = new PCTest();
        Thread producer = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 5; i++) {
                    pcTest.put(i);
                }
            }
        });

        Thread consumer = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 0; i < 5; i++) {
                    pcTest.get();
                }
            }
        });

        producer.start();
        consumer.start();

    }

}
