package test.thread;

class ExtThread extends Thread {
    @Override
    public void run() {
        System.out.println("::::extending thread::");

    }

}

class RunableThread implements Runnable {

    @Override
    public void run() {
        System.out.println("::::runnable thread::");

    }

}

public class CreatingThreadDemoTest {

    public static void main(String[] args) {
        ExtThread extThread = new ExtThread();
        extThread.start();
        Thread thread = new Thread(new RunableThread());
        thread.start();

    }

}
