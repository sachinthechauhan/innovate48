package test.thread;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;

public class ArrayBlockingQueueDemo {

    public static void main(String[] args) throws InterruptedException {

        ateempt1();

    }

    public static void ateempt1() throws InterruptedException {
        List<String> list = new ArrayList<>();
        list.add("l_kkk");
        list.add("l_kkk");
        list.add("l_kkk");
        list.add("l_kkk");
        list.add("l_kkk");
        list.add("l_kkk");
        list.add("l_kkk");
        //java.lang.IllegalArgumentException exception if pass a list greater then size
        ArrayBlockingQueue<String> blockingQueue = new ArrayBlockingQueue<>(5);
        ArrayBlockingQueue<String> blockingQueue2 = new ArrayBlockingQueue<>(5, true);
        ArrayBlockingQueue<String> blockingQueue3 = new ArrayBlockingQueue<>(5, true);
        blockingQueue3.add("Sachin");
        blockingQueue3.put("Sachin put");
        //        blockingQueue3.put(null);// not allowed
        //        blockingQueue3.add(null);// not allowed
        System.out.println(blockingQueue3);
    }

}
