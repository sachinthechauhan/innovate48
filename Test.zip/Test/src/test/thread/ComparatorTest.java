package test.thread;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;


class Employee {
    private String name;

    private int id;

    private double salary;

    private Date dob;

    public Employee(String name, int id, double salary, Date dob) {
        super();
        this.name = name;
        this.id = id;
        this.salary = salary;
        this.dob = dob;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }
}

class ComparatorProvider {

    public int compareByName(Employee o1, Employee o2) {
        return o1.getName().compareTo(o2.getName());
    }

    public int compareBySalary(Employee o1, Employee o2) {
        return o1.getId()-o2.getId();
    }

}

public class ComparatorTest {
    public static void main(String[] args) {
        Calendar calendar = Calendar.getInstance();
        List<Employee> list = new ArrayList<>();
        Employee obj1 = new Employee("Sachin", 122, 12000, calendar.getTime());
        calendar.add(Calendar.DATE, 2);
        Employee obj2 = new Employee("Anuj", 14, 20000, calendar.getTime());
        calendar.add(Calendar.DATE, 2);
        Employee obj3 = new Employee("Rahul", 90, 12000, calendar.getTime());
        calendar.add(Calendar.DATE, 2);
        Employee obj4 = new Employee("Verma", 1333, 34000, calendar.getTime());
        list.add(obj1);
        list.add(obj2);
        list.add(obj3);
        list.add(obj4);
        // base of id;
        // attempt 1
        /*Collections.sort(list, new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                if (o1.getId() < o2.getId()) {
                    return -1;
                } else if (o1.getId() > o2.getId()) {
                    return 1;
                } else if (o1.getId() == o2.getId()) {
                    return 0;
                }
                return 0;
            }
        });
        */
//        extracted(list);
        
        
        
        // by suing method ref
        ComparatorProvider comparatorProvider=new ComparatorProvider();
        
		/*
		 * list.sort(new Comparator<Employee>() {
		 * 
		 * @Override public int compare(Employee o1, Employee o2) { return
		 * comparatorProvider.compareBySalary(o1, o2); } });
		 */
        
        list.sort(comparatorProvider :: compareBySalary);
        
        list.forEach(e-> System.out.println(e.getId()));
    }

    
    /**
     * 
     * @param list
     */
	private static void extracted(List<Employee> list) {
		// attempt 2
        Collections.sort(list, new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                return o1.getId() - o2.getId();
            }
        });

        list.forEach(e -> System.out.println(":::" + e.getName() + "::::" + e.getId()));

        Collections.sort(list, new Comparator<Employee>() {
            @Override
            public int compare(Employee o1, Employee o2) {
                return o1.getDob().compareTo(o2.getDob());
            }
        });
        list.forEach(e -> System.out.println(":::" + e.getName() + "::::" + e.getId() + "::DOB::" + e.getDob()));
	}
}
