package test.clone;

import java.util.ArrayList;
import java.util.List;

class CloneDemo2 implements Cloneable {

    public int a = 6;

    CloneDemo2() {
        System.out.println(":::in deafult constructor:::");
    }

    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

public class CloneTest3 {

    public static void main(String[] args) throws CloneNotSupportedException {
        List<String> list = new ArrayList<>();
        CloneDemo2 obvj1 = new CloneDemo2();
        CloneDemo2 obvj2 = (CloneDemo2) obvj1.clone();
        obvj2.a = 8;

        System.out.println("::obvj1::" + obvj1.a);
        System.out.println("::obvj2::" + obvj2.a);

        if (obvj1 == obvj2) {
            System.out.println(":::same:::");
        } else {
            System.out.println(":::not same:::");

        }

    }

}
