package test.clone;

import java.util.ArrayList;
import java.util.List;

class CloneDemo implements Cloneable {

    CloneDemo() {
        System.out.println(":::in deafult constructor:::");
    }

    public String name;

    public Integer age;

    public List<String> list;

    CloneDemo(String name, Integer age, List list) {
        this.name = name;
        this.age = age;
        this.list = list;
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

public class CloneTest2 {

    public static void main(String[] args) throws CloneNotSupportedException {
        List<String> list = new ArrayList<>();
        list.add("Sachin");
        CloneDemo object = new CloneDemo("Sachin", 30, list);
        CloneDemo cloneObject = (CloneDemo) object.clone();
        cloneObject.name = "rahul kumar";
        //        cloneObject.age = 25;
        cloneObject.list.add("Rahul");
        System.out.println(
                ":Fresh Object:::" + object.name + "      " + object.age.hashCode() + "      " + cloneObject.list);
        System.out.println(":Clone Object:::" + cloneObject.name + "      " + cloneObject.age.hashCode() + "  "
                + cloneObject.list);

        if (object == cloneObject) {
            System.out.println("::same address:::");
        } else {
            System.out.println("::diff address:::");
        }

    }

}
