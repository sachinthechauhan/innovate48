package test.exception;

import java.io.FileNotFoundException;
import java.io.IOException;

class Foo {

    public void display() {
        System.out.println("::in Foo Display");
    }

    public void display2() throws IOException {
        System.out.println("::in Foo Display2");
    }

}

class Bar extends Foo {

    /**
     * Parent method declare no exception
     *  so we can give only run time exception 
     *  as unchecked not checked exception
     */
    @Override
    public void display() throws RuntimeException {
        System.out.println("::in Bar Display");
    }

    /**
     * Can be throws same exception or child if 
     * give parent exception then it give compile time error
     */
    @Override
    public void display2() throws FileNotFoundException {

        System.out.println(":::in Bar Display2");
    };

}

public class TestOverrideException {

    public static void main(String[] args) {

    }

}
