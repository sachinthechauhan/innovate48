package test.exception;

class MyException extends Exception {

    MyException(String args) {
        super(args);// Go in Exceptio then Throwable...
    }

}

public class CustomExceptionTest {

    public static void main(String[] args) {

        if (true) {
            try {
                throw new MyException("exception throw message");
            } catch (MyException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
                System.out.println(":::" + e.getMessage());
            }
        }

    }

}
