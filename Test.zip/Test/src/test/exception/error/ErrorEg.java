package test.exception.error;

/**
 * We can handle error...mostly when error occured in application at that time application will be in abnormal condition.
 * 
 * we can catch StackOverflow error.
 * OutOfMemoryError and NoClassDefFoundError can be catch but in case of OutOfMemoryError we are not sure as application will be in good condition to execute
 * code correctly.
 * 
 * 
 * Errors are also unchecked exception & the programmer is not required to do anything with these. In fact it is a bad idea to use a 
 * try-catch clause for Errors. Most often, recovery from an Error is not possible & the program should be allowed to terminate. Examples
 *  include OutOfMemoryError, StackOverflowError, etc.
 * 
 * @author iid
 *
 */
class StackOverflow {
    public static void test(int i) {
        // No correct as base condition leads to 
        // non-stop recursion. 
        if (i == 0)
            return;
        else {
            test(i++);
        }
    }

    public static void display2() {
        System.out.println("::::::in display 2::::");
    }
}

public class ErrorEg {

    public static void main(String[] args) {

        // eg of StackOverflowError 
        try {
            StackOverflow.test(5);
        } catch (Throwable e) {
            System.out.println(":::in throwable::");
            StackOverflow.display2();
        }

    }
}
