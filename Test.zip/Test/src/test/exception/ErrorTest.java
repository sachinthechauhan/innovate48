package test.exception;

public class ErrorTest {

    public static void test(int i) {
        // No correct as base condition leads to 
        // non-stop recursion. 
        if (i == 0)
            return;
        else {
            test(i++);
        }
    }

    public static void main(String[] args) {

        test(2);
    }

}
