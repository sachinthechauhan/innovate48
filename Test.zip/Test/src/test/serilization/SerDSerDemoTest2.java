package test.serilization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

class Demo2 implements java.io.Serializable {

    public int id;

    public String add;

    public static String name;

    public transient Integer mob;

    public int test;

    ChildDemo childDemo;

    Demo2() {
        System.out.println(":::in default constructor...");
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the add
     */
    public String getAdd() {
        return add;
    }

    /**
     * @param add the add to set
     */
    public void setAdd(String add) {
        this.add = add;
    }

    /**
     * @return the name
     */
    public static String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public static void setName(String name) {
        Demo.name = name;
    }

    /**
     * @return the mob
     */
    public Integer getMob() {
        return mob;
    }

    /**
     * @param mob the mob to set
     */
    public void setMob(Integer mob) {
        this.mob = mob;
    }

    /**
     * @param test the test to set
     */
    public void setTest(int test) {
        this.test = test;
    }

    /**
     * @param childDemo the childDemo to set
     */
    public void setChildDemo(ChildDemo childDemo) {
        this.childDemo = childDemo;
    }

    // Default constructor 

}

class ChildDemo2 extends Demo2 {

    private void writeObject(ObjectOutputStream oos) throws Exception {
        System.out.println(":::in child demo2:: write object..");

        throw new NotSerializableException(":::Not Required Exception::");
    }

}

public class SerDSerDemoTest2 {

    public static void serilizeObject(String path) {

        Demo2 demo = new Demo2();
        demo.setId(1234);
        demo.setName("Sachin kumar");
        demo.setMob(8800161);
        demo.setAdd("dhampur");
        demo.setChildDemo(new ChildDemo());

        ChildDemo2 childDemo2 = new ChildDemo2();

        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(path));) {

            //            objectOutputStream.writeObject(demo);
            objectOutputStream.writeObject(childDemo2);
            System.out.println("::Serilizede successful..");
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static void deSerilizeObject(String path) {

        try {
            ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(path));

            Demo demo = (Demo) inputStream.readObject();

            System.out.println(
                    "::::" + demo.getAdd() + ":::::::" + demo.getId() + ":::" + demo.getName() + "::" + demo.getMob());

        } catch (IOException | ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        String path = "/home/iid/Desktop/Serilization/demo.ser";
        serilizeObject(path);
        //        deSerilizeObject(path);
    }

}
