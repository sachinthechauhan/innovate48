package test.serilization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class User implements Serializable {
    private String userName;

    private transient String userPswd;

    User(String userName, String userPswd) {
        this.userName = userName;
        this.userPswd = userPswd;
    }

    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName the userName to set
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * @return the userPswd
     */
    public String getUserPswd() {
        return userPswd;
    }

    /**
     * @param userPswd the userPswd to set
     */
    public void setUserPswd(String userPswd) {
        this.userPswd = userPswd;
    }

    // override read and write object for custom implementation

    /**
     * serilize object write line by line and also read in same manner
     *oos.defaultWriteObject();  write object// readObject
     *oos.writeObject(epwd);// then write this  // readObject
       * oos.writeObject(epwd2); // then write this  // call to readObject() for this 
     *
     * @param oos
     * @throws Exception
     */

    private void writeObject(ObjectOutputStream oos) throws Exception {
        System.out.println(":::in write object.......");
        // to perform default serialization of User object. 
        oos.defaultWriteObject();

        // epwd (encrypted password) 
        String epwd = "123" + userPswd;
        String epwd2 = "Test 3 object";

        // writing encrypted password to the file 
        oos.writeObject(epwd);
        oos.writeObject(epwd2);
    }

    // this method is executed by jvm when readObject() on 
    // Account object reference in main method is executed by jvm. 
    private void readObject(ObjectInputStream ois) throws Exception {
        System.out.println(":::in Read object.......");
        // performing default deserialization of Account object 
        ois.defaultReadObject();

        // deserializing the encrypted password from the file 
        String epwd = (String) ois.readObject();

        // decrypting it and saving it to the original password 
        // string starting from 3rd  index till the last index 
        userPswd = epwd.substring(3);

        String lastObj = (String) ois.readObject();
        System.out.println(":::lastObj::" + lastObj);
    }

    /**
     * 
     * in case of de-serialization, this method called always
     * ..we can modify this
     * This object will return
     * @return
     */
    protected Object readResolve() {
        return new User("KK", "KK pswd");
    }

}

public class CustomeHandlingForSerDerDemo {

    public static void serializeObject(User userObj, String path) {

        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(path));) {

            objectOutputStream.writeObject(userObj);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void deSerializeObject(String path) {

        try (ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(path))) {
            User userObj = (User) inputStream.readObject();
            System.out.println("::UName::::" + userObj.getUserName() + "::pswd::::" + userObj.getUserPswd() + "");
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {

        // serlization object

        User user = new User("Sachin Kumar", "password");

        String path = "/home/iid/Desktop/serilizationDemo/userDetails.ser";

        System.out.println("::Object Property::::" + user.getUserName() + ": PSwd::" + user.getUserPswd());

        serializeObject(user, path);

        // de seriliaze object

        deSerializeObject(path);

    }

}
