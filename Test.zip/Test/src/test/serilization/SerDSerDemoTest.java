package test.serilization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Demo3 implements Serializable {
    public int userId;
}

class Demo extends Demo3 implements java.io.Serializable {

    public int id;

    public String add;

    public static String name;

    public transient Integer mob;

    public int test;

    ChildDemo childDemo;

    Demo() {
        System.out.println(":::in default constructor...");
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the add
     */
    public String getAdd() {
        return add;
    }

    /**
     * @param add the add to set
     */
    public void setAdd(String add) {
        this.add = add;
    }

    /**
     * @return the name
     */
    public static String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public static void setName(String name) {
        Demo.name = name;
    }

    /**
     * @return the mob
     */
    public Integer getMob() {
        return mob;
    }

    /**
     * @param mob the mob to set
     */
    public void setMob(Integer mob) {
        this.mob = mob;
    }

    /**
     * @param test the test to set
     */
    public void setTest(int test) {
        this.test = test;
    }

    /**
     * @param childDemo the childDemo to set
     */
    public void setChildDemo(ChildDemo childDemo) {
        this.childDemo = childDemo;
    }

    // Default constructor 

}

class ChildDemo implements Serializable {

    private String name;

}

public class SerDSerDemoTest {

    public static void serilizeObject(String path) {

        Demo demo = new Demo();
        demo.setId(1234);
        //        demo.setName("Sachin kumar");
        demo.setMob(8800161);
        demo.setAdd("dhampur");
        demo.setChildDemo(new ChildDemo());
        demo.userId = 4555;
        Demo.name = "kkk";

        try (ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(path));) {

            objectOutputStream.writeObject(demo);
            System.out.println("::Serilizede successful..");
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public static void deSerilizeObject(String path) {

        try {
            ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(path));

            Demo demo = (Demo) inputStream.readObject();

            System.out.println("::::" + demo.getAdd() + ":::::::" + demo.getId() + ":::" + demo.getName() + "::"
                    + demo.getMob() + "  " + demo.userId);

        } catch (IOException | ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    public static void main(String[] args) {
        String path = "/home/iid/Desktop/Serilization/demo.ser";
        //        serilizeObject(path);
        deSerilizeObject(path);
    }

}
