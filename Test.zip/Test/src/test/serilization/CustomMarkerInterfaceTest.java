package test.serilization;

class CutomMarker implements Marker {

}

public class CustomMarkerInterfaceTest {

    public static void main(String[] args) {
        CutomMarker cutomMarker = new CutomMarker();

        if (cutomMarker instanceof Marker) {
            System.out.println("::::DO something specific for this class");
        }

    }

}
