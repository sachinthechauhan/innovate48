package test.serilization;

public interface Marker {

}
