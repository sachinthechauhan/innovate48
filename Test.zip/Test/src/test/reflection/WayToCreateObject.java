package test.reflection;

public class WayToCreateObject {

    public static void main(String[] args)
            throws ClassNotFoundException, InstantiationException, IllegalAccessException, CloneNotSupportedException {

        // using new
        Test test = new Test();
        //using reflection
        Class cls = Class.forName("Test");
        System.out.println(":::Simple name::" + cls.getSimpleName());
        Object test2 = cls.newInstance();
        //second
        Test test3 = Test.class.newInstance();// constructor will called
        // by clone
        Test test4 = (Test) test3.clone();
        // using serilization and de-serilalization
        //        Whenever we serialize and deserialize an object,
        //the JVM creates a separate object for us. In deserialization, the JVM doesn’t use any constructor to create the object

    }

}
