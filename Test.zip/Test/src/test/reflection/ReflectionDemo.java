package test.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

class Test implements Cloneable {

    public Test() {
        System.out.println(":::consttructor called");
    }

    public Test(String str) {
        System.out.println(":::consttructor called  " + str);
    }

    public void display() {
        System.out.println(":::in display methods....");
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

public class ReflectionDemo {

    public static void main(String[] args) throws NoSuchMethodException, SecurityException {

        Test test = new Test();

        Class cls = test.getClass();
        // Getting the constructor of the class through the 
        // object of the class 
        Constructor constructor = cls.getConstructor();
        System.out.println("The name of constructor is " + constructor.getName());

        //        / Getting methods of the class through the object 
        // of the class by using getMethods 
        Method[] methods = cls.getMethods();

        // Printing method names 
        for (Method method : methods)
            System.out.println(method.getName());

    }

}
