package test.ArrAndStrOperation;

public class StringPractiseTest {

    public static void main(String[] args) {

        //        reverseString();
        // isplaindrome strng
        // EG: NITIN

        // check for anagram of two string

        String str1 = "Aaba";
        String str2 = "aaa";
        //        isAnagram(str1, str2);
        // reverse given number
        StringDecode(str1);

    }

    public static void StringDecode(String str) {

        System.out.println((int) str.charAt(0));
        System.out.println((int) str.charAt(1));

    }

    /**
     * An anagram of a string is another string that contains the same characters, 
     * only the order of characters can be different. For example, “abcd” and “dabc”
     *  are an Anagram of each othe
     * @param str1
     * @param str2
     */

    public static void isAnagram(String str1, String str2) {
        boolean flag = true;
        if (str1.length() != str2.length()) {
            flag = false;
        }
        str1 = str1.toLowerCase();
        str2 = str2.toLowerCase();

        for (int i = 0; i < str1.length(); i++) {
            if (!str2.contains(String.valueOf(str1.charAt(i)))) {
                flag = false;
            }
        }
        if (flag) {
            System.out.println(str1 + "   " + str2 + " are anagram");
        } else {
            System.out.println(str1 + "   " + str2 + " are not anagram");
        }
    }

    /**
     * 
     */
    private static void reverseString() {
        // reverse String
        String str = "sachin";
        String rev = "";
        char[] strArr = str.toCharArray();
        for (int i = strArr.length - 1; i >= 0; i--) {
            rev += strArr[i];
        }
        System.out.println("::::rev string:::" + rev);
    }

}
