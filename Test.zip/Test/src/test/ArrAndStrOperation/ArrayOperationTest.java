package test.ArrAndStrOperation;

import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * https://javarevisited.blogspot.com/2015/06/top-20-array-interview-questions-and-answers.html
 * @author iid
 *
 */
public class ArrayOperationTest {

    /**
     * By using java 8 we can merge , sorted, distinct..ect..
     * @param arr1
     * @param arr2
     */
    private static void mergeTwoArray(int[] arr1, int[] arr2) {
        // first way
        Stream<int[]> arr4 = Stream.of(arr1, arr2);
        IntStream intStream = arr4.flatMapToInt(x -> Arrays.stream(x));
        // if want sort both array

        intStream.sorted().forEach(e -> System.out.println(e));
        // if we use single array then we can use...
        //stream of use interanlly arrays.stream method.
        //      IntStream intStream1=Arrays.stream(arr1);
        //      intStream1.distinct().forEach(e -> System.out.println(e));
    }

    /**
     * reverse array
     * @param arr1
     * @param arr2
     */
    private static void reversed(int[] arr1) {
        int len = arr1.length;
        int rev[] = new int[len];
        for (int i = len - 1, j = 0; i >= 0; i--, j++) {
            rev[j] = arr1[i];
        }
        Arrays.stream(rev).forEach(e -> System.out.print(e + "  "));
    }

    /**
     * without using java 8
     */
    private static void mergeTwoSortedArray(int[] arr1, int[] arr2) {
        // it will allow if both have duplicate elements
        int n1 = arr1.length;
        int n2 = arr2.length;
        int[] sortedArr = new int[arr1.length + arr2.length];
        int k = 0;// index of new array
        int i = 0, j = 0;
        while (i < n1 && j < n2) {
            if (arr1[i] < arr2[j]) {
                sortedArr[k] = arr1[i];
                i++;
            } else {
                sortedArr[k] = arr2[j];
                j++;
            }
            k++;
        }
        // add remaing element as both array can be diffrent size.
        while (i < n1) {
            sortedArr[k] = arr1[i];
            k++;
            i++;
        }
        while (j < n2) {
            sortedArr[k] = arr2[j];
            k++;
            j++;
        }

        // print array
        Arrays.stream(sortedArr).forEach(e -> System.out.print(e + " "));
    }

    /**
     * remove duplicate element from unsorted array, we can use hasp mapfor maintain frequeny
     * and if array is sorted we can use just one temp variable 
     * and store cureen val and compare prev added value
     * @param arr
     */
    public static void removeDuplicateFromSortedArr(int arr[]) {
        int[] outPutArr = new int[arr.length];
        int lastVal = 0;
        for (int i = 0, j = 0; i < arr.length; i++) {
            if (arr[i] != lastVal) {
                outPutArr[j++] = arr[i];
            }
            lastVal = arr[i];
        }
        // print array
        Arrays.stream(outPutArr).forEach(e -> System.out.print(e + " "));
    }

    public static void main(String[] args) {
        int[] arr1 = { 2, 45, 12 };
        int[] arr2 = { 15, 3, 5 };
        //      mergeTwoArray(arr1, arr2);
        //      reversed(arr1);
        int[] arr3 = { 3, 12, 45, 56 };
        int[] arr4 = { 3, 5, 8, 9 };
        //        mergeTwoSortedArray(arr3, arr4);

        int[] arr5 = { 3, 3, 5, 8, 8, 8, 8, 9, 10 };
        removeDuplicateFromSortedArr(arr5);

        //        int[] arr6 = new int[6];
        //        Arrays.stream(arr6).forEach(e -> System.out.print(e + " "));
    }

}
