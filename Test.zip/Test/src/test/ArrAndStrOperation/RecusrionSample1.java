package test.ArrAndStrOperation;

public class RecusrionSample1 {

    static void printFun(int test) {
        if (test < 1)
            return;
        else {
            System.out.printf("%d ", test);
            printFun(test - 1); // statement 2 
            System.out.printf("%d 2222  ", test);
            return;
        }
    }

    public static int test(int n) {

        if (n <= 1) {
            return 1;
        }
        System.out.println(n);
        return test(n - 1);
    }

    static {
        //		System.out.println(test(5));// can we without using main method
    }

    public static void main(String[] args) {

        // try to print value from top to one.
        //        System.out.println(test(5));
        printFun(5);

    }

}
