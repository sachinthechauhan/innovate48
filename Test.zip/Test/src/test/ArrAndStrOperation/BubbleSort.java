package test.ArrAndStrOperation;

import java.util.Arrays;

public class BubbleSort {

    public static void attempt1(int[] arr) {
        // eg: 4 5 6 7 1 3 3
        for (int i = arr.length - 1; i >= 0; i--) {

            for (int j = 0; j <= i - 1; j++) {

                if (arr[j] > arr[j + 1]) {

                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }

            }

        }
        Arrays.stream(arr).forEach(e -> System.out.println(e));
    }

    /**
     * Unsorted array, Complexity: o(n2)
     * 
     * @param arr
     */
    public static void attempt2(int[] arr) {
        // eg: 4 5 6 7 1 3 3
        for (int i = 0; i < arr.length; i++) {
            // arr.length-i-1 as minize the no iteration
            for (int j = 0; j < arr.length - i - 1; j++) {

                if (arr[j] > arr[j + 1]) {

                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }

            }

        }
        Arrays.stream(arr).forEach(e -> System.out.println(e));
    }

    /**
     * if given array is already sorted then no need to do compare Complexity:
     * O(n)
     * 
     * @param arr
     */
    public static void attempt3(int[] arr) {
        // eg: 4 5 6 7 1 3 3
        int swapPass = 1;// just check any operation done for suffling elements
        for (int i = 0; i < arr.length && swapPass == 1; i++) {
            System.out.println("::::::::::::::::first loop::");
            // arr.length-i-1 as mince the no iteration
            swapPass = 0;
            for (int j = 0; j < arr.length - i - 1; j++) {
                System.out.println(":::inner loop::");
                if (arr[j] > arr[j + 1]) {
                    int temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    swapPass = 1;
                }
            }

        }
        Arrays.stream(arr).forEach(e -> System.out.println(e));
    }

    public static void main(String[] args) {

        int[] arr = { 45, 12, 23, 12, 6, 9 };
        // sorted array
        int[] arr2 = { 50, 2, 4, 6, 3, 7, 8, 9 };
        // attempt2(arr);
        attempt3(arr2);
    }

}
