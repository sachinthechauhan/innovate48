package test.ArrAndStrOperation;

import java.util.HashMap;
import java.util.Map;

/**
 * https://www.java67.com/2018/04/21-string-programming-and-coding-interview-questions-answers.html
 * @author iid
 *
 */
public class StringOperationTest {

    public static void reverseString(String str) {
        int len = str.length();
        String res = "";
        for (int i = len - 1; i >= 0; i--) {
            res += str.charAt(i);

        }
        System.out.println(":OutPut::" + res);
    }

    /**
     * plaindron means if we reverse string then it should be same
     * as original
     * @param input
     */

    public static void isPalindrome(String input) {
        input = input.toLowerCase();
        int len = input.length();
        int mid = len / 2;
        boolean flag = true;

        for (int i = 0, j = len - 1; i <= mid; i++, j--) {
            if (input.charAt(i) != input.charAt(j)) {
                flag = false;
            }

        }
        if (flag) {
            System.out.println("::::String is plaindron...");
        } else {
            System.out.println("::::String is not plaindron...");
        }
    }

    /**
     * Listen and Silent
     * Triangle Integral
     * abcd dabc
     * @param arg1
     * @param arg2
     */
    public static void isAnagram(String arg1, String arg2) {
        // check frequency
        arg1 = arg1.toLowerCase();
        arg2 = arg2.toLowerCase();
        if (arg1.length() != arg2.length()) {
            System.out.println("::not anagram....");
            return;
        }
        Map<Character, Integer> arg1Map = new HashMap<>();
        Map<Character, Integer> arg2Map = new HashMap<>();
        for (int i = 0; i < arg1.length(); i++) {
            // for first string
            if (arg1Map.containsKey(arg1.charAt(i))) {
                arg1Map.put(arg1.charAt(i), arg1Map.get(arg1.charAt(i)) + 1);
            } else {
                arg1Map.put(arg1.charAt(i), 1);

            }
            // for second string
            if (arg2Map.containsKey(arg2.charAt(i))) {
                arg2Map.put(arg2.charAt(i), arg2Map.get(arg2.charAt(i)) + 1);
            } else {
                arg2Map.put(arg2.charAt(i), 1);

            }
        }
        // compare both map
        boolean flag = true;
        for (Character ch : arg1Map.keySet()) {
            if (!arg2Map.containsKey(ch) && arg1Map.get(ch) != arg2Map.get(ch)) {
                flag = false;
            }
        }
        if (flag) {
            System.out.println(":::given string is anagram...");
        } else {
            System.out.println("::::not anagram........");
        }
        System.out.println(":::Map::" + arg1Map + ":::::" + arg2Map);
    }

    public static void isAnagramAttempt2(String str1, String str2) {
        boolean flag = true;
        if (str1.length() != str2.length()) {
            flag = false;
        }
        str1 = str1.toLowerCase();
        str2 = str2.toLowerCase();

        for (int i = 0; i < str1.length(); i++) {
            if (!str2.contains(String.valueOf(str1.charAt(i)))) {
                flag = false;
            }
        }
        if (flag) {
            System.out.println(str1 + "   " + str2 + " are anagram");
        } else {
            System.out.println(str1 + "   " + str2 + " are not anagram");
        }
    }

    public static void reverseAnumber(int num) {
        int res = 0;
        while (num > 0) {
            res = res * 10 + num % 10;
            num = num / 10;
        }
        System.out.println("::" + res);
    }

    public static void removeCharacterFromString(String str, String repChar) {

        //   str=   str.replaceAll("sa", "");
        System.out.println(":::::input:::" + str);

        int index = str.indexOf(repChar);
        //   str.substring(beginIndex)
        System.out.println("::::" + str.substring(1, 4));

    }

    public static void main(String[] args) {
        String str = "sachin";
        // reverseString(str);
        str = "Madam";// plain drone
        str = "121";
        str = "ABBA";
        str = "NITIN";
        isPalindrome(str);
        //      isAnagram("Listen","Sileasdgadsnt");
        //      reverseAnumber(123);
        //        str = "sachinsani";
        //        removeCharacterFromString(str, "h");

    }

}
