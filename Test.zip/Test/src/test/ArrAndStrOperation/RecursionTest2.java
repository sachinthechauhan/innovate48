package test.ArrAndStrOperation;

public class RecursionTest2 {

    public int factorial(int n) {
        if (n == 0) {
            return 1;
        }

        return n * factorial(n - 1);
    }

    public static void main(String[] args) {
        RecursionTest2 rec = new RecursionTest2();

        System.out.println("::::" + rec.factorial(5));

    }

}
