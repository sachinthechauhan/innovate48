package test.ArrAndStrOperation;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

/**
 * https://www.java67.com/2019/04/how-to-remove-duplicates-from-unsorted-array-in-java.html
 * https://javarevisited.blogspot.com/2014/08/how-to-find-all-pairs-in-array-of-integers-whose-sum-equal-given-number-java.html
 * 
 * 
 * 
 * Concvert array to String use Arrays.toString()..overloaded for all type
 * @author iid
 *
 */
public class ArrayPractiseTest {

    public static void main(String[] args) {

        //        mergeTwoArrayWithJava8();

        //        reverseArrayElements();
        //        removeDuplicateElements();

        //        removeElementFromArray();

        //        pairOfnumberAsGivenSum();

        pairOfnumberAsGivenSum2();
        //        converionArrayToListViceVersa();

        // binary Search 
        // apply on sorted array

        //        binarySearch();

        //        Integer[] arr1 = { 1, 2, 3, 4, 5, 6, 8, 9, 24, 30, 50 };
        //        secondHighestElement(arr1);

    }

    private static void binarySearch() {
        Integer[] arr1 = { 1, 2, 3, 4, 5, 6, 8, 9, 24, 30, 50 };
        int num = 9;
        int start = 0;
        int end = arr1.length;

        while (start <= end) {
            int mid = (start + end) / 2;

            if (arr1[mid] == num) {
                System.out.println("::::element in found: on index:" + mid);
            }
            if (num < arr1[mid]) {
                end = mid - 1;
            } else {
                start = mid + 1;
            }

        }
    }

    public static void secondHighestElement(Integer[] arr) {
        Optional<Integer> max = Arrays.stream(arr).sorted().distinct().reduce((a, b) -> a > b ? a : b);
        System.out.println("::highest Max::::" + max.get());
        List<Integer> list = Arrays.stream(arr).sorted().distinct().collect(Collectors.toList());
        System.out.println(list.size() + ":::Element:::" + list);
        System.out.println(":::Second Highest Element::" + list.get(list.size() - 2));

    }

    /**
     * 
     * 
     * 
     */
    private static void converionArrayToListViceVersa() {
        Integer[] arr1 = { 1, 2, 3, 4, 5, 0, 2, -1 };
        // convert to String 
        Arrays.toString(arr1);

        // convert array to list
        List<Integer> list = Arrays.asList(arr1);
        // list to array
        arr1 = (Integer[]) list.toArray();
        System.out.println(Arrays.toString(arr1));
    }

    /**
     * using single loop
     */
    private static void pairOfnumberAsGivenSum2() {
        // // find the pair of number in forward direction for given sum
        // complexity o(nlogn) should be
        //        int[] arr1 = { 1, 2, 3, 4, 5, 0, 2, -1 };

        int[] arr1 = { 5, 4, 6 };
        int sum = 3;// find pair of sum
        HashSet<Integer> hashSet = new HashSet<>();
        for (int num : arr1) {
            int target = sum - num;
            if (!hashSet.contains(target)) {
                hashSet.add(num);
            } else {
                System.out.println("::pair of Sum " + sum + " {" + num + ", " + target + "}");
            }

        }
    }

    /**
     * using simple array
     * compl o(n2)
     */
    private static void pairOfnumberAsGivenSum() {
        // find the pair of number in forward direction for given sum
        // complexity o(n2)
        int[] arr1 = { 1, 2, 3, 4, 5, 0, 2, -1 };
        int sum = 4;// find pair of sum

        for (int i = 0; i < arr1.length; i++) {
            int firstEl = arr1[i];

            for (int j = i + 1; j < arr1.length; j++) {
                int secondtEl = arr1[j];
                if (firstEl + secondtEl == sum) {
                    System.out.println("::pair of Sum " + sum + " {" + firstEl + ", " + secondtEl + "}");
                }
            }
        }
    }

    /**
     * Remove element from as given index
     */
    private static void removeElementFromArray() {
        // remove elements from array given index
        int[] arr1 = { 1, 2, 3, 4, 5 };

        int index = 2;// want to remove

        int temp = index;
        while (temp < arr1.length - 1) {
            arr1[temp] = arr1[temp + 1];
            arr1[temp + 1] = 0;
            temp++;
        }

        Arrays.stream(arr1).forEach(e -> System.out.println(e));
    }

    /**
     * remove duplicate from sorted array or we can give example by using java8
     * with distinct filter and print...
     * 
     * array is unsorted the it can be by java 8 or sort the array then remove duplicate element..or
     */
    private static void removeDuplicateElements() {
        // remove duplicate elemnts fromn sorted array
        int[] arr1 = { 1, 2, 2, 3, 4, 5, 5 };

        int[] distArray = new int[arr1.length];
        int temp = 0;
        for (int i = 0, k = 0; i < arr1.length; i++) {
            if (temp != arr1[i]) {
                distArray[k++] = arr1[i];
                temp = arr1[i];
            }

        }
        Arrays.stream(distArray).forEach(e -> System.out.println(e));
    }

    private static void reverseArrayElements() {
        int[] arr1 = { 1, 2, 3, 4, 5, 5 };
        // reverse array
        int[] rev = new int[arr1.length];

        for (int i = arr1.length - 1, j = 0; i >= 0; i--) {
            rev[j++] = arr1[i];
        }
        // print rev array elements
        Arrays.stream(rev).distinct().forEach(e -> System.out.println(e));
    }

    /**
     * merge two unsorted array or can be merge two 
     * sorted array and then filter of distinct elements
     * 
     * sum of two array
     */
    private static void mergeTwoArrayWithJava8() {
        // merge two arry with java 8
        int[] arr1 = { 1, 2, 3, 4, 5, 5 };
        int[] arr2 = { 1, 2, 3, 4, 5, 5 };

        // jut check diff between Arrays.stream and Stream.of
        IntStream intStream2 = Arrays.stream(arr1);
        intStream2.forEach(e -> System.out.println(e));

        Stream<int[]> intStream = Stream.of(arr1);
        intStream.forEach(e -> System.out.println(e));

        // now start to merge array and filter with distnict

        Stream<int[]> stream = Stream.of(arr1, arr2);
        IntStream mergeStream = stream.flatMapToInt(x -> Arrays.stream(x)).distinct();
        mergeStream.forEach(e -> System.out.println(e));
        int sum = stream.flatMapToInt(x -> Arrays.stream(x)).distinct().sum();
    }

}
