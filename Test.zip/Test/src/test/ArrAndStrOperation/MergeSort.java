package test.ArrAndStrOperation;

import java.util.Arrays;

public class MergeSort {

    static void callMerge(int arr[], int lower, int m, int r) {
        System.out.println("::callMerge:::" + Arrays.toString(arr) + "Lower::" + lower + ":::m::" + m + "::r::" + r);
        // Find sizes of two subarrays to be merged 
        //Lower::0:::m::0::r::1 as l and m may on same position
        int n1 = m - lower + 1;
        int n2 = r - m;

        /* Create temp arrays */
        int L[] = new int[n1];
        int R[] = new int[n2];

        /*Copy data to temp arrays*/
        for (int i = 0; i < n1; i++)
            L[i] = arr[lower + i];
        for (int i = 0; i < n2; i++)
            R[i] = arr[m + 1 + i];
        System.out.println("::LL:::" + Arrays.toString(L));
        System.out.println("::RR:::" + Arrays.toString(R));

        // merge temp array
        int i = 0, j = 0;
        // initial index for second merge array
        int k = lower;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            } else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }
        // add remaining elemtsnt;
        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }
        while (j < n2) {
            arr[k] = R[j];
            k++;
            j++;
        }

        System.out.println("::merged array:::" + Arrays.toString(arr));
    }

    static void mergeSort(int arr[], int l, int r) {

        System.out.println("::mergeSort:::" + Arrays.toString(arr));
        if (l < r) {
            int m = (l + r) / 2;
            // divide first array
            System.out.println(":::first array::");
            mergeSort(arr, l, m);
            // divided another second array
            System.out.println(":::second array::");
            mergeSort(arr, m + 1, r);
            //call merge
            System.out.println("::finally call merge::");
            callMerge(arr, l, m, r);
        }

    }

    static void printArr(int arr[]) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(arr[i]);
        }

    }

    public static void main(String[] args) {

        int arr[] = { 38, 27, 43, 3, 9, 82, 10 };
        mergeSort(arr, 0, arr.length - 1);

    }
}
