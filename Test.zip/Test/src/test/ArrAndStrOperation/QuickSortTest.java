package test.ArrAndStrOperation;

/**
 * Comlexity:
 * 
 * worst Case: o(n2)
 * avrege case: nlogn
 * best case: nlogn
 * @author Sachin Chauhan
 *
 */
class QickSort {

    public int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i = low - 1;// becoz we can replace arr[i+1] and arr[high] after exit from loop o/w it will throw index out of bound exception..
        for (int j = low; j < high; j++) {

            //if current element is equal or less then or equal to pivot
            if (arr[j] <= pivot) {
                i++;
                //swap i and j
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
        // swap arr[i+1] and arr[high] (or pivot)
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        return i + 1;
    }

    /**
     * 
     */
    public void sort(int[] arr, int low, int high) {
        if (low < high) {

            int pi = partition(arr, low, high);
            System.out.println(":::" + pi + "::low::" + low + "::high::" + high);
            printArray(arr);

            // recursively sort array after and before of partion
            sort(arr, low, pi - 1);
            sort(arr, pi + 1, high);

        }

    }

    /* A utility function to print array of size n */
    static void printArray(int arr[]) {
        int n = arr.length;
        for (int i = 0; i < n; ++i)
            System.out.print(arr[i] + " ");
        System.out.println();
    }

}

public class QuickSortTest {

    public static void main(String[] args) {
        int[] arr = { 10, 80, 30, 90, 40, 50, 70 };

        QickSort qickSort = new QickSort();
        qickSort.sort(arr, 0, arr.length - 1);
        QickSort.printArray(arr);

    }

}
