package test.ArrAndStrOperation;

public class SearchTest {

    /**
     * time comlexity of this O(n);
     * @param arr
     * @param num
     */
    public static void linearSearch(int arr[], int num) {
        boolean flag = false;
        int i = 0;
        for (; i < arr.length; i++) {
            if (arr[i] == num) {
                flag = true;
                break;
            }
        }
        if (flag) {
            System.out.println("::requested element " + num + " found and index " + i);
        } else {
            System.out.println("::::::note found...");
        }
    }

    /**
     * 
     *  time comlexity of this O(1); // best case
     *  avrege case: o(logn)
     * Using recursion
     * @param arr
     * @param low
     * @param high
     * @param num
     * @return
     */
    public static int binarySearch(int arr[], int low, int high, int num) {

        if (high >= low) {
            int median = (low + high) / 2;
            if (arr[median] == num) {
                System.out.println("::::requested element found on index..." + median);
                return median;
            } else if (num < arr[median]) {
                return binarySearch(arr, low, median, num);
            } else if (num > arr[median]) {
                return binarySearch(arr, median + 1, high, num);
            }
        }
        return -1;
    }

    public static int binarySearchUsingIterative(int[] arr, int num) {
        int low = 0;
        int high = arr.length;
        while (high >= low) {
            int med = (low + high) / 2;
            if (arr[med] == num) {
                return med;
            } else if (arr[med] < num) {
                low = med + 1;
            } else {
                high = med - 1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        int[] arr = { 45, 67, 13, 343, 66, 78, 9, 5, 4, 3 };
        //      linearSearch(arr,343);
        // for binary search
        int[] arr2 = { 2, 5, 6, 7, 8, 9, 14, 26, 30 };
        int result = binarySearch(arr2, 0, arr2.length - 1, 30);
        //        int result = binarySearchUsingIterative(arr2, 2);
        if (result == -1) {
            System.out.println("::result::::" + result);
        } else {
            System.out.println("::::found in the system.....");
        }

    }

}
