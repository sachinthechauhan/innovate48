package test.ArrAndStrOperation;

public class SetCompare {

    public static void main(String[] args) {

        String str1 = "NITIN";
        //        String str2 = "NKTIN";

        int len = str1.length() - 1;

        for (int i = 0, j = len; i < len / 2; i++, j--) {

            if (!(str1.charAt(i) == str1.charAt(j))) {
                System.out.println("..NO Plainedron..........");
            }

        }
        char[] letters = str1.toLowerCase().toCharArray();
        int count = 0;
        for (char c : letters) {
            switch (c) {
            case 'a':
                count++;
                break;
            case 'e':
            case 'i':
                count++;
                break;
            case 'o':
            case 'u':

                count++;
                break;
            default:
                // no count increment
            }

        }

        System.out.println("::::No Vow:::" + count);
    }

}
