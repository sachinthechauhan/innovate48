package test.ArrAndStrOperation;

import java.util.HashSet;
import java.util.Set;

public class MinUniqueArraySum {

    static Set<Integer> set = new HashSet<>();

    public static Integer makeUnique(Integer e) {
        if (set.contains(e)) {
            e = e + 1;
            makeUnique(e);
        } else {
            set.add(e);
        }

        System.out.println(set);
        return e;
    }

    public static void main(String[] args) {

        Integer arr[] = { 1, 2, 2 };

        int sum = 0;

        for (int i = 0; i < arr.length; i++) {

            sum = sum + MinUniqueArraySum.makeUnique(arr[i]);
        }
        System.out.println("::::sume:::" + sum);//6
    }

}
