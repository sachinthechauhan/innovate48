package test.queue;

/**
 * https://www.geeksforgeeks.org/queue-interface-java/
 */

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {

    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<Integer>();
        queue.add(44);
        queue.add(22);
        queue.add(33);

        System.out.println(":::Print Elemnts::" + queue);
        queue.remove();// remove elemnt from head
        queue.remove(22);
        System.out.println(":::Print Elemnts::" + queue);

        // To view the head of queue 
        int head = queue.peek();
        System.out.println("head of queue-" + head);
    }

}
