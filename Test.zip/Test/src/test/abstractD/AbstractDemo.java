package test.abstractD;

interface Demo {
    public void display();

}

abstract class Graphic implements Demo {
    /* Graphic(int a) {
        System.out.println(":::in parametrized constru...");
    }*/
    // private construtor not allowed.
    Graphic() {
        System.out.println(":::in deafult constru...");
    }

    public int a = 5;

    public static int aaa = 5;

    public static final int aa = 5;

    private int c = 5;

    public abstract void draw();
}

class Foo extends Graphic {

    @Override
    public void draw() {
        System.out.println(":::" + a);

    }

    @Override
    public void display() {
        // TODO Auto-generated method stub

    }

}

public class AbstractDemo {

    public static void main(String[] args) {
        new Foo().draw();

    }

}
