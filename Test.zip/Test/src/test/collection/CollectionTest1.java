package test.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

/**
 * Testing the collection mewthod vs iterator method
 * @author iid
 *
 */
public class CollectionTest1 {

    public static void main(String[] args) {

        List<String> list = new ArrayList<>();
        list.add("sachin");
        list.add("First");
        list.add("Second");
        list.add("Third");
        list.add("Four");
        list.add("B");
        list.add("A");
        //        attempt1WithIterator(list);

        // using enumeration

        attempt2WithEnumeration(list);
        System.out.println("::::::" + list);

    }

    private static void attempt2WithEnumeration(List<String> list) {
        Enumeration<String> enumeration = Collections.enumeration(list);

        while (enumeration.hasMoreElements()) {
            String string = (String) enumeration.nextElement();
            if (string.equalsIgnoreCase("Second")) {
                //                list.remove(string);// CME throw
            }
            System.out.println(":::" + string);

        }
    }

    private static void attempt1WithIterator(List<String> list) {
        // using iterator
        Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()) {
            String element = iterator.next();
            if (element.equalsIgnoreCase("Second")) {
                iterator.remove();// safe method we can use no exception
                //                list.remove(3);// CME if use this 
            }

        }
    }

}
