package test.collection;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.concurrent.CopyOnWriteArrayList;

public class NullValueTest {

    public static void main(String[] args) {

        HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put(null, null);// allow one null as key
        System.out.println(":::Size of Map::" + hashMap.size() + "::::" + hashMap);

        Hashtable<String, Integer> hashtable = new Hashtable<>();
        //        hashtable.put(null, null);//NullPointerException as run time exception will throw, No CTE

        CopyOnWriteArrayList<String> clist = new CopyOnWriteArrayList<>();
        clist.add("sachin");
        clist.add(null);// working
        System.out.println("::size of CopyList::::" + clist);
    }

}
