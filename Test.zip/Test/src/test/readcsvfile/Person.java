package test.readcsvfile;

import java.util.Objects;

public class Person {

    private String name;

    private String address;

    private Long mob;

    private double amount;

    private char gender;

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }
        if (this == obj) {
            return true;
        }
        Person personObj = (Person) obj;

        boolean propertyCheck = this.name.equals(personObj.name) && this.address.equals(personObj.address)
                && this.mob.equals(personObj.mob) && this.gender == personObj.gender;

        return propertyCheck;
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, address, mob, gender);
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the mob
     */
    public Long getMob() {
        return mob;
    }

    /**
     * @param mob the mob to set
     */
    public void setMob(Long mob) {
        this.mob = mob;
    }

    /**
     * @return the amount
     */
    public double getAmount() {
        return amount;
    }

    /**
     * @param amount the amount to set
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * @return the gender
     */
    public char getGender() {
        return gender;
    }

    /**
     * @param gender the gender to set
     */
    public void setGender(char gender) {
        this.gender = gender;
    }
}
