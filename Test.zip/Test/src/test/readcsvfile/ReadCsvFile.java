package test.readcsvfile;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Sort map by value with java 8
 * https://dzone.com/articles/how-to-sort-a-map-by-value-in-java-8
 * https://www.mkyong.com/java/how-to-sort-a-map-in-java/
 * @author iid
 *
 */

public class ReadCsvFile {

    public static void main(String[] args) {

        readcsvFile();
        System.out.println(PersonHandler.map);
        // sort map with key can be use by put value in tree map..nothing more required
        // sort map with value
        //        sortMapByValue();
        sortMapByValueWithJava8();
        //        sortMapByValueWithJava82();
        printMap();
        // write csv file
        WriteCsvFile.writeCSVFile();

    }

    private static void printMap() {
        Set<Person> map = PersonHandler.map.keySet();
        for (Person person : map) {
            System.out.println(person.getName() + "  " + PersonHandler.map.get(person));
        }
    }

    private static void sortMapByValue() {
        List<Entry<Person, Double>> entries = new ArrayList<>(PersonHandler.map.entrySet());
        Collections.sort(entries, new Comparator<Entry<Person, Double>>() {
            @Override
            public int compare(Entry<Person, Double> o1, Entry<Person, Double> o2) {
                return o2.getValue().compareTo(o1.getValue());
            }
        });
        // loop and put linkdes hash map
        LinkedHashMap<Person, Double> hashMap = new LinkedHashMap<>();
        for (Entry<Person, Double> entry : entries) {
            hashMap.put(entry.getKey(), entry.getValue());
        }
        PersonHandler.map = hashMap;
    }

    /**
     * With Java 8  descending oreder
     */
    private static void sortMapByValueWithJava8() {
        List<Entry<Person, Double>> entries = new ArrayList<>(PersonHandler.map.entrySet());

        PersonHandler.map = entries.stream().sorted((o1, o2) -> o2.getValue().compareTo(o1.getValue()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));
    }

    // attempt 2
    private static void sortMapByValueWithJava82() {
        List<Entry<Person, Double>> entries = new ArrayList<>(PersonHandler.map.entrySet());

        PersonHandler.map = entries.stream().sorted((Map.Entry.comparingByValue()))
                .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e1, LinkedHashMap::new));

    }

    private static void readcsvFile() {
        File directory = new File("./");
        System.out.println(":::" + directory.getAbsolutePath());
        String line = "";

        String path = "/home/iid/workspace/Test/src/test/readcsvfile/Csv_test.csv";
        String csvSplitBy = ",";
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            // skip header
            br.readLine();
            while ((line = br.readLine()) != null) {
                String[] array = line.split(csvSplitBy);
                Person person = new Person();
                person.setName(array[0]);
                person.setAddress(array[1]);
                person.setMob(Long.valueOf(array[2].trim()));
                person.setAmount(Double.valueOf(array[3]));
                person.setGender(array[4].charAt(0));
                if (PersonHandler.map.containsKey(person)) {
                    PersonHandler.map.put(person, PersonHandler.map.get(person) + Double.valueOf(array[3]));
                } else {
                    PersonHandler.map.put(person, Double.valueOf(array[3]));
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
