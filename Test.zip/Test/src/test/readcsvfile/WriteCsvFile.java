package test.readcsvfile;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Map.Entry;

/**
 * https://examples.javacodegeeks.com/core-java/writeread-csv-files-in-java-example/
 * @author iid
 *
 */
public class WriteCsvFile {

    private static final String COMMA_DELIMITER = ",";

    private static final String NEW_LINE_SEPARATOR = "\n";

    //CSV file header
    private static final String FILE_HEADER = "Name, Address, Mobile, Amount, Gender";

    private static final String OutPut_File = "/home/iid/workspace/Test/src/test/readcsvfile/OutPut_test.csv";

    public static void writeCSVFile() {
        try (FileWriter fw = new FileWriter(OutPut_File)) {
            // Add Header
            fw.append(FILE_HEADER);

            //Add a new line separator after the header
            fw.append(NEW_LINE_SEPARATOR);

            for (Entry<Person, Double> entry : PersonHandler.map.entrySet()) {
                Person person = entry.getKey();
                fw.append(person.getName());
                fw.append(COMMA_DELIMITER);
                fw.append(person.getAddress());
                fw.append(COMMA_DELIMITER);
                fw.append(person.getMob() + "");
                fw.append(COMMA_DELIMITER);
                fw.append(entry.getValue() + "");
                fw.append(COMMA_DELIMITER);
                fw.append(person.getGender());
                fw.append(NEW_LINE_SEPARATOR);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
