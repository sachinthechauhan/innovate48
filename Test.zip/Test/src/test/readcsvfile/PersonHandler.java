package test.readcsvfile;

import java.util.HashMap;
import java.util.Map;

public class PersonHandler {

    public static Map<Person, Double> map = new HashMap<>();

}
