package test.bst;

/**
 * https://www.geeksforgeeks.org/binary-search-tree-set-1-search-and-insertion/
 * @author iid
 *
 */

public class BinarySearchTree {

    Node root;

    class Node {
        Node left, right;

        int key;

        Node(int key) {
            this.key = key;
            left = null;
            right = null;
        }

    }

    // add node 
    public void insert(int key) {
        // assign =root as first value of root can assign only
        root = insertInBST(root, key);
        //        System.out.println("::;Leaf Node before Insert: " + root.key);
    }

    // search node

    /** This is recursive function
     * time Comp : O(n)
     * Space Comp: O(n)
     * @param key
     * @return
     */
    public Node insertInBST(Node root, int key) {

        /* when tree is empty as no key in BST..return new node ..basicaly its help new at leaf node*/
        if (root == null) {
            root = new Node(key);
            return root;
        }
        /*..key > root key then need to traverse in right part*/
        if (key > root.key) {

            root.right = insertInBST(root.right, key);
        } else if (key < root.key) {

            root.left = insertInBST(root.left, key);
        }
        // return unchanged node
        return root;

    }

    public void delete(int key) {
        deleteInBST(root, key);
    }

    /**
     * Delete node in BST
     * Time Comple : O(n)
     * Space Comp: O(n)
     * @param root
     * @param key
     * @return
     */
    public Node deleteInBST(Node root, int key) {

        if (root == null) {
            return root;
        } else if (key > root.key) {
            Node nd = deleteInBST(root.right, key);
            System.out.println(":Right::" + nd);
            root.right = nd;
        } else if (key < root.key) {
            Node nd = deleteInBST(root.left, key);
            System.out.println(":Left::" + nd);
            if (nd != null) {
                System.out.println(":Left::" + nd.key);
            }
            root.left = nd;
        } else {
            /* node is leaf node or have only one child*/
            if (root.left == null) {
                return root.left;
            } else if (root.right == null) {
                return root.right;
            } else {
                // if node have two child
                // find min value  in right sub tree...left most value will be min in right sub tree
                int minValue = minElementValueNonRecursive(root.right);
                // node with two children: Get the inorder successor (smallest 
                // in the right subtree) 
                root.key = minValue;

                // Delete the inorder successor 
                root.right = deleteInBST(root.right, root.key);

            }

        }

        return root;
    }

    // traverse in BST 

    public void traverse() {
        inOrderTraverse(root);
        //        inOrderTraverse2(root);
    }

    /**
     * Left root right
     * @param root
     */
    public void inOrderTraverse(Node root) {
        if (root != null) {
            inOrderTraverse(root.left);
            System.out.println(root.key);
            inOrderTraverse(root.right);
        }
    }

    /**
     * Second attempt
     * @param root
     */
    public void inOrderTraverse2(Node root) {
        if (root != null) {
            if (root.left != null) {
                inOrderTraverse(root.left);
            }
            System.out.println(root.key);
            if (root.right != null) {
                inOrderTraverse(root.right);
            }
        }
    }

    /**
     * Fetch most left elemnt as left most element will be the minimum
     */
    public void minElementNonRecursive() {
        Node minNode = minElementNonRecursive(root);
        if (minNode != null) {
            System.out.println("::::Min Value::" + minNode.key);
        }
    }

    public Node minElementNonRecursive(Node root) {

        if (root == null) {
            return root;
        }

        while (root.left != null) {
            root = root.left;
        }
        return root;
    }

    /**
     * time compl: o(n)
     * Space Compl: o(1)
     * @param root
     * @return
     */
    public int minElementValueNonRecursive(Node root) {

        while (root.left != null) {
            root = root.left;
        }
        return root.key;
    }

    /**
     * Fetch most right element as right most element will be the minimum
     */
    public void maxElementNonRecursive() {
        Node maxNode = maxElementNonRecursive(root);
        if (maxNode != null) {
            System.out.println("::::Max Value::" + maxNode.key);
        }
    }

    /**
     * time compl: o(n)
     * Space Compl: o(1)
     * @param root
     * @return
     */
    public Node maxElementNonRecursive(Node root) {

        if (root == null) {
            return root;
        }

        while (root.right != null) {
            root = root.right;
        }
        return root;
    }

    public void findElement(int key) {
        Node searchEle = findElementRec(root, key);
        if (searchEle != null && searchEle.key == key) {
            System.out.println(":::element found:::");
        } else {
            System.out.println(":::not Found....");
        }

    }

    /**
     * Complexity: O(n)
     * Space Comp: O(n)- due to recursive stack
     * @param key
     */
    public Node findElementRec(Node root, int key) {
        if (root == null) {
            return root;
        }
        if (key > root.key) {
            return findElementRec(root.right, key);
        } else if (key < root.key) {
            return findElementRec(root.left, key);
        }
        return root;
    }

    /**
     * Complexity: O(n)
     * Space Comp: O(1)-
     */
    public Node findElementNonRec(Node root, int key) {
        if (root == null) {
            return root;
        }
        while (root != null) {
            if (root.key == key) {
                return root;
            }
            if (key > root.key) {
                root = root.right;
            } else if (key < root.key) {
                root = root.left;
            }
        }
        return null;
    }

    // delete node

    // duplicate node

}
