package test.bst;

public class BST_Test {

    public static void main(String[] args) {

        BinarySearchTree tree = new BinarySearchTree();

        /*  tree.insert(50);
        tree.insert(30);
        tree.insert(20);
        tree.insert(40);
        tree.insert(70);
        tree.insert(60);
        tree.insert(80);
        
        // traverse in BST
        tree.traverse();
        //        tree.delete(30);
        //        System.out.println("::::after Del 40::");
        //        tree.traverse();
        //        tree.findElement(300);
        
        //        tree.maxElementNonRecursive();
        //        tree.minElementNonRecursive();
        */

        tree.insert(20);
        tree.insert(15);
        tree.insert(13);
        tree.insert(16);
        tree.insert(30);
        tree.insert(24);
        tree.insert(35);
        //        tree.traverse();
        tree.delete(13);

    }

}
