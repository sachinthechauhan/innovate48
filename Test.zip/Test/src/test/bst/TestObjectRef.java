package test.bst;

class Test {

    public String str;
}

public class TestObjectRef {

    public static Test testObjectRef(Test test) {
        test = new Test();
        test.str = "in method";
        return test;
    }

    /**
     * java use address as a value
     * @param a
     * @param b
     */
    public static void swap(int a, int b) {
        int temp = a;
        a = b;
        b = temp;
        System.out.println("a::" + a + "::b:::" + b);
    }

    public static void main(String[] args) {
        Test tst = new Test();
        tst.str = "In main Method";
        System.out.println("::Before::" + tst.str);
        //        testObjectRef(tst) no value changed
        tst = testObjectRef(tst);//untill re assign no value of chnage object
        System.out.println("::after::" + tst.str);

        int a = 6, b = 7;
        System.out.println("before  a::" + a + "::b:::" + b);
        swap(a, b);
        System.out.println("after : a::" + a + "::b:::" + b);

    }

}
