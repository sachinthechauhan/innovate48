
package test.designpattern;

import java.io.Serializable;

public class SerializedSingleton implements Serializable {

    private static final long serialVersionUID = -7604766932017737115L;

    private SerializedSingleton() {
        System.out.println("::in conctructor :::");
    }

    private static class SingletonHelper {
        private static final SerializedSingleton instance = new SerializedSingleton();
    }

    public static SerializedSingleton getInstance() {
        return SingletonHelper.instance;
    }

    /**
     *  Even though the constructor is private, the serializable tools have special 
     *  access to create instances of a class regardless....
     *  
     * implemnt this method to avoid to create a new object during serliazation 
     * The readResolve method is called when ObjectInputStream has read an object 
     * from the stream and is preparing to return it to the caller. ObjectInputStream checks
     *  whether the class of the object defines the readResolve method. If the method is defined,
     *   the readResolve method is called to allow the object in the stream to designate the object 
     *   to be returned. The object returned should be of a type that is compatible with all uses. 
     *   If it is not compatible, a ClassCastException will be thrown when the type mismatch is discovered.
     * @return
     */
    protected Object readResolve() {
        return getInstance();
    }
}
