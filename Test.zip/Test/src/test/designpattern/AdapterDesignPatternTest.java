package test.designpattern;

interface Bird {
    public void fly();

    public void makeSound();
}

class Crow implements Bird {

    @Override
    public void fly() {
        System.out.println(":::crow is flying......");
    }

    @Override
    public void makeSound() {
        System.out.println(":::crow is doing coo coo.....");
    }

}

// new interface

interface ToyDuck {
    public void toySound();
}

class PlasticToyDuck implements ToyDuck {

    @Override
    public void toySound() {
        System.out.println("::::toy sound.....");
    }

}

// Client req as Toy  make sound as bird so need to create a adapter ToyDuck and Bird interface.

class BirdAdapter implements ToyDuck {
    Bird bird;

    BirdAdapter(Bird bird) {
        this.bird = bird;
    }

    @Override
    public void toySound() {
        bird.makeSound();
    }
}

public class AdapterDesignPatternTest {

    public static void main(String[] args) {

        ToyDuck duck = new PlasticToyDuck();
        duck.toySound();

        // using adapter design pattern
        Crow crow = new Crow();
        ToyDuck duck2 = new BirdAdapter(crow);
        duck2.toySound();
    }

}
