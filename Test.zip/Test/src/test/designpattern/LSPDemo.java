package test.designpattern;

/**
 * In mathematics, a Square is a Rectangle. Indeed it is a specialization of a rectangle. The "is a" makes you want to model this with inheritance. However if in code you made Square derive from Rectangle, then a Square should be usable anywhere you expect a Rectangle. This makes for some strange behavior.

Imagine you had SetWidth and SetHeight methods on your Rectangle base class; this seems perfectly logical. However if your Rectangle reference pointed to a Square, then SetWidth and SetHeight doesn't make sense because setting one would change the other to match it. In this case Square fails the Liskov Substitution Test with Rectangle and the abstraction of having Square inherit from Rectangle is a bad one
 * @author iid
 *
 */
class Rectangle {
    private int length;

    private int breadth;

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getBreadth() {
        return breadth;
    }

    public void setBreadth(int breadth) {
        this.breadth = breadth;
    }

    public int getArea() {
        return this.length * this.breadth;
    }
}

class Square extends Rectangle {
    @Override
    public void setBreadth(int breadth) {
        super.setBreadth(breadth);
        super.setLength(breadth);
    }

    @Override
    public void setLength(int length) {
        super.setLength(length);
        super.setBreadth(length);
    }
}

public class LSPDemo {

    public void calculateArea(Rectangle r, int length, int width) {
        r.setBreadth(length);
        r.setLength(width);
        System.out.println(":::::" + r.getArea());
    }

    public static void main(String[] args) {
        LSPDemo demo = new LSPDemo();
        demo.calculateArea(new Rectangle(), 2, 3);

        demo.calculateArea(new Square(), 2, 3);

    }

}
