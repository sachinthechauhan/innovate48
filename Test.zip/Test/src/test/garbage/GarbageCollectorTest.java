package test.garbage;

/**
 * There is no guarantee that any one of above two methods will definitely run Garbage Collector.
The call System.gc() is effectively equivalent to the call : Runtime.getRuntime().gc()
 * @author iid
 *
 */
class GarbageCollectorDemo {

    @Override
    protected void finalize() throws Throwable {
        System.out.println("Garbage collector called");
        System.out.println("Object garbage collected : " + this);
        super.finalize();
    }

    public void test(B b) {
        System.out.println(":: test method called....");
    }

}

class B {

}

public class GarbageCollectorTest {

    static void start() {
        GarbageCollectorDemo a = new GarbageCollectorDemo();
        B b = new B();
        a.test(b);
        b = null; /* Line 5 */
        a = null; /* Line 6 */
        System.out.println("start completed"); /* Line 7 */
        System.gc();
    }

    public static void main(String[] args) {
        //        attempt1();
        start();
        // requesting JVM for running Garbage Collector 

    }

    private static void attempt1() {
        GarbageCollectorDemo collectorDemo = new GarbageCollectorDemo();
        GarbageCollectorDemo collectorDemo2 = new GarbageCollectorDemo();
        collectorDemo = null;
        // requesting JVM for running Garbage Collector 
        System.gc();
        // Nullifying the reference variable 
        collectorDemo2 = null;

        // requesting JVM for running Garbage Collector 
        Runtime.getRuntime().gc();
    }

}
