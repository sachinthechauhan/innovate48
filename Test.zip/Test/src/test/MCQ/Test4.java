package test.MCQ;

public class Test4 {

    public static void main(String[] args) {

        short s = 0;
        int x = 07;
        //        int y = 08;
        int y = 0;
        int z = 112345;

        s += z;
        System.out.println("" + x + y + s);
        int a = 10;
        int b = 20;
        System.out.println("::" + a + b);// convert to string
        System.out.println(a + b);//30

    }

}
