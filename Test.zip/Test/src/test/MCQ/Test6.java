package test.MCQ;

public class Test6 {

    public static void gfg(String s) {
        System.out.println("String");
    }

    public static void gfg(Object o) {
        System.out.println("Object");
    }

    public static void gfg(Integer i) {
        System.out.println("Integer");
    }

    public static void gfg(int i) {
        System.out.println("Int");
    }

    public static void gfg(long i) {
        System.out.println("Long");
    }

    public static void main(String[] args) {
        //        gfg(null);// CE as ambigius
        gfg(29);// Int
    }

}
