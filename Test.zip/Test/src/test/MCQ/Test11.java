package test.MCQ;

public class Test11 {

    public static void main(String[] args) {

        Integer a = 127;
        Integer b = 127;
        boolean flag = a == b;
        System.out.println(":::" + flag);

        int i1 = 1000;
        Integer i2 = 1000;
        Integer i3 = new Integer(1000);
        System.out.println(i1 == i2);
        System.out.println(i3 == i2);
        System.out.println(i1 == i3);
    }
}
