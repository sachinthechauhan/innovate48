package test.MCQ;

class Gfg2 {
    // constructor 
    Gfg2() {
        System.out.println("Geeksforgeeks");
    }

    static Gfg2 a = new Gfg2(); //line 8 
    /**
     *Gfg a = new Gfg();
     *simple it will create over flow error as stack flow error 
     */
}

public class Test5 {

    public static void main(String[] args) {

        //        String str = "sachin";
        //        System.out.println(str.substring(2));
        Gfg2 b; //line 12 
        b = new Gfg2();
    }

}
