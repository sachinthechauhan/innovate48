package test.MCQ;

class Test {
    protected int x, y;
}

class Point {
    protected int x, y;

    public Point(int _x, int _y) {
        x = _x;
        y = _y;
    }
}

public class JavaProgrammingOutput {

    public static void main(String[] args) {
        Test test = new Test();
        System.out.println(test.x + ":::" + test.y);// access as becoz x & Y protected.

        for (int i = 0; true; i++) {
            System.out.println("Hello");
            break;
        }

        /*for (int i = 0; 1; i++) {// CTE
            System.out.println("Hello");
            break;
        }*/

        // Question 3

        //        Point point=new Point();// no deafult construcotr as CE error will showing

        // quest -4

    }

}
