package test.MCQ;

public class MCQ11

{
    public static void main(String args[]) {

        String str = "SACHIN";
        String strRev = "";
        char[] arr = str.toCharArray();
        for (int i = arr.length - 1; i >= 0; i--) {
            strRev = strRev.concat(arr[i] + "");
        }
        System.out.println("" + strRev);
    }
}
