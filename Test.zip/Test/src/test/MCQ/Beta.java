package test.MCQ;

class Alpha {
    public String type = "a ";

    public int a = 10;

    public Alpha() {
        System.out.print("alpha " + type);
    }
}

public class Beta extends Alpha {
    public Beta() {
        System.out.print("beta ");
    }

    void go() {
        type = "b ";
        a = 20;
        System.out.print(this.type + super.type);
        System.out.print("" + this.a + super.a);
    }

    public static void main(String[] args) {

        new Beta().go();
    }
}