package test.MCQ;

public class TestArray {

    public static void main(String[] args) {
        int[] x = new int[3];
        System.out.println("x[0] is " + x[2]);

    }

}
