package test.MCQ;

import java.util.HashMap;

class Test1 {
    Test1(int x) {
        System.out.println("Constructor called " + x);
    }
}

public class Test2 {

    Test1 t1 = new Test1(10);

    Test2(int i) {
        t1 = new Test1(i);
    }

    public static void main(String[] args) {
        Test2 t2 = new Test2(5);

        int sum = 0;
        for (int i = 0; i < 20; i++) {
            sum += i;
        }
        /*for (int i = 0; i < 100; i++) {
            sum += i;
        }*/

        if (sum > 0) {
            System.out.println("::::::::::::::;in if::::::::");
        }
        System.out.println("::::" + sum);

        HashMap<Integer, Integer> hashMap = new HashMap<>(12000, 1);

    }

}
