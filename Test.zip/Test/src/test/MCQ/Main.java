package test.MCQ;

class Base {
    public int i = 20;

    public void show() {
        System.out.println("Base::show() called");
    }
}

class Derived extends Base {
    /**
    * 
    */
    int i = 10;

    public void show() {
        System.out.println("Derived::show() called " + i);
    }
}

public class Main {
    public static void main(String[] args) {
        Base b = new Derived();
        b.show();
        System.out.println(":::::" + b.i);
    }
}