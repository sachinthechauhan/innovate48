package test.string;

public class StringTest1 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        String str = "Sachin";
        //        boolean check='A'<= str.charAt(0);
        int index = str.charAt(1) - 'A';
        System.out.println(":::sindex::" + index);

        int index2 = 'A';// Print 65
        int index3 = 'a';// Print 97
        System.out.println(":::sindex::" + index3);
        System.out.println();

    }

}
