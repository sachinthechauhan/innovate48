package test.internalworking;

import java.util.HashMap;

class Person3 {

    private String name;

    private Integer mob;

    public Person3(String name, Integer mob) {
        super();
        this.name = name;
        this.mob = mob;
    }

    @Override
    public int hashCode() {
        // TODO Auto-generated method stub
        return 0;
    }

}

class Person2 {

    private String name;

    private Integer mob;

    public Person2(String name, Integer mob) {
        super();
        this.name = name;
        this.mob = mob;
    }

    /*  @Override
    public int hashCode() {
        // TODO Auto-generated method stub
        return Objects.hash(name, mob);
    }*/

    @Override
    public boolean equals(Object obj) {

        if (obj.getClass() != this.getClass() || obj == null)
            return false;
        if (obj == this) {
            return true;
        }
        Person2 psrson = (Person2) obj;

        return psrson.name.equals(this.name) && psrson.mob.equals(this.mob);
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the mob
     */
    public Integer getMob() {
        return mob;
    }

    /**
     * @param mob the mob to set
     */
    public void setMob(Integer mob) {
        this.mob = mob;
    }
}

public class HashMapTest {

    public static void main(String[] args) {

        /*  HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put(null, null);
        
        HashSet hashSet = new HashSet<>();
        hashSet.add("First");
        hashSet.add("first");
        System.out.println(":::" + hashSet.size() + "");*/
        Person2 person1 = new Person2("Sachin", 1234);
        Person2 person2 = new Person2("Sachin", 1234);

        HashMap<Person2, Integer> hashMap = new HashMap<>();
        hashMap.put(person1, 12);
        //        hashMap.put(person2, 20);

        System.out.println(person1.hashCode() + "::::" + person2.hashCode());

        System.out.println("::Size:::" + hashMap.size());
        person1.setName("Kumar");// hash code will change as default imple

        System.out.println(person1.hashCode() + "::::" + person2.hashCode());
        System.out.println("::Get::::" + hashMap.get(person1));

        //        TreeMap<Person3, Integer> treeMap3 = new TreeMap();
        //
        //        Person3 p1 = new Person3("Sachin", 25);
        //        Person3 p2 = new Person3("Sachin", 25);
        //
        //        treeMap3.put(p1, 12);
        //        treeMap3.put(p2, 15);
        //
        //        System.out.println("::::::::::::" + treeMap3.size());

        Person3 p1 = new Person3("Sachin", 25);
        Person3 p2 = new Person3("Sachi2", 25);
        HashMap<Person3, Integer> hashMap2 = new HashMap<>();
        hashMap2.put(p1, 10);
        hashMap2.put(p2, 11);
        System.out.println("::::sizee::::::" + hashMap2.size());

        System.out.println("::::Get:::::::" + hashMap2.get(p2));

    }

}
