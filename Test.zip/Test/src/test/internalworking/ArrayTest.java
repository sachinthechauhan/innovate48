package test.internalworking;

import java.util.Arrays;

public class ArrayTest {

    private static void removeElementFromArray(Integer[] arr, int index) {
        if (index < arr.length) {
            int actLength = arr.length - 1;
            int temp = index;
            while (temp < actLength) {
                arr[temp] = arr[temp + 1];
                arr[temp + 1] = 0;
                temp++;
            }
        } else {
            throw new IndexOutOfBoundsException();
        }

    }

    public static void main(String[] args) {

        Integer[] arr = { 1, 2, 3, 4, 5, 6, 7 };

        removeElementFromArray(arr, 2);

        System.out.println(":::::" + Arrays.toString(arr));
        ;
    }

}
