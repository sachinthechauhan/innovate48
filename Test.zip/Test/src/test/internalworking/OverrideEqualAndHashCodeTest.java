package test.internalworking;

import java.util.HashMap;
import java.util.Objects;

class Person {
    private String name;

    private Integer id;

    Person(String name, Integer id) {
        this.name = name;
        this.id = id;
    }

    @Override
    public boolean equals(Object obj) {

        if (obj == null) {
            return false;
        }
        if (this == obj) {
            return true;

        }
        Person personObj = (Person) obj;

        boolean propertyCheck = this.name.equals(personObj.name) && this.id.equals(personObj.id);

        return propertyCheck;
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, id);
    }

}

public class OverrideEqualAndHashCodeTest {

    public static void main(String[] args) {

        Person person = new Person("Sachin", 12);
        Person person2 = new Person("Sachin", 12);
        Person person3 = new Person("Sachin", 13);
        System.out.println(person.equals(person2));// true
        System.out.println(person.equals(person3));// false
        HashMap<Person, Integer> hashMap = new HashMap<>();
        hashMap.put(person, 1);
        hashMap.put(person2, 2);
        hashMap.put(person3, 2);
        System.out.println("::Size of map::" + hashMap.size());//2

    }

}
