package test.internalworking;

import java.util.Arrays;

class CustomList {

    private int actSize = 0;

    private Object[] storeArray;

    CustomList(int size) {

        storeArray = new Object[size];
    }

    public void add(Object obj) {

        if (storeArray.length - actSize <= 5) {
            increaseListSize();
        }
        storeArray[actSize++] = obj;
    }

    public Object get(int index) {

        if (index < actSize) {
            return storeArray[index];
        } else {
            throw new IndexOutOfBoundsException();
        }

    }

    public Object remove(int index) {
        Object object = storeArray[index];
        int temp = index;
        while (temp < actSize) {
            storeArray[temp] = storeArray[temp + 1];
            temp++;
        }
        actSize--;
        return object;
    }

    public int size() {
        return actSize;
    }

    private void increaseListSize() {
        storeArray = Arrays.copyOf(storeArray, storeArray.length * 2);
        System.out.println("\nNew length: " + storeArray.length);
    }

}

public class CustomListTest {

    public static void main(String[] args) {
        CustomList customList = new CustomList(10);
        customList.add(12);
        customList.add(14);
        customList.add(15);
        customList.add(16);
        customList.remove(2);
        for (int i = 0; i < customList.size(); i++) {
            System.out.print(customList.get(i) + " ");
        }
    }

}
