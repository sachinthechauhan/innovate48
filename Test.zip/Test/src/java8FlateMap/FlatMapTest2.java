package java8FlateMap;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

class Book {

	String name;
	Set<String> writterName;

	public Book(String name, Set<String> writterName) {
		super();
		this.name = name;
		this.writterName = writterName;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the writterName
	 */
	public Set<String> getWritterName() {
		return writterName;
	}

	/**
	 * @param writterName
	 *            the writterName to set
	 */
	public void setWritterName(Set<String> writterName) {
		this.writterName = writterName;
	}

}

public class FlatMapTest2 {

	public static void main(String[] args) {

		HashSet<String> hashSet = new HashSet<>();
		hashSet.add("Sachin");
		hashSet.add("Rahul");

		HashSet<String> hashSet2 = new HashSet<>();
		hashSet2.add("Kumar");
		hashSet2.add("Rahul");

		HashSet<String> hashSet3 = new HashSet<>();
		hashSet3.add("rajnesh");
		hashSet3.add("singh");

		Book java = new Book("Java", hashSet);
		Book c = new Book("c", hashSet2);
		Book science = new Book("science", hashSet3);

		List<Book> booksList = Arrays.asList(java, c, science);

		// get all writer name

		booksList.stream().map(e -> e.getWritterName()).flatMap(x -> x.stream()).distinct()
				.forEach(e -> System.out.println("W Name: " + e));
	}

}
