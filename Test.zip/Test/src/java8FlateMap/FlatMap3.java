package java8FlateMap;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class FlatMap3 {

	public static void main(String[] args) {

		int[] intArray = { 1, 6, 3, 5, 4, 0 };

		// 1. Stream<int[]>
		Stream<int[]> streamArray = Stream.of(intArray);

		// 2. Stream<int[]> -> flatMap -> IntStream
		IntStream intStream = streamArray.flatMapToInt(x -> Arrays.stream(x)).sorted();

		intStream.forEach(e -> System.out.println(e));

		List<String> list = Arrays.asList("sachin", "kumar", "kk", "tt");
		Stream<String> stream = list.stream();
		stream.forEach(e -> System.out.println(e));

	}

}
