package java8FlateMap;

import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FlatMapTest {

	public static void main(String[] args) {

		List<String> list = Arrays.asList("foo", "bar", "jar");
		List<String[]> uniqueList = list.stream().map(e -> e.split("")).distinct().collect(Collectors.toList());
		System.out.println("::::" + uniqueList);

		uniqueList.forEach(e -> {
			for (String strings : e) {
				// System.out.println("dist ele: " + strings);
			}
		});
		// Use of flat map
		uniqueList.stream().flatMap(Arrays::stream).distinct().forEach(e -> System.out.println(e));

		Stream<List<Integer>> integerListStream = Stream.of(Arrays.asList(1, 2), Arrays.asList(3, 4), Arrays.asList(5));

		Stream<Integer> integerStream = integerListStream.flatMap(Collection::stream);
		integerStream.forEach(System.out::println);

	}

}
