package java8.practise;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class KthHighestElement {

    public static void main(String[] args) {

        List<Integer> listofNumbers = Arrays.asList(2, 4, 3, 9, 8, 5, 6, 3, 11, 15, 14, 13);

        // kth highest element..

        listofNumbers.stream().distinct().sorted().forEach(e -> System.out.print(e + "  "));

        System.out.println("after..........");

        //        listofNumbers.stream().distinct().sorted().skip(4).forEach(e -> System.out.print(e + "  "));

        Integer kethElement = listofNumbers.stream().distinct().sorted().skip(4).collect(Collectors.toList()).get(0);

        System.out.println(":kethElement::::::" + kethElement);

    }
}
