package java8.practise;

public class RunnableTest {

    public static void main(String[] args) {
        final int a = 5;
        int b = 5;//implicitly final
        Thread th = new Thread(() -> System.out.println(";:in run method::" + a + b));
        th.start();
    }

}
