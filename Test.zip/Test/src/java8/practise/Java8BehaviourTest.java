package java8.practise;

@FunctionalInterface
interface Operation {

    public abstract int apply(int a, int b);
}

class Logic {

    public int applyLogic(int a, int b, Operation operation) {
        return operation.apply(a, b);
    }
}

public class Java8BehaviourTest {

    public static void main(String[] args) {
        Logic logic = new Logic();

        int sum = logic.applyLogic(5, 10, new Operation() {

            @Override
            public int apply(int a, int b) {

                return a + b;
            }
        });

        // without lamda expression
        System.out.println("::::" + sum);

        sum = logic.applyLogic(25, 10, (int a, int b) -> a + b);
        sum = logic.applyLogic(15, 10, (a, b) -> a + b);
        System.out.println(":::" + sum);

    }

}
