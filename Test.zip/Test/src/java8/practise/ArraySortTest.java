package java8.practise;

import java.util.Arrays;
import java.util.Comparator;

public class ArraySortTest {

    public static void main(String[] args) {

        Integer[] arr = { 1, 8, 2, 3, 5, 6, 7 };
        Integer[] arr2 = { 10, 11 };

        String[] str = { "sachin", "kumar", "ishi", "meenakshi" };

        Arrays.sort(arr, new Comparator<Integer>() {

            @Override
            public int compare(Integer o1, Integer o2) {
                return o1 - o2;
            }
        });
        //or

        Arrays.sort(str, (String o1, String o2) -> (o1.length() - o2.length()));

        //        Arrays.stream(arr).forEach(e -> System.out.println(e));
        //
        //        Arrays.stream(str).forEach(e -> System.out.println(e));

    }

}
