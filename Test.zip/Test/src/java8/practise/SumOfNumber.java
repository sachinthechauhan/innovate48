package java8.practise;

import java.util.stream.IntStream;

/**
 * Find sum of number of multiple of 3 & 5 up to n;
 * 
 * @author iid
 *
 */
public class SumOfNumber {

	public static void main(String[] args) {
		int n = 10;

		int sumOf3 = IntStream.rangeClosed(1, n).filter(e -> e % 3 == 0).sum();
		int sumOf5 = IntStream.rangeClosed(1, n).filter(e -> e % 5 == 0).sum();
		System.out.println("::::" + (sumOf3 + sumOf5));

	}

}
