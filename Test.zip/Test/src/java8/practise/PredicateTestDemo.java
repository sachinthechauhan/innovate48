package java8.practise;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

class Apple {
    private String color;

    private int weight;

    /**
     * @return the color
     */
    public String getColor() {
        return color;
    }

    /**
     * @param color the color to set
     */
    public void setColor(String color) {
        this.color = color;
    }

    /**
     * @return the weight
     */
    public int getWeight() {
        return weight;
    }

    /**
     * @param weight the weight to set
     */
    public void setWeight(int weight) {
        this.weight = weight;
    }

    public Apple(String color, int weight) {
        super();
        this.color = color;
        this.weight = weight;
    }

}

public class PredicateTestDemo {

    public List<Apple> requestApple(List<Apple> apples, Predicate<Apple> predicate) {
        List<Apple> apples2 = new ArrayList<>();
        for (Apple apple : apples) {
            if (predicate.test(apple)) {
                apples2.add(apple);
            }
        }

        return apples2;

    }

    public static void main(String[] args) {
        List<Apple> apples = Arrays.asList(new Apple("green", 500), new Apple("red", 500), new Apple("orange", 500),
                new Apple("yello", 500), new Apple("pink", 500));

        Predicate<Apple> predicate = e -> e.getColor().equals("green");
        PredicateTestDemo demo = new PredicateTestDemo();
        demo.requestApple(apples, predicate).forEach(e -> System.out.println(e.getColor() + "  " + e.getWeight()));
    }

}
