package java8.practise;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class ReductionTest {

    public static void main(String[] args) {

        List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7);

        // summ of all value

        Optional<Integer> sum = list.stream().reduce((a, b) -> a + b);
        System.out.println("::::" + sum.get());

        // use of identity

        Integer sumWithIdentity = list.stream().reduce(2, (a, b) -> a + b);
        System.out.println(":::Sum With Identity::::" + sumWithIdentity);

        // find max
        Optional<Integer> max = list.stream().reduce((a, b) -> a > b ? a : b);
        System.out.println("::Max::" + max.get());

        //  find min
        Optional<Integer> min = list.stream().reduce((a, b) -> a < b ? a : b);
        System.out.println("::Min::" + min.get());

        List<String> strList = Arrays.asList("Sachin", "pritam", "kumar", "dhampurrr", "min");

        String minLength = strList.stream().reduce((s1, s2) -> s1.length() > s2.length() ? s2 : s1).orElse("Default");
        System.out.println(":::min length::" + minLength);

    }
}
