package java8.practise;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class FlatMapDemo {

    public static void main(String[] args) {
        // list of list
        Stream<List<Integer>> integerListStream = Stream.of(Arrays.asList(1, 2), Arrays.asList(3, 4), Arrays.asList(5));

        List<Integer> list = integerListStream.flatMap(e -> e.stream()).collect(Collectors.toList());

        list.stream().forEach(e -> System.out.println(e));

        int[] arr1 = { 2, 3, 5, 67 };
        int[] arr2 = { 4, 5, 6 };
        Stream<int[]> arrStream = Stream.of(arr1, arr2);
        IntStream intStream = arrStream.flatMapToInt(e -> Arrays.stream(e));

        /**
         * Observation: when we convert list to stream then we use .stream()method on that collection
         * For Array:
         * Stream.of provide array of stream and but Arrays.stream(e) provide premitive stream t
         * type as IntStream, LongStream etc..depend on object
         */

        Stream stream = Stream.of(arr2);// nothing to to do
        stream.forEach(e -> System.out.println(e));
    }

}
