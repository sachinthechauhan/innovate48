package operation.dllist;

public class DoubleyLinkedList {
	Node head;

	class Node {
		int data;
		Node next;
		Node prev;

		public Node(int data) {
			super();
			this.data = data;
		}

	}

	public void add(int data) {
		Node newNode = new Node(data);
		if (head == null) {
			head = newNode;
			newNode.next = null;
			newNode.prev = null;
		} else {
			Node lastNode = getLastNode();
			lastNode.next = newNode;
			newNode.prev = lastNode;
		}

	}

	public void addFirst(int data) {

		Node nd = new Node(data);
		nd.next = head;
		head.prev = nd;
		head = nd;
		head.prev = null;
	}

	public void addAfterGivenElement(int data, int newData) {
		Node currentNode = getCurrentNode(data);
		Node newNode = new Node(newData);

		newNode.next = currentNode.next;
		currentNode.next.prev = newNode;

		newNode.prev = currentNode;
		currentNode.next = newNode;
	}

	public Node getLastNode() {
		Node lstNode = head;

		while (lstNode.next != null) {
			lstNode = lstNode.next;
		}
		return lstNode;
	}

	public Node getCurrentNode(int data) {
		Node currNode = head;
		while (currNode.next != null) {

			if (currNode.data == data) {
				return currNode;
			}
			currNode = currNode.next;
		}
		return currNode;

	}

	public void delete(int data) {
		Node delNode = getCurrentNode(data);
		delNode.prev.next = delNode.next;
		delNode.next.prev = delNode.prev;
	}

	public Node reverse() {
		Node prev = null;
		Node current = head;
		Node next = null;
		while (current != null) {
			next = current.next;
			current.prev = next;
			current.next = prev;
			prev = current;
			current = next;
		}
		head = prev;
		return head;
	}

	public void printList() {
		Node nd = head;
		while (nd != null) {
			System.out.print(" " + nd.data);
			nd = nd.next;
		}
	}

}
