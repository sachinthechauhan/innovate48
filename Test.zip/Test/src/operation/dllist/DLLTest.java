package operation.dllist;

public class DLLTest {

	public static void main(String[] args) {

		DoubleyLinkedList doubleyLinkedList = new DoubleyLinkedList();
		doubleyLinkedList.add(5);
		doubleyLinkedList.add(10);
		doubleyLinkedList.add(14);

		doubleyLinkedList.printList();

		doubleyLinkedList.addFirst(11);

		System.out.println();
		doubleyLinkedList.printList();
		doubleyLinkedList.addAfterGivenElement(10, 99);
		System.out.println("--------After insert--99-------");
		doubleyLinkedList.printList();

		doubleyLinkedList.delete(10);
		System.out.println("--------After delete--10-------");
		doubleyLinkedList.printList();

		doubleyLinkedList.reverse();
		System.out.println("--------After Reverse-------");
		doubleyLinkedList.printList();

	}

}
