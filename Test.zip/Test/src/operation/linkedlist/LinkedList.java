package operation.linkedlist;

/**
 * https://www.geeksforgeeks.org/linked-list-set-1-introduction/
 * https://www.geeksforgeeks.org/linked-list-set-2-inserting-a-node/
 * https://www.geeksforgeeks.org/linked-list-set-3-deleting-node/
 * 
 * Go through the linkedlist operation as how internally work
 * 
 * @author iid
 *
 */
public class LinkedList {

    static Node head;// first element

    static class Node {

        int data;

        Node next; // next element

        public Node(int data) {
            super();
            this.data = data;
        }
    }

    public void printListElements() {
        Node n = head;

        while (n != null) {
            n = n.next;

        }

    }

    public void addFirst(int data) {
        Node nd = new Node(data);
        nd.next = head;// link to head
        head = nd;// change value of head

    }

    public void addLast(int data) {
        Node lastNode = head;
        while (lastNode.next != null) {
            lastNode = lastNode.next;
        }
        lastNode.next = new Node(data);
    }

    public void addGivenIndex(Node prevNode, int n) {

        Node newNode = new Node(n);
        Node nextNode = prevNode.next;
        prevNode.next = newNode;
        newNode.next = nextNode;

    }

    public Node getCurrentNode(int data) {
        Node node = head;
        while (node.data != data && node.next != null) {
            node = node.next;
        }
        return node;
    }

    public Node getPrevNode(int data) {
        Node node = head;
        Node prevNode = head;
        while (node.data != data && node.next != null) {
            if (node.next.data == data) {
                prevNode = node;
                node = node.next;

            } else {
                node = node.next;
            }
        }
        return prevNode;
    }

    public int length() {
        Node nd = head;
        int count = 0;
        while (nd != null) {
            count++;
            nd = nd.next;
        }

        return count;
    }

    public void deleteNode(int data) {
        Node delNode = getCurrentNode(data);

        Node prevNode = getPrevNode(data);
        prevNode.next = delNode.next;

    }

    public Node reverse(Node head) {
        Node prev = null;
        Node current = head;
        Node next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        head = prev;
        return head;
    }

    public static void main(String[] args) {

        LinkedList linkedList = new LinkedList();
        linkedList.head = new Node(1);
        Node second = new Node(3);
        Node third = new Node(4);
        // Link Second element
        linkedList.head.next = second;
        // link third element
        second.next = third;

        // Print elements
        // linkedList.printListElements();
        linkedList.addFirst(5);
        // linkedList.printListElements();
        linkedList.addGivenIndex(second, 11);
        linkedList.addLast(99);
        linkedList.printListElements();
        System.out.println(":::length::" + linkedList.length());
        linkedList.deleteNode(4);
        System.out.println(":::after del lenght::" + linkedList.length());

        System.out.println(":::value Of head:::" + head.data);
        linkedList.reverse(head);
        linkedList.printListElements();

    }

}
