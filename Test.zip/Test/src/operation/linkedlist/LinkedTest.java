package operation.linkedlist;

import java.util.LinkedList;

public class LinkedTest {

	public static void main(String[] args) {

		LinkedList<String> linkedList = new LinkedList<>();
		linkedList.add("sachin");
		linkedList.add("kumar");
		linkedList.add("test");
		linkedList.add("kkk");

	}
}
