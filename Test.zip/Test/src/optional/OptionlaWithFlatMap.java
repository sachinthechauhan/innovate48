package optional;

import java.util.Optional;

public class OptionlaWithFlatMap {

	public static void main(String[] args) {

		Optional<String> gender = Optional.of("Male");
		Optional<Optional<String>> gender2 = Optional.of(gender);

		String str = gender2.map(e -> e.get()).get();
		System.out.println("::str1::" + str);
		// by usinf flate map

		String str2 = gender2.flatMap(e -> e.map(String::toUpperCase)).get();
		System.out.println("::str2:::" + str2);

		gender2.ifPresent(e -> System.out.println(e.get()));

		Optional<String> emptyGender = Optional.empty();

		System.out.println(emptyGender.orElse("no value present")); // MALE

		System.out.println(emptyGender.orElseGet(() -> "<N/A>")); // MALE

	}

}
