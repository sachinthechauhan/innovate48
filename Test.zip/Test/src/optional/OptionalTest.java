package optional;

import java.util.Optional;

public class OptionalTest {

    public static void main(String[] args) {

        Insurance insurance = new Insurance();
        //        insurance.setCompanyName("FIS");

        Car car = new Car();
        car.setInsurance(insurance);

        Person person = new Person();
        person.setCar(car);

        Optional<Insurance> insuOptional = Optional.ofNullable(insurance);

        Optional<String> compName = insuOptional.map(Insurance::getCompanyName);

        //        System.out.println(":::Comp name::" + compName);

        // Attempt 1

        Optional<Person> optPerson = Optional.ofNullable(person);
        String name = optPerson.map(Person::getCar).map(Car::getInsurance).map(Insurance::getCompanyName)
                .orElse("Not found value");

        //        System.out.println("::name of Comp:" + name);

        Optional<String> insuName =
                optPerson.map(e -> e.getCar()).map(e -> e.getInsurance()).map(e -> e.getCompanyName());

        insuName.ifPresent(e -> System.out.println("Today:::::" + e));

    }

}
