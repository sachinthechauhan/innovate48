package manuplation.string;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Set;

/**
 * https://javarevisited.blogspot.com/2015/01/top-20-string-coding-interview-question-programming-interview.html
 * @author iid
 *
 */
public class StringManuplation1 {

    // attempt 1 using array..
    public static void isAnagramBothString(String str1, String str2) {
        if (str1.length() != str2.length()) {
            System.out.println(":::not anagram.....");
            return;
        }
        char[] str1Arr = str1.toCharArray();
        char[] str2Arr = str2.toCharArray();

        Arrays.sort(str1Arr);
        Arrays.sort(str2Arr);

        if (Arrays.equals(str1Arr, str2Arr)) {
            System.out.println("::Anagram:::");
        } else {
            System.out.println(":::not anagram.....");
        }
    }

    // attempt 2
    /**
     * using string builder...
     * @param str1
     * @param str2
     */

    public static void isAnagramUsingStringBuilder(String str1, String str2) {
        if (str1.length() != str2.length()) {
            System.out.println(":::not anagram.....");
            return;
        }
        char[] str1Arr = str1.toCharArray();
        StringBuilder builder = new StringBuilder(str2);

        for (char c : str1Arr) {
            int index = builder.indexOf("" + c);
            if (index != -1) {
                builder.deleteCharAt(index);
            } else {
                System.out.println(":::not anagram.....");
            }
        }
        if (builder.length() == 0) {
            System.out.println(":::anagram.....");
        } else {
            System.out.println(":::not anagram.....");
        }

    }

    /**
     * first non repeated character...
     * 
     */
    public static void firstNonRepeatedChar(String str) {

        // use linked hashmap as its maintain order of character
        LinkedHashMap<Character, Integer> hashMap = new LinkedHashMap<>();
        char[] strArr = str.toCharArray();
        for (char c : strArr) {
            if (hashMap.containsKey(c)) {
                hashMap.put(c, hashMap.get(c) + 1);
            } else {
                hashMap.put(c, 1);
            }
        }
        System.out.println(hashMap);
        for (char c : hashMap.keySet()) {
            if (hashMap.get(c) == 1) {
                System.out.println("::::first no repeated char:::" + c);
                break;
            }
        }

    }

    /**
    * Permutation of string 
    * @param str
    * @param ans
    */

    static void printPermutn(String str, String ans) {

        // If string is empty 
        if (str.length() == 0) {
            System.out.print(ans + " ");
            return;
        }

        for (int i = 0; i < str.length(); i++) {

            // ith character of str 
            char ch = str.charAt(i);

            // Rest of the string after excluding  
            // the ith character 
            String ros = str.substring(0, i) + str.substring(i + 1);

            // Recurvise call 
            printPermutn(ros, ans + ch);
        }
    }

    /**
     * 
     * @param a
     * @param b
     * @return
     */

    public static void removeDuplicateCharacter(String str1) {

        char[] arr = str1.toCharArray();
        StringBuilder builder = new StringBuilder(str1);
        LinkedHashMap<Character, Integer> hashMap = new LinkedHashMap<>();
        int i = 0;
        for (char c : arr) {
            System.out.println(":i:::" + i);
            if (hashMap.containsKey(c)) {
                builder.deleteCharAt(i);
            } else {
                i++;
                hashMap.put(c, 1);
            }
        }
        System.out.println("::::" + builder.toString());
    }

    /**
     * Del char from string
     * @param str
     * @param rmChar
     */
    public static void delCharFromString(String str, char rmChar) {
        str = str.replaceAll("" + rmChar, "");
        System.out.println(str);
    }

    public static int getCountForAnagram(String a, String b) {
        int charMatchCount = 0;
        int reqDelChar = 0;
        Set<Character> characters = new HashSet<>();
        char[] charArr = a.toCharArray();
        for (int i = 0; i < charArr.length; i++) {
            if (/* !characters.contains(charArr[i]) && */ b.contains(String.valueOf(charArr[i]))) {
                charMatchCount++;
                characters.add(charArr[i]);
            }

        }
        int delCharFromA = a.length() - charMatchCount;
        int delCharFromB = b.length() - delCharFromA;

        reqDelChar = delCharFromA + delCharFromB;
        return reqDelChar;
    }

    public static void main(String[] args) {
        //        System.out.println("Req Del Char::" + StringManuplation1.getCountForAnagram("mary", "army"));

        //        System.out.println("Req Del Char::" + StringManuplation1.getCountForAnagram("abcda", "dea"));

        //        isAnagramBothString("mary", "army");
        //        isAnagramUsingStringBuilder("mary1", "null");
        //        firstNonRepeatedChar("sachin");
        //        printPermutn("cd", "");
        //        removeDuplicateCharacter("ssssssssaachhhhhhhii");
        delCharFromString("sachin", 'a');

    }

}
