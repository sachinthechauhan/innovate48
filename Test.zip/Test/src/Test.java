import java.text.ParseException;

public class Test {

    public static void display() {
        System.out.println(":::in display...........");
    }

    public static void main(String args[]) throws ParseException, ClassNotFoundException {

        String str = "";
        if (str != null) {
            System.out.println(":::in iffff");
        }
        int _sa = 10;

        ;

    }

}