import java.util.HashSet;
import java.util.Set;

public class CommonOfTwoString {

    static String twoStrings(String s1, String s2) {
        char[] arr = s1.toCharArray();
        for (int i = 0; i < arr.length; i++) {
            if (s2.contains(String.valueOf(arr[i]))) {
                return "YES";
            }
        }

        return "NO";

    }

    static String twoStrings2(String s1, String s2) {
        Set<Character> set = new HashSet<>();
        // add s1
        char[] arr1 = s1.toCharArray();
        for (char c : arr1) {
            set.add(c);
        }
        // add s2
        char[] arr2 = s2.toCharArray();
        for (char c : arr2) {
            if (set.contains(c)) {
                return "YES";
            }
        }
        return "NO";
    }

    public static void main(String[] args) {
        System.out.println(twoStrings2("hello", "world"));
    }

}
