import java.util.Scanner;

/**
 * Print in sinle line as even and odd charter of string
 * @author iid
 *
 *//*
   class Person {
    public String firstName;
   
    public String lastName;
   
    public int id;
   
    public int[] testScores;
   
   }*/

/*class Student extends Person {

    public Student(String firstName, String lastName, int id, int[] testScores) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.id = id;
        this.testScores = testScores;
    }

    public char calculate() {
        OptionalDouble value = Arrays.stream(testScores).average();
        double marks = value.getAsDouble();
        if (marks >= 90 && marks <= 100) {
            return 'O';
        } else if (marks >= 80 && marks < 90) {
            return 'E';
        } else if (marks >= 70 && marks < 80) {
            return 'A';
        } else if (marks >= 55 && marks < 70) {
            return 'P';
        } else if (marks >= 40 && marks < 55) {
            return 'D';
        } else {
            return 'T';
        }
    }

    public void printPerson() {
        System.out.println("Name: " + this.firstName + ", " + this.lastName);
        System.out.println("ID: " + this.id);
    }

}*/

public class Solution4 {

    public static void main(String[] argh) {
        Scanner scan = new Scanner(System.in);
        String firstName = scan.next();
        String lastName = scan.next();
        int id = scan.nextInt();
        int numScores = scan.nextInt();
        int[] testScores = new int[numScores];
        for (int i = 0; i < numScores; i++) {
            testScores[i] = scan.nextInt();
        }
        scan.close();

        Student s = new Student(firstName, lastName, id, testScores);
        s.printPerson();
        System.out.println("Grade: " + s.calculate());
    }
}
