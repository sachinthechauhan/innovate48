package com.study.SpringWebClient.controller;

import java.time.Duration;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;

@RestController
public class MonoAndFluxController {

	@GetMapping("fluxStr")
	public Flux<String> returnFluxStr() {
		Flux<String> flux = Flux.just("Sachin", "1", "2");
		return flux;

	}
	
	@GetMapping("flux")
	public Flux<Integer> returnFlux() {
		System.out.println(":::returnFlux ");
		Flux<Integer> flux = Flux.just(1, 2, 3, 4, 5, 6);
		return flux;
	}

	@GetMapping(value = "fluxStream", produces = MediaType.APPLICATION_STREAM_JSON_VALUE)
	public Flux<Integer> returnFluxStream() {
		Flux<Integer> flux = Flux.just(1,2,3,34,5,6).delayElements(Duration.ofSeconds(1)).log();
		return flux;

	}

	
	@GetMapping(value="fluxInf", produces= MediaType.APPLICATION_STREAM_JSON_VALUE)
	public Flux<Long> returnFluxWithInfiniteStream() {
		System.out.println(":::returnFluxWithInfiniteStream  ");
		Flux<Long> flux = Flux.interval(Duration.ofSeconds(1)).log();
		return flux;
	}
}
