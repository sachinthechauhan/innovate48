package com.study.SpringWebClient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;
//https://www.youtube.com/watch?v=F3uJyeAyv5g

import com.study.SpringWebClient.model.Movie;
import com.study.SpringWebClient.model.User;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
public class WebClientDemoResource {
	
	//http://localhost:8282/movie/2
	//http://localhost:8080/movieInfo/2
	//http://localhost:8282/registerdUser2
	
	@Autowired
	WebClient.Builder builder;
	
	@Autowired
	RestTemplate restTemplate;
	
	@GetMapping("movieInfo/{movieId}")
	public Movie getMovieDetails(@PathVariable("movieId") String movieid) {
		// using rest template
//		Movie mv = restTemplate.getForObject("http://localhost:8282/movie/2", Movie.class);
		Movie mv	=builder.build()
		.get()// method name
		.uri("http://localhost:8080/movie/2")
		.retrieve()// response
		.bodyToMono(Movie.class)// cast to which class
		.block();
		return mv;
	}
	
	/**
	 * spring-boot-first-app
	 * Fetch data from spring-boot-first-app 
	 * @return
	 */
	@GetMapping("userDetails")
	public Flux<User> getUserDeatils() {
		Flux<User> list=	builder.build()
		.get()
		.uri("http://localhost:8282/registerdUser2")
		.retrieve()
		.bodyToFlux(User.class)
		//.filter(e-> e.getLastName().startsWith("Kumar"))// just remove to check all user
		;
	return list;
	}
	
	/**
	 * Opearation On: spring-boot-first-app
	 Create a dummy user and send post request to Spring Boot App
	 * @return
	 */
	@GetMapping("createUser")
	public String registeruser() {
		User user = new User("Rajnesh", "Kumar", "ishi@gmail.com", 8800161404l);
		
		/*
		 * Mono<String> mUser =
		 * builder.build().post().uri("http://localhost:8282/register") //
		 * .contentType(MediaType.APPLICATION_JSON) .body(Mono.just(user),
		 * User.class).retrieve().bodyToMono(String.class);
		 */
		 
		
		// .block() is used for end of call
		
		String mUser = builder.build().post().uri("http://localhost:8080/register")
				.contentType(MediaType.APPLICATION_JSON).body(Mono.just(user), User.class).retrieve()
				.bodyToMono(String.class).block();
		 
		
		System.out.println("::::User::::" + mUser);
		return mUser;
	}

}
