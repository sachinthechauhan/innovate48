package com.study.SpringWebClient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.reactive.function.client.WebClient;

@SpringBootApplication
public class SpringWebClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebClientApplication.class, args);
	}

	@Bean
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}
	
	  @Bean public WebClient.Builder getWebClient() { return WebClient.builder(); }
	 

	/*
	 * public WebClient getWebClient() {
	 * 
	 * 
	 * HttpClient httpClient = HttpClient.create() .tcpConfiguration(client ->
	 * client.option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 10000)
	 * .doOnConnected(conn -> conn .addHandlerLast(new ReadTimeoutHandler(10))
	 * .addHandlerLast(new WriteTimeoutHandler(10))));
	 * 
	 * 
	 * 
	 * ClientHttpConnector connector = new
	 * ReactorClientHttpConnector(httpClient.wiretap(true));
	 * 
	 * 
	 * return WebClient.builder().baseUrl("http://localhost:8282/").defaultHeader(
	 * HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE) .build(); }
	 */
}
