package com.study.SpringWebClient.resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.study.SpringWebClient.model.Movie;
import com.study.SpringWebClient.model.User;


/**
 * basically purpose of this class as handel request and give response..
 * To avoid another project to handle request..just use same project for demo purpose 
 * only..
 * 
 * in real time we always hit request another micro-service for response.
 * @author Sachin Chauhan
 *
 */

@RestController
public class WebClientServerResourceDemo {
	
	@RequestMapping("movie/{movieId}")
	public Movie getMovieInfo(String movieId){
		return new Movie("12", "Don", "very Good Movie");
	}
	
	@PostMapping("/register")
	public String registerUser(@RequestBody User user) {
		System.out.println("::::web client user:::"+user);
		return "User "+user.getFirstName()+" "+user.getLastName()+"Register Succefully";
	}
	
}
