package com.study.SpringWebClient.router;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.RouterFunctions;
import org.springframework.web.reactive.function.server.ServerResponse;

import com.study.SpringWebClient.function.SampleHandlerFunction;

import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RequestPredicates.accept;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;


//https://www.youtube.com/watch?v=h7Lb6gX4ZoU&list=PLnXn1AViWyL70R5GuXt_nIDZytYBnvBdd&index=18

@Configuration
public class RouterFunctionConfig {
	// access url for this: http://localhost:8080/functional/flux
	@Bean
	public RouterFunction<ServerResponse> rout(SampleHandlerFunction function) {

		RouterFunction<ServerResponse> sr = RouterFunctions
				.route(GET("/functional/flux").and(accept(MediaType.APPLICATION_JSON)), function::flux);
		return sr;
	}
	
}
