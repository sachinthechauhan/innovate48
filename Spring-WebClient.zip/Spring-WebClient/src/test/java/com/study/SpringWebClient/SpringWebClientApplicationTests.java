package com.study.SpringWebClient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import reactor.core.publisher.Flux;

@SpringBootTest
class SpringWebClientApplicationTests {

	@Test
	void contextLoads() {
		Flux<String> str = Flux.just("Sachin", "Chauhan", "Bijnor").log();
		str.subscribe(System.out:: println);
		
		// error handling and debug...with log metho
		
		Flux<String> str2 = Flux.just("Sachin", "Chauhan", "Bijnor")
				.concatWith(Flux.error(new RuntimeException("just Test Erro"))).log();
		str2.subscribe(System.out::println,e-> System.out.println(e.getCause()));
	}

}
