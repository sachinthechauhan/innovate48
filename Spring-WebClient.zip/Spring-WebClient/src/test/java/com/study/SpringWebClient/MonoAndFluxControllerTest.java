package com.study.SpringWebClient;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.study.SpringWebClient.controller.MonoAndFluxController;

import reactor.core.publisher.Flux;
import reactor.test.StepVerifier;

@WebFluxTest(controllers = MonoAndFluxController.class)// or can give @WebFluxTest only..it will scan all
public class MonoAndFluxControllerTest {
	
	@Autowired
	WebTestClient webClient;

    @Test
    public void flux_approach1(){
    	Flux<Integer>  flux   =webClient.get().uri("/flux")
    	.accept(MediaType.APPLICATION_JSON)
    	.exchange()
    	.expectStatus().isOk()
    	.returnResult(Integer.class)
    	.getResponseBody();
    	
    	StepVerifier.create(flux)
    	.expectSubscription()
    	.expectNext(1)
    	.expectNext(2)
    	.expectNext(3)
    	.expectNext(4)
    	.expectNext(5)
    	.expectNext(6)
    	.verifyComplete();
    	
    }

    @Test
    public void fluxStream(){
        Flux<Long> longStreamFlux = webClient.get().uri("/fluxInf")
                .accept(MediaType.APPLICATION_STREAM_JSON)
                .exchange()
                .expectStatus().isOk()
                .returnResult(Long.class)
                .getResponseBody();
        
        StepVerifier.create(longStreamFlux)
                .expectNext(0l)
                .expectNext(1l)
                .expectNext(2l)
                .thenCancel()
                .verify();


    }
	
	

}
