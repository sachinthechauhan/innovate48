package com.study.springcloudzuul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudZuulApplicationTests {

	@Test
	void contextLoads() {
	}

}
