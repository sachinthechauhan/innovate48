package innovate48.campaignservice.service;

import innovate48.campaignservice.model.Campaign;


public interface CampaignService {
	public String postCampaign(Campaign campaign);
	public Campaign getCampaign(String campaignId) ;
	public String deleteCampaign(String campaignId);
}
