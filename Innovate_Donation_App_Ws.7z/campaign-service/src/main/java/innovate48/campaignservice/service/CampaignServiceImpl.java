package innovate48.campaignservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import innovate48.campaignservice.dao.CampaignDao;
import innovate48.campaignservice.model.Campaign;

@Service
public class CampaignServiceImpl implements CampaignService {

	@Autowired
	CampaignDao campaignDao;

	@Override
	public String postCampaign(Campaign campaign) {
		return campaignDao.postCampaign(campaign);
	}

	@Override
	public Campaign getCampaign(String campaignId) {
		return campaignDao.getCampaign(campaignId);
	}

	@Override
	public String deleteCampaign(String campaignId) {
		return campaignDao.deleteCampaign(campaignId);
	}

}
