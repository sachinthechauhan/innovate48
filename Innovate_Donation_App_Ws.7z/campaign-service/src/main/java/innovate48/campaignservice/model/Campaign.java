package innovate48.campaignservice.model;

import java.util.Date;
import java.util.List;

public class Campaign {

	private Integer id;
	private String title;
	private String desc;
	private List<String> audience;
	private List<String> giftCategory;
	private Integer giftLimit;
	private Date startDate;
	private Date endDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public List<String> getAudience() {
		return audience;
	}

	public void setAudience(List<String> audience) {
		this.audience = audience;
	}

	public List<String> getGiftCategory() {
		return giftCategory;
	}

	public void setGiftCategory(List<String> giftCategory) {
		this.giftCategory = giftCategory;
	}

	public Integer getGiftLimit() {
		return giftLimit;
	}

	public void setGiftLimit(Integer giftLimit) {
		this.giftLimit = giftLimit;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Campaign(Integer id, String title, String desc, List<String> audience, List<String> giftCategory,
			Integer giftLimit, Date startDate, Date endDate) {
		super();
		this.id = id;
		this.title = title;
		this.desc = desc;
		this.audience = audience;
		this.giftCategory = giftCategory;
		this.giftLimit = giftLimit;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public Campaign() {
		super();
	}

	@Override
	public String toString() {
		return "Campaign [id=" + id + ", title=" + title + ", desc=" + desc + ", audience=" + audience
				+ ", giftCategory=" + giftCategory + ", giftLimit=" + giftLimit + ", startDate=" + startDate
				+ ", endDate=" + endDate + "]";
	}

}
