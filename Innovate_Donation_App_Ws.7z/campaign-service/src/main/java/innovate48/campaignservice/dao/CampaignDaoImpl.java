package innovate48.campaignservice.dao;

import java.util.Date;

import org.springframework.stereotype.Repository;

import innovate48.campaignservice.model.Campaign;

@Repository
public class CampaignDaoImpl implements CampaignDao{

	@Override
	public String postCampaign(Campaign campaign) {
		System.out.println("Campaign Object::"+campaign);
		return null;
	}

	@Override
	public Campaign getCampaign(String campaignId) {
		Campaign campaign2 = new Campaign();
		campaign2.setId(12);
		campaign2.setTitle("Share Meal");
		campaign2.setStartDate(new Date());
		campaign2.setEndDate(new Date());
		return campaign2;
	}

	@Override
	public String deleteCampaign(String campaignId) {
		System.out.println("Del id");
		return null;
	}

}
