package innovate48.campaignservice.dao;

import innovate48.campaignservice.model.Campaign;

public interface CampaignDao {

	public String postCampaign(Campaign campaign);
	public Campaign getCampaign(String campaignId) ;
	public String deleteCampaign(String campaignId);
}
