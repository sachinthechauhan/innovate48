package innovate48.campaignservice.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import innovate48.campaignservice.model.Campaign;
import innovate48.campaignservice.service.CampaignService;

@RestController
public class CampaignResource {
	
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	CampaignService campaignService;

	@PostMapping("/postCampaign")
	public String postCampaign(@RequestBody Campaign campaign) {
		campaignService.postCampaign(campaign);
		return "Save Camp Successfully..";
	}

	@GetMapping("/campaign/{campaignId}")
	public Campaign getCampaign(@PathVariable("campaignId") String campaignId) {
		return campaignService.getCampaign(campaignId);
		
	}

	@DeleteMapping("/delcampaign/{campaignId}")
	public String deleteCampaign(@PathVariable("campaignId") String campaignId) {
		campaignService.deleteCampaign(campaignId);
		return "";
	}
}
