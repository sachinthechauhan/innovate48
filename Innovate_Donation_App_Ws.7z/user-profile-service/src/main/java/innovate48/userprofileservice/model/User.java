package innovate48.userprofileservice.model;

import java.sql.Blob;
import java.util.Date;

public class User {

	private Integer userId;
	private String userName;
	private String userNickName;
	private String eamilAddress;
	private String mobileNumber;
	private String address;
	private String userType;
	private Blob image;
	private String password;
	private Date whenModified;
	
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserNickName() {
		return userNickName;
	}
	public void setUserNickName(String userNickName) {
		this.userNickName = userNickName;
	}
	public String getEamilAddress() {
		return eamilAddress;
	}
	public void setEamilAddress(String eamilAddress) {
		this.eamilAddress = eamilAddress;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public Blob getImage() {
		return image;
	}
	public void setImage(Blob image) {
		this.image = image;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Date getWhenModified() {
		return whenModified;
	}
	public void setWhenModified(Date whenModified) {
		this.whenModified = whenModified;
	}
	@Override
	public String toString() {
		return "User [userId=" + userId + ", userName=" + userName + ", userNickName=" + userNickName
				+ ", eamilAddress=" + eamilAddress + ", mobileNumber=" + mobileNumber + ", address=" + address
				+ ", userType=" + userType + ", image=" + image + ", password=" + password + ", whenModified="
				+ whenModified + "]";
	}
	
	
	
}
