package innovate48.userprofileservice.resource;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserResource {

	
	
	
}
