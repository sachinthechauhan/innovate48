package innovate48.userprofileservice.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import innovate48.userprofileservice.model.User;

@Repository
public class UserDaoImpl implements UserDao {

	@Override
	public String createUser(User userId) {
		return null;
	}

	@Override
	public User getUserById(String userId) {
		return null;
	}

	@Override
	public String deleteUser(String userId) {
		return null;
	}

	@Override
	public List<User> getAllUser() {
		return null;
	}

}
