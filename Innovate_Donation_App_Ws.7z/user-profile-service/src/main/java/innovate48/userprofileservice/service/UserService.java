package innovate48.userprofileservice.service;

import java.util.List;

import innovate48.userprofileservice.model.User;

public interface UserService {

	public String createUser(User userId);
	public User getUserById(String userId) ;
	public String deleteUser(String userId);
	public List<User> getAllUser();
}
