package innovate48.userprofileservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import innovate48.userprofileservice.dao.UserDao;
import innovate48.userprofileservice.model.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserDao userDao;

	@Override
	public String createUser(User userId) {
		return userDao.createUser(userId);
	}

	@Override
	public User getUserById(String userId) {
		return userDao.getUserById(userId);
	}

	@Override
	public String deleteUser(String userId) {
		return userDao.deleteUser(userId);
	}

	@Override
	public List<User> getAllUser() {
		return userDao.getAllUser();
	}

}
