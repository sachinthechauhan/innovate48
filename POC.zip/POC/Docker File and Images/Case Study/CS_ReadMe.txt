Frontend service communicating with account and customer service for save and retrieve data. In K8s facing a problem to register service
with Eureka Discovery server. I will try to complete the Case Study.

Fronend Service:
http://localhost:8080/frontendservice/
http://localhost:8080/frontendservice/all

Account Service:
http://localhost:8383/accountservice/
http://localhost:8383/accountservice/all

Customer Service:
http://localhost:8282/customerservice
http://localhost:8282/customerservice/all

Discovery Server:
http://localhost:8761/



kind: Pod
apiVersion: v1
metadata:
  name: eurekaserver
  labels:
    myvalue: eurekaserver                                
spec:
  containers:
    - name: eurekaserver-00  
      image:  sachinthechauhan/springbootapp:eurekaserver
      ports:
       - containerPort: 8761                        
	   

kind: Service                   
apiVersion: v1
metadata:
  name: eurekaserver
spec:
  ports:
    - port: 8761                         
      targetPort: 8761            
  selector:
    myvalue: eurekaserver               
  type: NodePort               


Frontend Service:
----------------

kind: Pod
apiVersion: v1
metadata:
  name: frontendservice
  labels:
    myvalue: frontendservice                                
spec:
  containers:
    - name: frontendservice-00  
      image:  sachinthechauhan/springbootapp:frontendservice
      ports:
       - containerPort: 8080     
	   
kind: Service                  
apiVersion: v1
metadata:
  name: frontendservice
spec:
  ports:
    - port: 8080                         
      targetPort: 8080           
  selector:
    myvalue: frontendservice               
  type: NodePort                


Customer Service:
----------------
kind: Pod
apiVersion: v1
metadata:
  name: customerservice
  labels:
    myvalue: customerservice                                
spec:
  containers:
    - name: customerservice-00  
      image:  sachinthechauhan/springbootapp:customerservice
      ports:
       - containerPort: 8282                        
	   

kind: Service                  
apiVersion: v1
metadata:
  name: customerservice
spec:
  ports:
    - port: 8282                          
      targetPort: 8282            
  selector:
    myvalue: customerservice               
  type: NodePort                


Account Service:
---------------

kind: Pod
apiVersion: v1
metadata:
  name: accountservice
  labels:
    myvalue: accountservice                                
spec:
  containers:
    - name: accountservice-00  
      image:  sachinthechauhan/springbootapp:accountservice
      ports:
       - containerPort: 8383                        
	   

kind: Service                   
apiVersion: v1
metadata:
  name: accountservice
spec:
  ports:
    - port: 8383                          
      targetPort: 8383            
  selector:
    myvalue: accountservice               
  type: NodePort                
